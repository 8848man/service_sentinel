import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../extensions/context_extensions.dart';
import '../../../router/app_router.dart';
import '../../../state/project_session_notifier.dart';
import '../widgets/api_key_settings_section.dart';
import '../../../../features/subscription/presentation/widgets/subscription_settings_section.dart';

/// Settings screen - App settings and preferences
/// Layout only. Provider consumption happens in section widgets.
///
/// Features:
/// - Theme selection
/// - Language selection
/// - API key management (authenticated users only)
/// - Account settings
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // General settings section
              // _GeneralSettingsSection(),

              // SizedBox(height: 24),

              // Project section (show current project and change button)
              _ProjectSection(),

              SizedBox(height: 24),

              // Subscription plan section
              SubscriptionSettingsSection(),

              SizedBox(height: 24),

              // API Key settings section (authenticated only)
              ApiKeySettingsSection(),

              // SizedBox(height: 24),

              // // Account section
              // _AccountSection(),
            ],
          ),
        ),
      ),
    );
  }
}

/// Project section (current project and change button)
class _ProjectSection extends ConsumerWidget {
  const _ProjectSection();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final l10n = context.l10n;
    final projectSession = ref.watch(projectSessionProvider);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              l10n.projects_title,
              style: theme.textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            if (projectSession.hasProject) ...[
              // Current project info
              ListTile(
                leading: Icon(
                  projectSession.project!.isLocalOnly
                      ? Icons.phonelink
                      : Icons.cloud_done,
                  color: theme.colorScheme.primary,
                ),
                title: Text(projectSession.project!.name),
                subtitle: projectSession.project!.description != null
                    ? Text(
                        projectSession.project!.description!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      )
                    : null,
              ),

              const Divider(),

              // Change project button
              ListTile(
                leading: const Icon(Icons.swap_horiz),
                title: Text(l10n.settings_change_project),
                subtitle: Text(l10n.settings_change_project_desc),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                onTap: () => context.go(AppRoutes.projectSelection),
              ),
            ] else ...[
              // No project selected
              ListTile(
                leading: Icon(
                  Icons.warning_amber,
                  color: theme.colorScheme.error,
                ),
                title: Text(l10n.settings_no_project_selected),
                subtitle: Text(l10n.settings_no_project_desc),
              ),

              const Divider(),

              // Go to project selection button
              ElevatedButton.icon(
                onPressed: () => context.go(AppRoutes.projectSelection),
                icon: const Icon(Icons.add),
                label: Text(l10n.settings_select_project),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

