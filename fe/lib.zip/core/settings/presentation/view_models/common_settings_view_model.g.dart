// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'common_settings_view_model.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$commonSettingsViewModelHash() =>
    r'5d748f93589d4efd839c99f45f66b63ff65a84f7';

/// See also [CommonSettingsViewModel].
@ProviderFor(CommonSettingsViewModel)
final commonSettingsViewModelProvider =
    AutoDisposeAsyncNotifierProvider<CommonSettingsViewModel, void>.internal(
  CommonSettingsViewModel.new,
  name: r'commonSettingsViewModelProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$commonSettingsViewModelHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CommonSettingsViewModel = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
