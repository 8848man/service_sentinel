// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'project_session.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ProjectSession {
// The complete selected project (includes all API keys)
  Project? get project =>
      throw _privateConstructorUsedError; // Which API key is currently active for this session
  String? get activeApiKeyId => throw _privateConstructorUsedError;

  /// Create a copy of ProjectSession
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ProjectSessionCopyWith<ProjectSession> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectSessionCopyWith<$Res> {
  factory $ProjectSessionCopyWith(
          ProjectSession value, $Res Function(ProjectSession) then) =
      _$ProjectSessionCopyWithImpl<$Res, ProjectSession>;
  @useResult
  $Res call({Project? project, String? activeApiKeyId});

  $ProjectCopyWith<$Res>? get project;
}

/// @nodoc
class _$ProjectSessionCopyWithImpl<$Res, $Val extends ProjectSession>
    implements $ProjectSessionCopyWith<$Res> {
  _$ProjectSessionCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ProjectSession
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project = freezed,
    Object? activeApiKeyId = freezed,
  }) {
    return _then(_value.copyWith(
      project: freezed == project
          ? _value.project
          : project // ignore: cast_nullable_to_non_nullable
              as Project?,
      activeApiKeyId: freezed == activeApiKeyId
          ? _value.activeApiKeyId
          : activeApiKeyId // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  /// Create a copy of ProjectSession
  /// with the given fields replaced by the non-null parameter values.
  @override
  @pragma('vm:prefer-inline')
  $ProjectCopyWith<$Res>? get project {
    if (_value.project == null) {
      return null;
    }

    return $ProjectCopyWith<$Res>(_value.project!, (value) {
      return _then(_value.copyWith(project: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ProjectSessionImplCopyWith<$Res>
    implements $ProjectSessionCopyWith<$Res> {
  factory _$$ProjectSessionImplCopyWith(_$ProjectSessionImpl value,
          $Res Function(_$ProjectSessionImpl) then) =
      __$$ProjectSessionImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Project? project, String? activeApiKeyId});

  @override
  $ProjectCopyWith<$Res>? get project;
}

/// @nodoc
class __$$ProjectSessionImplCopyWithImpl<$Res>
    extends _$ProjectSessionCopyWithImpl<$Res, _$ProjectSessionImpl>
    implements _$$ProjectSessionImplCopyWith<$Res> {
  __$$ProjectSessionImplCopyWithImpl(
      _$ProjectSessionImpl _value, $Res Function(_$ProjectSessionImpl) _then)
      : super(_value, _then);

  /// Create a copy of ProjectSession
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project = freezed,
    Object? activeApiKeyId = freezed,
  }) {
    return _then(_$ProjectSessionImpl(
      project: freezed == project
          ? _value.project
          : project // ignore: cast_nullable_to_non_nullable
              as Project?,
      activeApiKeyId: freezed == activeApiKeyId
          ? _value.activeApiKeyId
          : activeApiKeyId // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

class _$ProjectSessionImpl extends _ProjectSession {
  const _$ProjectSessionImpl({this.project, this.activeApiKeyId}) : super._();

// The complete selected project (includes all API keys)
  @override
  final Project? project;
// Which API key is currently active for this session
  @override
  final String? activeApiKeyId;

  @override
  String toString() {
    return 'ProjectSession(project: $project, activeApiKeyId: $activeApiKeyId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProjectSessionImpl &&
            (identical(other.project, project) || other.project == project) &&
            (identical(other.activeApiKeyId, activeApiKeyId) ||
                other.activeApiKeyId == activeApiKeyId));
  }

  @override
  int get hashCode => Object.hash(runtimeType, project, activeApiKeyId);

  /// Create a copy of ProjectSession
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ProjectSessionImplCopyWith<_$ProjectSessionImpl> get copyWith =>
      __$$ProjectSessionImplCopyWithImpl<_$ProjectSessionImpl>(
          this, _$identity);
}

abstract class _ProjectSession extends ProjectSession {
  const factory _ProjectSession(
      {final Project? project,
      final String? activeApiKeyId}) = _$ProjectSessionImpl;
  const _ProjectSession._() : super._();

// The complete selected project (includes all API keys)
  @override
  Project? get project; // Which API key is currently active for this session
  @override
  String? get activeApiKeyId;

  /// Create a copy of ProjectSession
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ProjectSessionImplCopyWith<_$ProjectSessionImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
