// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'migration_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$MigrationState {
  MigrationStatus get status => throw _privateConstructorUsedError;
  String? get errorMessage => throw _privateConstructorUsedError;
  int? get totalItems => throw _privateConstructorUsedError;
  int? get migratedItems => throw _privateConstructorUsedError;

  /// Create a copy of MigrationState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $MigrationStateCopyWith<MigrationState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MigrationStateCopyWith<$Res> {
  factory $MigrationStateCopyWith(
          MigrationState value, $Res Function(MigrationState) then) =
      _$MigrationStateCopyWithImpl<$Res, MigrationState>;
  @useResult
  $Res call(
      {MigrationStatus status,
      String? errorMessage,
      int? totalItems,
      int? migratedItems});
}

/// @nodoc
class _$MigrationStateCopyWithImpl<$Res, $Val extends MigrationState>
    implements $MigrationStateCopyWith<$Res> {
  _$MigrationStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of MigrationState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? errorMessage = freezed,
    Object? totalItems = freezed,
    Object? migratedItems = freezed,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as MigrationStatus,
      errorMessage: freezed == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String?,
      totalItems: freezed == totalItems
          ? _value.totalItems
          : totalItems // ignore: cast_nullable_to_non_nullable
              as int?,
      migratedItems: freezed == migratedItems
          ? _value.migratedItems
          : migratedItems // ignore: cast_nullable_to_non_nullable
              as int?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MigrationStateImplCopyWith<$Res>
    implements $MigrationStateCopyWith<$Res> {
  factory _$$MigrationStateImplCopyWith(_$MigrationStateImpl value,
          $Res Function(_$MigrationStateImpl) then) =
      __$$MigrationStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {MigrationStatus status,
      String? errorMessage,
      int? totalItems,
      int? migratedItems});
}

/// @nodoc
class __$$MigrationStateImplCopyWithImpl<$Res>
    extends _$MigrationStateCopyWithImpl<$Res, _$MigrationStateImpl>
    implements _$$MigrationStateImplCopyWith<$Res> {
  __$$MigrationStateImplCopyWithImpl(
      _$MigrationStateImpl _value, $Res Function(_$MigrationStateImpl) _then)
      : super(_value, _then);

  /// Create a copy of MigrationState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? errorMessage = freezed,
    Object? totalItems = freezed,
    Object? migratedItems = freezed,
  }) {
    return _then(_$MigrationStateImpl(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as MigrationStatus,
      errorMessage: freezed == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String?,
      totalItems: freezed == totalItems
          ? _value.totalItems
          : totalItems // ignore: cast_nullable_to_non_nullable
              as int?,
      migratedItems: freezed == migratedItems
          ? _value.migratedItems
          : migratedItems // ignore: cast_nullable_to_non_nullable
              as int?,
    ));
  }
}

/// @nodoc

class _$MigrationStateImpl extends _MigrationState {
  const _$MigrationStateImpl(
      {required this.status,
      this.errorMessage,
      this.totalItems,
      this.migratedItems})
      : super._();

  @override
  final MigrationStatus status;
  @override
  final String? errorMessage;
  @override
  final int? totalItems;
  @override
  final int? migratedItems;

  @override
  String toString() {
    return 'MigrationState(status: $status, errorMessage: $errorMessage, totalItems: $totalItems, migratedItems: $migratedItems)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MigrationStateImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.errorMessage, errorMessage) ||
                other.errorMessage == errorMessage) &&
            (identical(other.totalItems, totalItems) ||
                other.totalItems == totalItems) &&
            (identical(other.migratedItems, migratedItems) ||
                other.migratedItems == migratedItems));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, status, errorMessage, totalItems, migratedItems);

  /// Create a copy of MigrationState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$MigrationStateImplCopyWith<_$MigrationStateImpl> get copyWith =>
      __$$MigrationStateImplCopyWithImpl<_$MigrationStateImpl>(
          this, _$identity);
}

abstract class _MigrationState extends MigrationState {
  const factory _MigrationState(
      {required final MigrationStatus status,
      final String? errorMessage,
      final int? totalItems,
      final int? migratedItems}) = _$MigrationStateImpl;
  const _MigrationState._() : super._();

  @override
  MigrationStatus get status;
  @override
  String? get errorMessage;
  @override
  int? get totalItems;
  @override
  int? get migratedItems;

  /// Create a copy of MigrationState
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$MigrationStateImplCopyWith<_$MigrationStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
