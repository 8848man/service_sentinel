// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'migration_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$migrationServiceHash() => r'6616b9d7a3ac200e365dc3e4b9763b7dde5de65b';

/// Migration service provider
///
/// Copied from [migrationService].
@ProviderFor(migrationService)
final migrationServiceProvider = AutoDisposeProvider<MigrationService>.internal(
  migrationService,
  name: r'migrationServiceProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$migrationServiceHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef MigrationServiceRef = AutoDisposeProviderRef<MigrationService>;
String _$isMigrationRequiredHash() =>
    r'1cd95b424b5c1a28fea436e3db256433d65dcfd3';

/// Helper provider to check if migration is currently needed
///
/// Copied from [isMigrationRequired].
@ProviderFor(isMigrationRequired)
final isMigrationRequiredProvider = AutoDisposeProvider<bool>.internal(
  isMigrationRequired,
  name: r'isMigrationRequiredProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$isMigrationRequiredHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef IsMigrationRequiredRef = AutoDisposeProviderRef<bool>;
String _$isMigrationInProgressHash() =>
    r'b456780d155d4cade59a0bfa6f6deb37def83804';

/// Helper provider to check if migration is in progress
///
/// Copied from [isMigrationInProgress].
@ProviderFor(isMigrationInProgress)
final isMigrationInProgressProvider = AutoDisposeProvider<bool>.internal(
  isMigrationInProgress,
  name: r'isMigrationInProgressProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$isMigrationInProgressHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef IsMigrationInProgressRef = AutoDisposeProviderRef<bool>;
String _$isMigrationCompletedHash() =>
    r'0a46041d89f6210b4813f56b402e94fbe0e6cd96';

/// Helper provider to check if migration is completed
///
/// Copied from [isMigrationCompleted].
@ProviderFor(isMigrationCompleted)
final isMigrationCompletedProvider = AutoDisposeProvider<bool>.internal(
  isMigrationCompleted,
  name: r'isMigrationCompletedProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$isMigrationCompletedHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef IsMigrationCompletedRef = AutoDisposeProviderRef<bool>;
String _$migrationStateNotifierHash() =>
    r'e791a10c259d53d388af710cce9d1d4a7f35942d';

/// Migration state notifier - Manages migration state and execution
///
/// This StateNotifier exposes migration state as an application-layer signal
/// that UI can observe. It does NOT directly render UI.
///
/// UI components can:
/// - Watch migration state changes
/// - Trigger migration via executeMigration()
/// - Skip migration via skipMigration()
/// - Check if migration is needed via checkMigrationNeeded()
///
/// Copied from [MigrationStateNotifier].
@ProviderFor(MigrationStateNotifier)
final migrationStateNotifierProvider = AutoDisposeNotifierProvider<
    MigrationStateNotifier, MigrationState>.internal(
  MigrationStateNotifier.new,
  name: r'migrationStateNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$migrationStateNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$MigrationStateNotifier = AutoDisposeNotifier<MigrationState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
