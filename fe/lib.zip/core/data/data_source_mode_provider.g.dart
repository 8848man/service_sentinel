// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'data_source_mode_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$dataSourceModeHash() => r'8a3de122a53e6ab79e847006f852b74c65cc8d70';

/// Central auth-aware data source mode provider
/// This provider listens to authentication state and determines
/// which data source (local or server) should be used.
///
/// Rules:
/// - Guest/unauthenticated → DataSourceMode.local
/// - Authenticated → DataSourceMode.server
///
/// All repository implementations MUST depend on this provider.
/// UI widgets MUST NEVER check authentication state directly.
///
/// Copied from [dataSourceMode].
@ProviderFor(dataSourceMode)
final dataSourceModeProvider = AutoDisposeProvider<DataSourceMode>.internal(
  dataSourceMode,
  name: r'dataSourceModeProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$dataSourceModeHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef DataSourceModeRef = AutoDisposeProviderRef<DataSourceMode>;
String _$isUsingLocalStorageHash() =>
    r'032bad51dd51983d3f8c4ba35c377060fb3196a2';

/// Helper provider to check if currently using local storage
///
/// Copied from [isUsingLocalStorage].
@ProviderFor(isUsingLocalStorage)
final isUsingLocalStorageProvider = AutoDisposeProvider<bool>.internal(
  isUsingLocalStorage,
  name: r'isUsingLocalStorageProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$isUsingLocalStorageHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef IsUsingLocalStorageRef = AutoDisposeProviderRef<bool>;
String _$isUsingServerStorageHash() =>
    r'969395aafa82eeb01a59763cc46109d3e030c862';

/// Helper provider to check if currently using server storage
///
/// Copied from [isUsingServerStorage].
@ProviderFor(isUsingServerStorage)
final isUsingServerStorageProvider = AutoDisposeProvider<bool>.internal(
  isUsingServerStorage,
  name: r'isUsingServerStorageProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$isUsingServerStorageHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef IsUsingServerStorageRef = AutoDisposeProviderRef<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
