// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dashboard_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$getGlobalDashboardHash() =>
    r'8f52de5ea0c98f83c5f6564828551baea7b42a3b';

/// Use case provider for getting global dashboard metrics
///
/// Copied from [getGlobalDashboard].
@ProviderFor(getGlobalDashboard)
final getGlobalDashboardProvider =
    AutoDisposeProvider<GetGlobalDashboard>.internal(
  getGlobalDashboard,
  name: r'getGlobalDashboardProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$getGlobalDashboardHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef GetGlobalDashboardRef = AutoDisposeProviderRef<GetGlobalDashboard>;
String _$globalDashboardHash() => r'362f3d653bf0b85a63c218bbccf7c65056f87405';

/// See also [globalDashboard].
@ProviderFor(globalDashboard)
final globalDashboardProvider =
    AutoDisposeFutureProvider<GlobalDashboardMetrics>.internal(
  globalDashboard,
  name: r'globalDashboardProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$globalDashboardHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef GlobalDashboardRef
    = AutoDisposeFutureProviderRef<GlobalDashboardMetrics>;
String _$getDashboardMatrixHash() =>
    r'e752fedcbad6ac198c79e6490b47fd3941dd45b0';

/// Use case provider for getting global dashboard metrics
///
/// Copied from [getDashboardMatrix].
@ProviderFor(getDashboardMatrix)
final getDashboardMatrixProvider =
    AutoDisposeProvider<GetDashboardMatrix>.internal(
  getDashboardMatrix,
  name: r'getDashboardMatrixProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$getDashboardMatrixHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef GetDashboardMatrixRef = AutoDisposeProviderRef<GetDashboardMatrix>;
String _$dashboardMatrixHash() => r'9c5bfcb8cfda1f6a425932d19d98ff37b2c2c535';

/// See also [dashboardMatrix].
@ProviderFor(dashboardMatrix)
final dashboardMatrixProvider =
    AutoDisposeFutureProvider<DashboardMetrics>.internal(
  dashboardMatrix,
  name: r'dashboardMatrixProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$dashboardMatrixHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef DashboardMatrixRef = AutoDisposeFutureProviderRef<DashboardMetrics>;
String _$getDashboardOverviewHash() =>
    r'd8be07d3ba73181959634e591c6307911f0e368d';

/// See also [getDashboardOverview].
@ProviderFor(getDashboardOverview)
final getDashboardOverviewProvider =
    AutoDisposeProvider<GetDashboardOverview>.internal(
  getDashboardOverview,
  name: r'getDashboardOverviewProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$getDashboardOverviewHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef GetDashboardOverviewRef = AutoDisposeProviderRef<GetDashboardOverview>;
String _$dashboardOverviewHash() => r'151c5b62bf55601d3b2712fb6381868171f02d00';

/// See also [dashboardOverview].
@ProviderFor(dashboardOverview)
final dashboardOverviewProvider =
    AutoDisposeFutureProvider<DashboardOverview>.internal(
  dashboardOverview,
  name: r'dashboardOverviewProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$dashboardOverviewHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef DashboardOverviewRef = AutoDisposeFutureProviderRef<DashboardOverview>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
