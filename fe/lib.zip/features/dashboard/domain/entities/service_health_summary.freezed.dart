// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'service_health_summary.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ServiceHealthSummary {
  int get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;

  /// healthy | warning | down | unknown
  String get status => throw _privateConstructorUsedError;
  bool? get lastCheckIsAlive => throw _privateConstructorUsedError;
  int? get lastCheckLatencyMs => throw _privateConstructorUsedError;
  DateTime? get lastCheckedAt => throw _privateConstructorUsedError;
  int? get activeIncidentId => throw _privateConstructorUsedError;
  IncidentSeverity? get activeIncidentSeverity =>
      throw _privateConstructorUsedError;

  /// Create a copy of ServiceHealthSummary
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ServiceHealthSummaryCopyWith<ServiceHealthSummary> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceHealthSummaryCopyWith<$Res> {
  factory $ServiceHealthSummaryCopyWith(ServiceHealthSummary value,
          $Res Function(ServiceHealthSummary) then) =
      _$ServiceHealthSummaryCopyWithImpl<$Res, ServiceHealthSummary>;
  @useResult
  $Res call(
      {int id,
      String name,
      String status,
      bool? lastCheckIsAlive,
      int? lastCheckLatencyMs,
      DateTime? lastCheckedAt,
      int? activeIncidentId,
      IncidentSeverity? activeIncidentSeverity});
}

/// @nodoc
class _$ServiceHealthSummaryCopyWithImpl<$Res,
        $Val extends ServiceHealthSummary>
    implements $ServiceHealthSummaryCopyWith<$Res> {
  _$ServiceHealthSummaryCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ServiceHealthSummary
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? status = null,
    Object? lastCheckIsAlive = freezed,
    Object? lastCheckLatencyMs = freezed,
    Object? lastCheckedAt = freezed,
    Object? activeIncidentId = freezed,
    Object? activeIncidentSeverity = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      lastCheckIsAlive: freezed == lastCheckIsAlive
          ? _value.lastCheckIsAlive
          : lastCheckIsAlive // ignore: cast_nullable_to_non_nullable
              as bool?,
      lastCheckLatencyMs: freezed == lastCheckLatencyMs
          ? _value.lastCheckLatencyMs
          : lastCheckLatencyMs // ignore: cast_nullable_to_non_nullable
              as int?,
      lastCheckedAt: freezed == lastCheckedAt
          ? _value.lastCheckedAt
          : lastCheckedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      activeIncidentId: freezed == activeIncidentId
          ? _value.activeIncidentId
          : activeIncidentId // ignore: cast_nullable_to_non_nullable
              as int?,
      activeIncidentSeverity: freezed == activeIncidentSeverity
          ? _value.activeIncidentSeverity
          : activeIncidentSeverity // ignore: cast_nullable_to_non_nullable
              as IncidentSeverity?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ServiceHealthSummaryImplCopyWith<$Res>
    implements $ServiceHealthSummaryCopyWith<$Res> {
  factory _$$ServiceHealthSummaryImplCopyWith(_$ServiceHealthSummaryImpl value,
          $Res Function(_$ServiceHealthSummaryImpl) then) =
      __$$ServiceHealthSummaryImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int id,
      String name,
      String status,
      bool? lastCheckIsAlive,
      int? lastCheckLatencyMs,
      DateTime? lastCheckedAt,
      int? activeIncidentId,
      IncidentSeverity? activeIncidentSeverity});
}

/// @nodoc
class __$$ServiceHealthSummaryImplCopyWithImpl<$Res>
    extends _$ServiceHealthSummaryCopyWithImpl<$Res, _$ServiceHealthSummaryImpl>
    implements _$$ServiceHealthSummaryImplCopyWith<$Res> {
  __$$ServiceHealthSummaryImplCopyWithImpl(_$ServiceHealthSummaryImpl _value,
      $Res Function(_$ServiceHealthSummaryImpl) _then)
      : super(_value, _then);

  /// Create a copy of ServiceHealthSummary
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? status = null,
    Object? lastCheckIsAlive = freezed,
    Object? lastCheckLatencyMs = freezed,
    Object? lastCheckedAt = freezed,
    Object? activeIncidentId = freezed,
    Object? activeIncidentSeverity = freezed,
  }) {
    return _then(_$ServiceHealthSummaryImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      lastCheckIsAlive: freezed == lastCheckIsAlive
          ? _value.lastCheckIsAlive
          : lastCheckIsAlive // ignore: cast_nullable_to_non_nullable
              as bool?,
      lastCheckLatencyMs: freezed == lastCheckLatencyMs
          ? _value.lastCheckLatencyMs
          : lastCheckLatencyMs // ignore: cast_nullable_to_non_nullable
              as int?,
      lastCheckedAt: freezed == lastCheckedAt
          ? _value.lastCheckedAt
          : lastCheckedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      activeIncidentId: freezed == activeIncidentId
          ? _value.activeIncidentId
          : activeIncidentId // ignore: cast_nullable_to_non_nullable
              as int?,
      activeIncidentSeverity: freezed == activeIncidentSeverity
          ? _value.activeIncidentSeverity
          : activeIncidentSeverity // ignore: cast_nullable_to_non_nullable
              as IncidentSeverity?,
    ));
  }
}

/// @nodoc

class _$ServiceHealthSummaryImpl implements _ServiceHealthSummary {
  const _$ServiceHealthSummaryImpl(
      {required this.id,
      required this.name,
      required this.status,
      this.lastCheckIsAlive,
      this.lastCheckLatencyMs,
      this.lastCheckedAt,
      this.activeIncidentId,
      this.activeIncidentSeverity});

  @override
  final int id;
  @override
  final String name;

  /// healthy | warning | down | unknown
  @override
  final String status;
  @override
  final bool? lastCheckIsAlive;
  @override
  final int? lastCheckLatencyMs;
  @override
  final DateTime? lastCheckedAt;
  @override
  final int? activeIncidentId;
  @override
  final IncidentSeverity? activeIncidentSeverity;

  @override
  String toString() {
    return 'ServiceHealthSummary(id: $id, name: $name, status: $status, lastCheckIsAlive: $lastCheckIsAlive, lastCheckLatencyMs: $lastCheckLatencyMs, lastCheckedAt: $lastCheckedAt, activeIncidentId: $activeIncidentId, activeIncidentSeverity: $activeIncidentSeverity)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ServiceHealthSummaryImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.lastCheckIsAlive, lastCheckIsAlive) ||
                other.lastCheckIsAlive == lastCheckIsAlive) &&
            (identical(other.lastCheckLatencyMs, lastCheckLatencyMs) ||
                other.lastCheckLatencyMs == lastCheckLatencyMs) &&
            (identical(other.lastCheckedAt, lastCheckedAt) ||
                other.lastCheckedAt == lastCheckedAt) &&
            (identical(other.activeIncidentId, activeIncidentId) ||
                other.activeIncidentId == activeIncidentId) &&
            (identical(other.activeIncidentSeverity, activeIncidentSeverity) ||
                other.activeIncidentSeverity == activeIncidentSeverity));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      name,
      status,
      lastCheckIsAlive,
      lastCheckLatencyMs,
      lastCheckedAt,
      activeIncidentId,
      activeIncidentSeverity);

  /// Create a copy of ServiceHealthSummary
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ServiceHealthSummaryImplCopyWith<_$ServiceHealthSummaryImpl>
      get copyWith =>
          __$$ServiceHealthSummaryImplCopyWithImpl<_$ServiceHealthSummaryImpl>(
              this, _$identity);
}

abstract class _ServiceHealthSummary implements ServiceHealthSummary {
  const factory _ServiceHealthSummary(
          {required final int id,
          required final String name,
          required final String status,
          final bool? lastCheckIsAlive,
          final int? lastCheckLatencyMs,
          final DateTime? lastCheckedAt,
          final int? activeIncidentId,
          final IncidentSeverity? activeIncidentSeverity}) =
      _$ServiceHealthSummaryImpl;

  @override
  int get id;
  @override
  String get name;

  /// healthy | warning | down | unknown
  @override
  String get status;
  @override
  bool? get lastCheckIsAlive;
  @override
  int? get lastCheckLatencyMs;
  @override
  DateTime? get lastCheckedAt;
  @override
  int? get activeIncidentId;
  @override
  IncidentSeverity? get activeIncidentSeverity;

  /// Create a copy of ServiceHealthSummary
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ServiceHealthSummaryImplCopyWith<_$ServiceHealthSummaryImpl>
      get copyWith => throw _privateConstructorUsedError;
}
