// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'global_dashboard_metrics.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$GlobalDashboardMetrics {
  int get totalProjects => throw _privateConstructorUsedError;
  int get totalServices => throw _privateConstructorUsedError;
  int get healthyServices => throw _privateConstructorUsedError;
  int get errorServices => throw _privateConstructorUsedError;
  int get inactiveServices => throw _privateConstructorUsedError;
  int get activeIncidents => throw _privateConstructorUsedError;
  int get degradedProjects => throw _privateConstructorUsedError;

  /// Create a copy of GlobalDashboardMetrics
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $GlobalDashboardMetricsCopyWith<GlobalDashboardMetrics> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GlobalDashboardMetricsCopyWith<$Res> {
  factory $GlobalDashboardMetricsCopyWith(GlobalDashboardMetrics value,
          $Res Function(GlobalDashboardMetrics) then) =
      _$GlobalDashboardMetricsCopyWithImpl<$Res, GlobalDashboardMetrics>;
  @useResult
  $Res call(
      {int totalProjects,
      int totalServices,
      int healthyServices,
      int errorServices,
      int inactiveServices,
      int activeIncidents,
      int degradedProjects});
}

/// @nodoc
class _$GlobalDashboardMetricsCopyWithImpl<$Res,
        $Val extends GlobalDashboardMetrics>
    implements $GlobalDashboardMetricsCopyWith<$Res> {
  _$GlobalDashboardMetricsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of GlobalDashboardMetrics
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalProjects = null,
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? errorServices = null,
    Object? inactiveServices = null,
    Object? activeIncidents = null,
    Object? degradedProjects = null,
  }) {
    return _then(_value.copyWith(
      totalProjects: null == totalProjects
          ? _value.totalProjects
          : totalProjects // ignore: cast_nullable_to_non_nullable
              as int,
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      errorServices: null == errorServices
          ? _value.errorServices
          : errorServices // ignore: cast_nullable_to_non_nullable
              as int,
      inactiveServices: null == inactiveServices
          ? _value.inactiveServices
          : inactiveServices // ignore: cast_nullable_to_non_nullable
              as int,
      activeIncidents: null == activeIncidents
          ? _value.activeIncidents
          : activeIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      degradedProjects: null == degradedProjects
          ? _value.degradedProjects
          : degradedProjects // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GlobalDashboardMetricsImplCopyWith<$Res>
    implements $GlobalDashboardMetricsCopyWith<$Res> {
  factory _$$GlobalDashboardMetricsImplCopyWith(
          _$GlobalDashboardMetricsImpl value,
          $Res Function(_$GlobalDashboardMetricsImpl) then) =
      __$$GlobalDashboardMetricsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int totalProjects,
      int totalServices,
      int healthyServices,
      int errorServices,
      int inactiveServices,
      int activeIncidents,
      int degradedProjects});
}

/// @nodoc
class __$$GlobalDashboardMetricsImplCopyWithImpl<$Res>
    extends _$GlobalDashboardMetricsCopyWithImpl<$Res,
        _$GlobalDashboardMetricsImpl>
    implements _$$GlobalDashboardMetricsImplCopyWith<$Res> {
  __$$GlobalDashboardMetricsImplCopyWithImpl(
      _$GlobalDashboardMetricsImpl _value,
      $Res Function(_$GlobalDashboardMetricsImpl) _then)
      : super(_value, _then);

  /// Create a copy of GlobalDashboardMetrics
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalProjects = null,
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? errorServices = null,
    Object? inactiveServices = null,
    Object? activeIncidents = null,
    Object? degradedProjects = null,
  }) {
    return _then(_$GlobalDashboardMetricsImpl(
      totalProjects: null == totalProjects
          ? _value.totalProjects
          : totalProjects // ignore: cast_nullable_to_non_nullable
              as int,
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      errorServices: null == errorServices
          ? _value.errorServices
          : errorServices // ignore: cast_nullable_to_non_nullable
              as int,
      inactiveServices: null == inactiveServices
          ? _value.inactiveServices
          : inactiveServices // ignore: cast_nullable_to_non_nullable
              as int,
      activeIncidents: null == activeIncidents
          ? _value.activeIncidents
          : activeIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      degradedProjects: null == degradedProjects
          ? _value.degradedProjects
          : degradedProjects // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$GlobalDashboardMetricsImpl implements _GlobalDashboardMetrics {
  const _$GlobalDashboardMetricsImpl(
      {required this.totalProjects,
      required this.totalServices,
      required this.healthyServices,
      required this.errorServices,
      required this.inactiveServices,
      required this.activeIncidents,
      required this.degradedProjects});

  @override
  final int totalProjects;
  @override
  final int totalServices;
  @override
  final int healthyServices;
  @override
  final int errorServices;
  @override
  final int inactiveServices;
  @override
  final int activeIncidents;
  @override
  final int degradedProjects;

  @override
  String toString() {
    return 'GlobalDashboardMetrics(totalProjects: $totalProjects, totalServices: $totalServices, healthyServices: $healthyServices, errorServices: $errorServices, inactiveServices: $inactiveServices, activeIncidents: $activeIncidents, degradedProjects: $degradedProjects)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GlobalDashboardMetricsImpl &&
            (identical(other.totalProjects, totalProjects) ||
                other.totalProjects == totalProjects) &&
            (identical(other.totalServices, totalServices) ||
                other.totalServices == totalServices) &&
            (identical(other.healthyServices, healthyServices) ||
                other.healthyServices == healthyServices) &&
            (identical(other.errorServices, errorServices) ||
                other.errorServices == errorServices) &&
            (identical(other.inactiveServices, inactiveServices) ||
                other.inactiveServices == inactiveServices) &&
            (identical(other.activeIncidents, activeIncidents) ||
                other.activeIncidents == activeIncidents) &&
            (identical(other.degradedProjects, degradedProjects) ||
                other.degradedProjects == degradedProjects));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      totalProjects,
      totalServices,
      healthyServices,
      errorServices,
      inactiveServices,
      activeIncidents,
      degradedProjects);

  /// Create a copy of GlobalDashboardMetrics
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$GlobalDashboardMetricsImplCopyWith<_$GlobalDashboardMetricsImpl>
      get copyWith => __$$GlobalDashboardMetricsImplCopyWithImpl<
          _$GlobalDashboardMetricsImpl>(this, _$identity);
}

abstract class _GlobalDashboardMetrics implements GlobalDashboardMetrics {
  const factory _GlobalDashboardMetrics(
      {required final int totalProjects,
      required final int totalServices,
      required final int healthyServices,
      required final int errorServices,
      required final int inactiveServices,
      required final int activeIncidents,
      required final int degradedProjects}) = _$GlobalDashboardMetricsImpl;

  @override
  int get totalProjects;
  @override
  int get totalServices;
  @override
  int get healthyServices;
  @override
  int get errorServices;
  @override
  int get inactiveServices;
  @override
  int get activeIncidents;
  @override
  int get degradedProjects;

  /// Create a copy of GlobalDashboardMetrics
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$GlobalDashboardMetricsImplCopyWith<_$GlobalDashboardMetricsImpl>
      get copyWith => throw _privateConstructorUsedError;
}
