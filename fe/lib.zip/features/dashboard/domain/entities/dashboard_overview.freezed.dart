// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'dashboard_overview.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$DashboardOverview {
  int get totalServices => throw _privateConstructorUsedError;
  int get healthyServices => throw _privateConstructorUsedError;
  int get unhealthyServices => throw _privateConstructorUsedError;
  int get totalOpenIncidents => throw _privateConstructorUsedError;
  List<ServiceHealthSummary> get services => throw _privateConstructorUsedError;
  DateTime get lastUpdated => throw _privateConstructorUsedError;

  /// Create a copy of DashboardOverview
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $DashboardOverviewCopyWith<DashboardOverview> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DashboardOverviewCopyWith<$Res> {
  factory $DashboardOverviewCopyWith(
          DashboardOverview value, $Res Function(DashboardOverview) then) =
      _$DashboardOverviewCopyWithImpl<$Res, DashboardOverview>;
  @useResult
  $Res call(
      {int totalServices,
      int healthyServices,
      int unhealthyServices,
      int totalOpenIncidents,
      List<ServiceHealthSummary> services,
      DateTime lastUpdated});
}

/// @nodoc
class _$DashboardOverviewCopyWithImpl<$Res, $Val extends DashboardOverview>
    implements $DashboardOverviewCopyWith<$Res> {
  _$DashboardOverviewCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of DashboardOverview
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? unhealthyServices = null,
    Object? totalOpenIncidents = null,
    Object? services = null,
    Object? lastUpdated = null,
  }) {
    return _then(_value.copyWith(
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      unhealthyServices: null == unhealthyServices
          ? _value.unhealthyServices
          : unhealthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      totalOpenIncidents: null == totalOpenIncidents
          ? _value.totalOpenIncidents
          : totalOpenIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      services: null == services
          ? _value.services
          : services // ignore: cast_nullable_to_non_nullable
              as List<ServiceHealthSummary>,
      lastUpdated: null == lastUpdated
          ? _value.lastUpdated
          : lastUpdated // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DashboardOverviewImplCopyWith<$Res>
    implements $DashboardOverviewCopyWith<$Res> {
  factory _$$DashboardOverviewImplCopyWith(_$DashboardOverviewImpl value,
          $Res Function(_$DashboardOverviewImpl) then) =
      __$$DashboardOverviewImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int totalServices,
      int healthyServices,
      int unhealthyServices,
      int totalOpenIncidents,
      List<ServiceHealthSummary> services,
      DateTime lastUpdated});
}

/// @nodoc
class __$$DashboardOverviewImplCopyWithImpl<$Res>
    extends _$DashboardOverviewCopyWithImpl<$Res, _$DashboardOverviewImpl>
    implements _$$DashboardOverviewImplCopyWith<$Res> {
  __$$DashboardOverviewImplCopyWithImpl(_$DashboardOverviewImpl _value,
      $Res Function(_$DashboardOverviewImpl) _then)
      : super(_value, _then);

  /// Create a copy of DashboardOverview
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? unhealthyServices = null,
    Object? totalOpenIncidents = null,
    Object? services = null,
    Object? lastUpdated = null,
  }) {
    return _then(_$DashboardOverviewImpl(
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      unhealthyServices: null == unhealthyServices
          ? _value.unhealthyServices
          : unhealthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      totalOpenIncidents: null == totalOpenIncidents
          ? _value.totalOpenIncidents
          : totalOpenIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      services: null == services
          ? _value._services
          : services // ignore: cast_nullable_to_non_nullable
              as List<ServiceHealthSummary>,
      lastUpdated: null == lastUpdated
          ? _value.lastUpdated
          : lastUpdated // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc

class _$DashboardOverviewImpl implements _DashboardOverview {
  const _$DashboardOverviewImpl(
      {required this.totalServices,
      required this.healthyServices,
      required this.unhealthyServices,
      required this.totalOpenIncidents,
      required final List<ServiceHealthSummary> services,
      required this.lastUpdated})
      : _services = services;

  @override
  final int totalServices;
  @override
  final int healthyServices;
  @override
  final int unhealthyServices;
  @override
  final int totalOpenIncidents;
  final List<ServiceHealthSummary> _services;
  @override
  List<ServiceHealthSummary> get services {
    if (_services is EqualUnmodifiableListView) return _services;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_services);
  }

  @override
  final DateTime lastUpdated;

  @override
  String toString() {
    return 'DashboardOverview(totalServices: $totalServices, healthyServices: $healthyServices, unhealthyServices: $unhealthyServices, totalOpenIncidents: $totalOpenIncidents, services: $services, lastUpdated: $lastUpdated)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DashboardOverviewImpl &&
            (identical(other.totalServices, totalServices) ||
                other.totalServices == totalServices) &&
            (identical(other.healthyServices, healthyServices) ||
                other.healthyServices == healthyServices) &&
            (identical(other.unhealthyServices, unhealthyServices) ||
                other.unhealthyServices == unhealthyServices) &&
            (identical(other.totalOpenIncidents, totalOpenIncidents) ||
                other.totalOpenIncidents == totalOpenIncidents) &&
            const DeepCollectionEquality().equals(other._services, _services) &&
            (identical(other.lastUpdated, lastUpdated) ||
                other.lastUpdated == lastUpdated));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      totalServices,
      healthyServices,
      unhealthyServices,
      totalOpenIncidents,
      const DeepCollectionEquality().hash(_services),
      lastUpdated);

  /// Create a copy of DashboardOverview
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$DashboardOverviewImplCopyWith<_$DashboardOverviewImpl> get copyWith =>
      __$$DashboardOverviewImplCopyWithImpl<_$DashboardOverviewImpl>(
          this, _$identity);
}

abstract class _DashboardOverview implements DashboardOverview {
  const factory _DashboardOverview(
      {required final int totalServices,
      required final int healthyServices,
      required final int unhealthyServices,
      required final int totalOpenIncidents,
      required final List<ServiceHealthSummary> services,
      required final DateTime lastUpdated}) = _$DashboardOverviewImpl;

  @override
  int get totalServices;
  @override
  int get healthyServices;
  @override
  int get unhealthyServices;
  @override
  int get totalOpenIncidents;
  @override
  List<ServiceHealthSummary> get services;
  @override
  DateTime get lastUpdated;

  /// Create a copy of DashboardOverview
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$DashboardOverviewImplCopyWith<_$DashboardOverviewImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
