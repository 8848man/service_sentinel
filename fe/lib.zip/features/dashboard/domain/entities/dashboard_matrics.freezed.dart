// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'dashboard_matrics.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$DashboardMetrics {
  String get period => throw _privateConstructorUsedError;
  int get totalHealthChecks => throw _privateConstructorUsedError;
  int get failedHealthChecks => throw _privateConstructorUsedError;
  double get uptimePercentage => throw _privateConstructorUsedError;
  double get averageLatencyMs => throw _privateConstructorUsedError;
  int get totalIncidents => throw _privateConstructorUsedError;
  int get openIncidents => throw _privateConstructorUsedError;
  int get aiAnalysesCount => throw _privateConstructorUsedError;
  double get aiTotalCostUsd => throw _privateConstructorUsedError;

  /// Create a copy of DashboardMetrics
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $DashboardMetricsCopyWith<DashboardMetrics> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DashboardMetricsCopyWith<$Res> {
  factory $DashboardMetricsCopyWith(
          DashboardMetrics value, $Res Function(DashboardMetrics) then) =
      _$DashboardMetricsCopyWithImpl<$Res, DashboardMetrics>;
  @useResult
  $Res call(
      {String period,
      int totalHealthChecks,
      int failedHealthChecks,
      double uptimePercentage,
      double averageLatencyMs,
      int totalIncidents,
      int openIncidents,
      int aiAnalysesCount,
      double aiTotalCostUsd});
}

/// @nodoc
class _$DashboardMetricsCopyWithImpl<$Res, $Val extends DashboardMetrics>
    implements $DashboardMetricsCopyWith<$Res> {
  _$DashboardMetricsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of DashboardMetrics
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? period = null,
    Object? totalHealthChecks = null,
    Object? failedHealthChecks = null,
    Object? uptimePercentage = null,
    Object? averageLatencyMs = null,
    Object? totalIncidents = null,
    Object? openIncidents = null,
    Object? aiAnalysesCount = null,
    Object? aiTotalCostUsd = null,
  }) {
    return _then(_value.copyWith(
      period: null == period
          ? _value.period
          : period // ignore: cast_nullable_to_non_nullable
              as String,
      totalHealthChecks: null == totalHealthChecks
          ? _value.totalHealthChecks
          : totalHealthChecks // ignore: cast_nullable_to_non_nullable
              as int,
      failedHealthChecks: null == failedHealthChecks
          ? _value.failedHealthChecks
          : failedHealthChecks // ignore: cast_nullable_to_non_nullable
              as int,
      uptimePercentage: null == uptimePercentage
          ? _value.uptimePercentage
          : uptimePercentage // ignore: cast_nullable_to_non_nullable
              as double,
      averageLatencyMs: null == averageLatencyMs
          ? _value.averageLatencyMs
          : averageLatencyMs // ignore: cast_nullable_to_non_nullable
              as double,
      totalIncidents: null == totalIncidents
          ? _value.totalIncidents
          : totalIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      openIncidents: null == openIncidents
          ? _value.openIncidents
          : openIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      aiAnalysesCount: null == aiAnalysesCount
          ? _value.aiAnalysesCount
          : aiAnalysesCount // ignore: cast_nullable_to_non_nullable
              as int,
      aiTotalCostUsd: null == aiTotalCostUsd
          ? _value.aiTotalCostUsd
          : aiTotalCostUsd // ignore: cast_nullable_to_non_nullable
              as double,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DashboardMetricsImplCopyWith<$Res>
    implements $DashboardMetricsCopyWith<$Res> {
  factory _$$DashboardMetricsImplCopyWith(_$DashboardMetricsImpl value,
          $Res Function(_$DashboardMetricsImpl) then) =
      __$$DashboardMetricsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String period,
      int totalHealthChecks,
      int failedHealthChecks,
      double uptimePercentage,
      double averageLatencyMs,
      int totalIncidents,
      int openIncidents,
      int aiAnalysesCount,
      double aiTotalCostUsd});
}

/// @nodoc
class __$$DashboardMetricsImplCopyWithImpl<$Res>
    extends _$DashboardMetricsCopyWithImpl<$Res, _$DashboardMetricsImpl>
    implements _$$DashboardMetricsImplCopyWith<$Res> {
  __$$DashboardMetricsImplCopyWithImpl(_$DashboardMetricsImpl _value,
      $Res Function(_$DashboardMetricsImpl) _then)
      : super(_value, _then);

  /// Create a copy of DashboardMetrics
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? period = null,
    Object? totalHealthChecks = null,
    Object? failedHealthChecks = null,
    Object? uptimePercentage = null,
    Object? averageLatencyMs = null,
    Object? totalIncidents = null,
    Object? openIncidents = null,
    Object? aiAnalysesCount = null,
    Object? aiTotalCostUsd = null,
  }) {
    return _then(_$DashboardMetricsImpl(
      period: null == period
          ? _value.period
          : period // ignore: cast_nullable_to_non_nullable
              as String,
      totalHealthChecks: null == totalHealthChecks
          ? _value.totalHealthChecks
          : totalHealthChecks // ignore: cast_nullable_to_non_nullable
              as int,
      failedHealthChecks: null == failedHealthChecks
          ? _value.failedHealthChecks
          : failedHealthChecks // ignore: cast_nullable_to_non_nullable
              as int,
      uptimePercentage: null == uptimePercentage
          ? _value.uptimePercentage
          : uptimePercentage // ignore: cast_nullable_to_non_nullable
              as double,
      averageLatencyMs: null == averageLatencyMs
          ? _value.averageLatencyMs
          : averageLatencyMs // ignore: cast_nullable_to_non_nullable
              as double,
      totalIncidents: null == totalIncidents
          ? _value.totalIncidents
          : totalIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      openIncidents: null == openIncidents
          ? _value.openIncidents
          : openIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      aiAnalysesCount: null == aiAnalysesCount
          ? _value.aiAnalysesCount
          : aiAnalysesCount // ignore: cast_nullable_to_non_nullable
              as int,
      aiTotalCostUsd: null == aiTotalCostUsd
          ? _value.aiTotalCostUsd
          : aiTotalCostUsd // ignore: cast_nullable_to_non_nullable
              as double,
    ));
  }
}

/// @nodoc

class _$DashboardMetricsImpl implements _DashboardMetrics {
  const _$DashboardMetricsImpl(
      {required this.period,
      required this.totalHealthChecks,
      required this.failedHealthChecks,
      required this.uptimePercentage,
      required this.averageLatencyMs,
      required this.totalIncidents,
      required this.openIncidents,
      required this.aiAnalysesCount,
      required this.aiTotalCostUsd});

  @override
  final String period;
  @override
  final int totalHealthChecks;
  @override
  final int failedHealthChecks;
  @override
  final double uptimePercentage;
  @override
  final double averageLatencyMs;
  @override
  final int totalIncidents;
  @override
  final int openIncidents;
  @override
  final int aiAnalysesCount;
  @override
  final double aiTotalCostUsd;

  @override
  String toString() {
    return 'DashboardMetrics(period: $period, totalHealthChecks: $totalHealthChecks, failedHealthChecks: $failedHealthChecks, uptimePercentage: $uptimePercentage, averageLatencyMs: $averageLatencyMs, totalIncidents: $totalIncidents, openIncidents: $openIncidents, aiAnalysesCount: $aiAnalysesCount, aiTotalCostUsd: $aiTotalCostUsd)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DashboardMetricsImpl &&
            (identical(other.period, period) || other.period == period) &&
            (identical(other.totalHealthChecks, totalHealthChecks) ||
                other.totalHealthChecks == totalHealthChecks) &&
            (identical(other.failedHealthChecks, failedHealthChecks) ||
                other.failedHealthChecks == failedHealthChecks) &&
            (identical(other.uptimePercentage, uptimePercentage) ||
                other.uptimePercentage == uptimePercentage) &&
            (identical(other.averageLatencyMs, averageLatencyMs) ||
                other.averageLatencyMs == averageLatencyMs) &&
            (identical(other.totalIncidents, totalIncidents) ||
                other.totalIncidents == totalIncidents) &&
            (identical(other.openIncidents, openIncidents) ||
                other.openIncidents == openIncidents) &&
            (identical(other.aiAnalysesCount, aiAnalysesCount) ||
                other.aiAnalysesCount == aiAnalysesCount) &&
            (identical(other.aiTotalCostUsd, aiTotalCostUsd) ||
                other.aiTotalCostUsd == aiTotalCostUsd));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      period,
      totalHealthChecks,
      failedHealthChecks,
      uptimePercentage,
      averageLatencyMs,
      totalIncidents,
      openIncidents,
      aiAnalysesCount,
      aiTotalCostUsd);

  /// Create a copy of DashboardMetrics
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$DashboardMetricsImplCopyWith<_$DashboardMetricsImpl> get copyWith =>
      __$$DashboardMetricsImplCopyWithImpl<_$DashboardMetricsImpl>(
          this, _$identity);
}

abstract class _DashboardMetrics implements DashboardMetrics {
  const factory _DashboardMetrics(
      {required final String period,
      required final int totalHealthChecks,
      required final int failedHealthChecks,
      required final double uptimePercentage,
      required final double averageLatencyMs,
      required final int totalIncidents,
      required final int openIncidents,
      required final int aiAnalysesCount,
      required final double aiTotalCostUsd}) = _$DashboardMetricsImpl;

  @override
  String get period;
  @override
  int get totalHealthChecks;
  @override
  int get failedHealthChecks;
  @override
  double get uptimePercentage;
  @override
  double get averageLatencyMs;
  @override
  int get totalIncidents;
  @override
  int get openIncidents;
  @override
  int get aiAnalysesCount;
  @override
  double get aiTotalCostUsd;

  /// Create a copy of DashboardMetrics
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$DashboardMetricsImplCopyWith<_$DashboardMetricsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
