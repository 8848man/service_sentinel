// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'dashboard_overview_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

DashboardOverviewDto _$DashboardOverviewDtoFromJson(Map<String, dynamic> json) {
  return _DashboardOverviewDto.fromJson(json);
}

/// @nodoc
mixin _$DashboardOverviewDto {
  @JsonKey(name: 'total_services')
  int get totalServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'active_services')
  int get activeServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'services_healthy')
  int get servicesHealthy => throw _privateConstructorUsedError;
  @JsonKey(name: 'services_warning')
  int get servicesWarning => throw _privateConstructorUsedError;
  @JsonKey(name: 'services_down')
  int get servicesDown => throw _privateConstructorUsedError;
  @JsonKey(name: 'services_unknown')
  int get servicesUnknown => throw _privateConstructorUsedError;
  @JsonKey(name: 'open_incidents')
  int get openIncidents => throw _privateConstructorUsedError;
  @JsonKey(name: 'critical_incidents')
  int get criticalIncidents => throw _privateConstructorUsedError;
  @JsonKey(name: 'error_services')
  int get errorServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'inactive_services')
  int get inactiveServices => throw _privateConstructorUsedError;
  List<ServiceHealthSummaryDto> get services =>
      throw _privateConstructorUsedError;

  /// Serializes this DashboardOverviewDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of DashboardOverviewDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $DashboardOverviewDtoCopyWith<DashboardOverviewDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DashboardOverviewDtoCopyWith<$Res> {
  factory $DashboardOverviewDtoCopyWith(DashboardOverviewDto value,
          $Res Function(DashboardOverviewDto) then) =
      _$DashboardOverviewDtoCopyWithImpl<$Res, DashboardOverviewDto>;
  @useResult
  $Res call(
      {@JsonKey(name: 'total_services') int totalServices,
      @JsonKey(name: 'active_services') int activeServices,
      @JsonKey(name: 'services_healthy') int servicesHealthy,
      @JsonKey(name: 'services_warning') int servicesWarning,
      @JsonKey(name: 'services_down') int servicesDown,
      @JsonKey(name: 'services_unknown') int servicesUnknown,
      @JsonKey(name: 'open_incidents') int openIncidents,
      @JsonKey(name: 'critical_incidents') int criticalIncidents,
      @JsonKey(name: 'error_services') int errorServices,
      @JsonKey(name: 'inactive_services') int inactiveServices,
      List<ServiceHealthSummaryDto> services});
}

/// @nodoc
class _$DashboardOverviewDtoCopyWithImpl<$Res,
        $Val extends DashboardOverviewDto>
    implements $DashboardOverviewDtoCopyWith<$Res> {
  _$DashboardOverviewDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of DashboardOverviewDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalServices = null,
    Object? activeServices = null,
    Object? servicesHealthy = null,
    Object? servicesWarning = null,
    Object? servicesDown = null,
    Object? servicesUnknown = null,
    Object? openIncidents = null,
    Object? criticalIncidents = null,
    Object? errorServices = null,
    Object? inactiveServices = null,
    Object? services = null,
  }) {
    return _then(_value.copyWith(
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      activeServices: null == activeServices
          ? _value.activeServices
          : activeServices // ignore: cast_nullable_to_non_nullable
              as int,
      servicesHealthy: null == servicesHealthy
          ? _value.servicesHealthy
          : servicesHealthy // ignore: cast_nullable_to_non_nullable
              as int,
      servicesWarning: null == servicesWarning
          ? _value.servicesWarning
          : servicesWarning // ignore: cast_nullable_to_non_nullable
              as int,
      servicesDown: null == servicesDown
          ? _value.servicesDown
          : servicesDown // ignore: cast_nullable_to_non_nullable
              as int,
      servicesUnknown: null == servicesUnknown
          ? _value.servicesUnknown
          : servicesUnknown // ignore: cast_nullable_to_non_nullable
              as int,
      openIncidents: null == openIncidents
          ? _value.openIncidents
          : openIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      criticalIncidents: null == criticalIncidents
          ? _value.criticalIncidents
          : criticalIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      errorServices: null == errorServices
          ? _value.errorServices
          : errorServices // ignore: cast_nullable_to_non_nullable
              as int,
      inactiveServices: null == inactiveServices
          ? _value.inactiveServices
          : inactiveServices // ignore: cast_nullable_to_non_nullable
              as int,
      services: null == services
          ? _value.services
          : services // ignore: cast_nullable_to_non_nullable
              as List<ServiceHealthSummaryDto>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DashboardOverviewDtoImplCopyWith<$Res>
    implements $DashboardOverviewDtoCopyWith<$Res> {
  factory _$$DashboardOverviewDtoImplCopyWith(_$DashboardOverviewDtoImpl value,
          $Res Function(_$DashboardOverviewDtoImpl) then) =
      __$$DashboardOverviewDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: 'total_services') int totalServices,
      @JsonKey(name: 'active_services') int activeServices,
      @JsonKey(name: 'services_healthy') int servicesHealthy,
      @JsonKey(name: 'services_warning') int servicesWarning,
      @JsonKey(name: 'services_down') int servicesDown,
      @JsonKey(name: 'services_unknown') int servicesUnknown,
      @JsonKey(name: 'open_incidents') int openIncidents,
      @JsonKey(name: 'critical_incidents') int criticalIncidents,
      @JsonKey(name: 'error_services') int errorServices,
      @JsonKey(name: 'inactive_services') int inactiveServices,
      List<ServiceHealthSummaryDto> services});
}

/// @nodoc
class __$$DashboardOverviewDtoImplCopyWithImpl<$Res>
    extends _$DashboardOverviewDtoCopyWithImpl<$Res, _$DashboardOverviewDtoImpl>
    implements _$$DashboardOverviewDtoImplCopyWith<$Res> {
  __$$DashboardOverviewDtoImplCopyWithImpl(_$DashboardOverviewDtoImpl _value,
      $Res Function(_$DashboardOverviewDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of DashboardOverviewDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalServices = null,
    Object? activeServices = null,
    Object? servicesHealthy = null,
    Object? servicesWarning = null,
    Object? servicesDown = null,
    Object? servicesUnknown = null,
    Object? openIncidents = null,
    Object? criticalIncidents = null,
    Object? errorServices = null,
    Object? inactiveServices = null,
    Object? services = null,
  }) {
    return _then(_$DashboardOverviewDtoImpl(
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      activeServices: null == activeServices
          ? _value.activeServices
          : activeServices // ignore: cast_nullable_to_non_nullable
              as int,
      servicesHealthy: null == servicesHealthy
          ? _value.servicesHealthy
          : servicesHealthy // ignore: cast_nullable_to_non_nullable
              as int,
      servicesWarning: null == servicesWarning
          ? _value.servicesWarning
          : servicesWarning // ignore: cast_nullable_to_non_nullable
              as int,
      servicesDown: null == servicesDown
          ? _value.servicesDown
          : servicesDown // ignore: cast_nullable_to_non_nullable
              as int,
      servicesUnknown: null == servicesUnknown
          ? _value.servicesUnknown
          : servicesUnknown // ignore: cast_nullable_to_non_nullable
              as int,
      openIncidents: null == openIncidents
          ? _value.openIncidents
          : openIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      criticalIncidents: null == criticalIncidents
          ? _value.criticalIncidents
          : criticalIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      errorServices: null == errorServices
          ? _value.errorServices
          : errorServices // ignore: cast_nullable_to_non_nullable
              as int,
      inactiveServices: null == inactiveServices
          ? _value.inactiveServices
          : inactiveServices // ignore: cast_nullable_to_non_nullable
              as int,
      services: null == services
          ? _value._services
          : services // ignore: cast_nullable_to_non_nullable
              as List<ServiceHealthSummaryDto>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DashboardOverviewDtoImpl extends _DashboardOverviewDto {
  const _$DashboardOverviewDtoImpl(
      {@JsonKey(name: 'total_services') required this.totalServices,
      @JsonKey(name: 'active_services') required this.activeServices,
      @JsonKey(name: 'services_healthy') required this.servicesHealthy,
      @JsonKey(name: 'services_warning') required this.servicesWarning,
      @JsonKey(name: 'services_down') required this.servicesDown,
      @JsonKey(name: 'services_unknown') required this.servicesUnknown,
      @JsonKey(name: 'open_incidents') required this.openIncidents,
      @JsonKey(name: 'critical_incidents') required this.criticalIncidents,
      @JsonKey(name: 'error_services') required this.errorServices,
      @JsonKey(name: 'inactive_services') required this.inactiveServices,
      required final List<ServiceHealthSummaryDto> services})
      : _services = services,
        super._();

  factory _$DashboardOverviewDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$DashboardOverviewDtoImplFromJson(json);

  @override
  @JsonKey(name: 'total_services')
  final int totalServices;
  @override
  @JsonKey(name: 'active_services')
  final int activeServices;
  @override
  @JsonKey(name: 'services_healthy')
  final int servicesHealthy;
  @override
  @JsonKey(name: 'services_warning')
  final int servicesWarning;
  @override
  @JsonKey(name: 'services_down')
  final int servicesDown;
  @override
  @JsonKey(name: 'services_unknown')
  final int servicesUnknown;
  @override
  @JsonKey(name: 'open_incidents')
  final int openIncidents;
  @override
  @JsonKey(name: 'critical_incidents')
  final int criticalIncidents;
  @override
  @JsonKey(name: 'error_services')
  final int errorServices;
  @override
  @JsonKey(name: 'inactive_services')
  final int inactiveServices;
  final List<ServiceHealthSummaryDto> _services;
  @override
  List<ServiceHealthSummaryDto> get services {
    if (_services is EqualUnmodifiableListView) return _services;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_services);
  }

  @override
  String toString() {
    return 'DashboardOverviewDto(totalServices: $totalServices, activeServices: $activeServices, servicesHealthy: $servicesHealthy, servicesWarning: $servicesWarning, servicesDown: $servicesDown, servicesUnknown: $servicesUnknown, openIncidents: $openIncidents, criticalIncidents: $criticalIncidents, errorServices: $errorServices, inactiveServices: $inactiveServices, services: $services)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DashboardOverviewDtoImpl &&
            (identical(other.totalServices, totalServices) ||
                other.totalServices == totalServices) &&
            (identical(other.activeServices, activeServices) ||
                other.activeServices == activeServices) &&
            (identical(other.servicesHealthy, servicesHealthy) ||
                other.servicesHealthy == servicesHealthy) &&
            (identical(other.servicesWarning, servicesWarning) ||
                other.servicesWarning == servicesWarning) &&
            (identical(other.servicesDown, servicesDown) ||
                other.servicesDown == servicesDown) &&
            (identical(other.servicesUnknown, servicesUnknown) ||
                other.servicesUnknown == servicesUnknown) &&
            (identical(other.openIncidents, openIncidents) ||
                other.openIncidents == openIncidents) &&
            (identical(other.criticalIncidents, criticalIncidents) ||
                other.criticalIncidents == criticalIncidents) &&
            (identical(other.errorServices, errorServices) ||
                other.errorServices == errorServices) &&
            (identical(other.inactiveServices, inactiveServices) ||
                other.inactiveServices == inactiveServices) &&
            const DeepCollectionEquality().equals(other._services, _services));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      totalServices,
      activeServices,
      servicesHealthy,
      servicesWarning,
      servicesDown,
      servicesUnknown,
      openIncidents,
      criticalIncidents,
      errorServices,
      inactiveServices,
      const DeepCollectionEquality().hash(_services));

  /// Create a copy of DashboardOverviewDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$DashboardOverviewDtoImplCopyWith<_$DashboardOverviewDtoImpl>
      get copyWith =>
          __$$DashboardOverviewDtoImplCopyWithImpl<_$DashboardOverviewDtoImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DashboardOverviewDtoImplToJson(
      this,
    );
  }
}

abstract class _DashboardOverviewDto extends DashboardOverviewDto {
  const factory _DashboardOverviewDto(
      {@JsonKey(name: 'total_services') required final int totalServices,
      @JsonKey(name: 'active_services') required final int activeServices,
      @JsonKey(name: 'services_healthy') required final int servicesHealthy,
      @JsonKey(name: 'services_warning') required final int servicesWarning,
      @JsonKey(name: 'services_down') required final int servicesDown,
      @JsonKey(name: 'services_unknown') required final int servicesUnknown,
      @JsonKey(name: 'open_incidents') required final int openIncidents,
      @JsonKey(name: 'critical_incidents') required final int criticalIncidents,
      @JsonKey(name: 'error_services') required final int errorServices,
      @JsonKey(name: 'inactive_services') required final int inactiveServices,
      required final List<ServiceHealthSummaryDto>
          services}) = _$DashboardOverviewDtoImpl;
  const _DashboardOverviewDto._() : super._();

  factory _DashboardOverviewDto.fromJson(Map<String, dynamic> json) =
      _$DashboardOverviewDtoImpl.fromJson;

  @override
  @JsonKey(name: 'total_services')
  int get totalServices;
  @override
  @JsonKey(name: 'active_services')
  int get activeServices;
  @override
  @JsonKey(name: 'services_healthy')
  int get servicesHealthy;
  @override
  @JsonKey(name: 'services_warning')
  int get servicesWarning;
  @override
  @JsonKey(name: 'services_down')
  int get servicesDown;
  @override
  @JsonKey(name: 'services_unknown')
  int get servicesUnknown;
  @override
  @JsonKey(name: 'open_incidents')
  int get openIncidents;
  @override
  @JsonKey(name: 'critical_incidents')
  int get criticalIncidents;
  @override
  @JsonKey(name: 'error_services')
  int get errorServices;
  @override
  @JsonKey(name: 'inactive_services')
  int get inactiveServices;
  @override
  List<ServiceHealthSummaryDto> get services;

  /// Create a copy of DashboardOverviewDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$DashboardOverviewDtoImplCopyWith<_$DashboardOverviewDtoImpl>
      get copyWith => throw _privateConstructorUsedError;
}
