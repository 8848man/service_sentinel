// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'global_dashboard_metrics_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

GlobalDashboardMetricsDto _$GlobalDashboardMetricsDtoFromJson(
    Map<String, dynamic> json) {
  return _GlobalDashboardMetricsDto.fromJson(json);
}

/// @nodoc
mixin _$GlobalDashboardMetricsDto {
  @JsonKey(name: 'total_projects')
  int get totalProjects => throw _privateConstructorUsedError;
  @JsonKey(name: 'total_services')
  int get totalServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'healthy_services')
  int get healthyServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'error_services')
  int get errorServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'inactive_services')
  int get inactiveServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'active_incidents')
  int get activeIncidents => throw _privateConstructorUsedError;
  @JsonKey(name: 'degraded_projects')
  int get degradedProjects => throw _privateConstructorUsedError;

  /// Serializes this GlobalDashboardMetricsDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of GlobalDashboardMetricsDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $GlobalDashboardMetricsDtoCopyWith<GlobalDashboardMetricsDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $GlobalDashboardMetricsDtoCopyWith<$Res> {
  factory $GlobalDashboardMetricsDtoCopyWith(GlobalDashboardMetricsDto value,
          $Res Function(GlobalDashboardMetricsDto) then) =
      _$GlobalDashboardMetricsDtoCopyWithImpl<$Res, GlobalDashboardMetricsDto>;
  @useResult
  $Res call(
      {@JsonKey(name: 'total_projects') int totalProjects,
      @JsonKey(name: 'total_services') int totalServices,
      @JsonKey(name: 'healthy_services') int healthyServices,
      @JsonKey(name: 'error_services') int errorServices,
      @JsonKey(name: 'inactive_services') int inactiveServices,
      @JsonKey(name: 'active_incidents') int activeIncidents,
      @JsonKey(name: 'degraded_projects') int degradedProjects});
}

/// @nodoc
class _$GlobalDashboardMetricsDtoCopyWithImpl<$Res,
        $Val extends GlobalDashboardMetricsDto>
    implements $GlobalDashboardMetricsDtoCopyWith<$Res> {
  _$GlobalDashboardMetricsDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of GlobalDashboardMetricsDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalProjects = null,
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? errorServices = null,
    Object? inactiveServices = null,
    Object? activeIncidents = null,
    Object? degradedProjects = null,
  }) {
    return _then(_value.copyWith(
      totalProjects: null == totalProjects
          ? _value.totalProjects
          : totalProjects // ignore: cast_nullable_to_non_nullable
              as int,
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      errorServices: null == errorServices
          ? _value.errorServices
          : errorServices // ignore: cast_nullable_to_non_nullable
              as int,
      inactiveServices: null == inactiveServices
          ? _value.inactiveServices
          : inactiveServices // ignore: cast_nullable_to_non_nullable
              as int,
      activeIncidents: null == activeIncidents
          ? _value.activeIncidents
          : activeIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      degradedProjects: null == degradedProjects
          ? _value.degradedProjects
          : degradedProjects // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$GlobalDashboardMetricsDtoImplCopyWith<$Res>
    implements $GlobalDashboardMetricsDtoCopyWith<$Res> {
  factory _$$GlobalDashboardMetricsDtoImplCopyWith(
          _$GlobalDashboardMetricsDtoImpl value,
          $Res Function(_$GlobalDashboardMetricsDtoImpl) then) =
      __$$GlobalDashboardMetricsDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: 'total_projects') int totalProjects,
      @JsonKey(name: 'total_services') int totalServices,
      @JsonKey(name: 'healthy_services') int healthyServices,
      @JsonKey(name: 'error_services') int errorServices,
      @JsonKey(name: 'inactive_services') int inactiveServices,
      @JsonKey(name: 'active_incidents') int activeIncidents,
      @JsonKey(name: 'degraded_projects') int degradedProjects});
}

/// @nodoc
class __$$GlobalDashboardMetricsDtoImplCopyWithImpl<$Res>
    extends _$GlobalDashboardMetricsDtoCopyWithImpl<$Res,
        _$GlobalDashboardMetricsDtoImpl>
    implements _$$GlobalDashboardMetricsDtoImplCopyWith<$Res> {
  __$$GlobalDashboardMetricsDtoImplCopyWithImpl(
      _$GlobalDashboardMetricsDtoImpl _value,
      $Res Function(_$GlobalDashboardMetricsDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of GlobalDashboardMetricsDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalProjects = null,
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? errorServices = null,
    Object? inactiveServices = null,
    Object? activeIncidents = null,
    Object? degradedProjects = null,
  }) {
    return _then(_$GlobalDashboardMetricsDtoImpl(
      totalProjects: null == totalProjects
          ? _value.totalProjects
          : totalProjects // ignore: cast_nullable_to_non_nullable
              as int,
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      errorServices: null == errorServices
          ? _value.errorServices
          : errorServices // ignore: cast_nullable_to_non_nullable
              as int,
      inactiveServices: null == inactiveServices
          ? _value.inactiveServices
          : inactiveServices // ignore: cast_nullable_to_non_nullable
              as int,
      activeIncidents: null == activeIncidents
          ? _value.activeIncidents
          : activeIncidents // ignore: cast_nullable_to_non_nullable
              as int,
      degradedProjects: null == degradedProjects
          ? _value.degradedProjects
          : degradedProjects // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$GlobalDashboardMetricsDtoImpl extends _GlobalDashboardMetricsDto {
  const _$GlobalDashboardMetricsDtoImpl(
      {@JsonKey(name: 'total_projects') required this.totalProjects,
      @JsonKey(name: 'total_services') required this.totalServices,
      @JsonKey(name: 'healthy_services') required this.healthyServices,
      @JsonKey(name: 'error_services') required this.errorServices,
      @JsonKey(name: 'inactive_services') required this.inactiveServices,
      @JsonKey(name: 'active_incidents') required this.activeIncidents,
      @JsonKey(name: 'degraded_projects') required this.degradedProjects})
      : super._();

  factory _$GlobalDashboardMetricsDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$GlobalDashboardMetricsDtoImplFromJson(json);

  @override
  @JsonKey(name: 'total_projects')
  final int totalProjects;
  @override
  @JsonKey(name: 'total_services')
  final int totalServices;
  @override
  @JsonKey(name: 'healthy_services')
  final int healthyServices;
  @override
  @JsonKey(name: 'error_services')
  final int errorServices;
  @override
  @JsonKey(name: 'inactive_services')
  final int inactiveServices;
  @override
  @JsonKey(name: 'active_incidents')
  final int activeIncidents;
  @override
  @JsonKey(name: 'degraded_projects')
  final int degradedProjects;

  @override
  String toString() {
    return 'GlobalDashboardMetricsDto(totalProjects: $totalProjects, totalServices: $totalServices, healthyServices: $healthyServices, errorServices: $errorServices, inactiveServices: $inactiveServices, activeIncidents: $activeIncidents, degradedProjects: $degradedProjects)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$GlobalDashboardMetricsDtoImpl &&
            (identical(other.totalProjects, totalProjects) ||
                other.totalProjects == totalProjects) &&
            (identical(other.totalServices, totalServices) ||
                other.totalServices == totalServices) &&
            (identical(other.healthyServices, healthyServices) ||
                other.healthyServices == healthyServices) &&
            (identical(other.errorServices, errorServices) ||
                other.errorServices == errorServices) &&
            (identical(other.inactiveServices, inactiveServices) ||
                other.inactiveServices == inactiveServices) &&
            (identical(other.activeIncidents, activeIncidents) ||
                other.activeIncidents == activeIncidents) &&
            (identical(other.degradedProjects, degradedProjects) ||
                other.degradedProjects == degradedProjects));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      totalProjects,
      totalServices,
      healthyServices,
      errorServices,
      inactiveServices,
      activeIncidents,
      degradedProjects);

  /// Create a copy of GlobalDashboardMetricsDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$GlobalDashboardMetricsDtoImplCopyWith<_$GlobalDashboardMetricsDtoImpl>
      get copyWith => __$$GlobalDashboardMetricsDtoImplCopyWithImpl<
          _$GlobalDashboardMetricsDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$GlobalDashboardMetricsDtoImplToJson(
      this,
    );
  }
}

abstract class _GlobalDashboardMetricsDto extends GlobalDashboardMetricsDto {
  const factory _GlobalDashboardMetricsDto(
      {@JsonKey(name: 'total_projects') required final int totalProjects,
      @JsonKey(name: 'total_services') required final int totalServices,
      @JsonKey(name: 'healthy_services') required final int healthyServices,
      @JsonKey(name: 'error_services') required final int errorServices,
      @JsonKey(name: 'inactive_services') required final int inactiveServices,
      @JsonKey(name: 'active_incidents') required final int activeIncidents,
      @JsonKey(name: 'degraded_projects')
      required final int degradedProjects}) = _$GlobalDashboardMetricsDtoImpl;
  const _GlobalDashboardMetricsDto._() : super._();

  factory _GlobalDashboardMetricsDto.fromJson(Map<String, dynamic> json) =
      _$GlobalDashboardMetricsDtoImpl.fromJson;

  @override
  @JsonKey(name: 'total_projects')
  int get totalProjects;
  @override
  @JsonKey(name: 'total_services')
  int get totalServices;
  @override
  @JsonKey(name: 'healthy_services')
  int get healthyServices;
  @override
  @JsonKey(name: 'error_services')
  int get errorServices;
  @override
  @JsonKey(name: 'inactive_services')
  int get inactiveServices;
  @override
  @JsonKey(name: 'active_incidents')
  int get activeIncidents;
  @override
  @JsonKey(name: 'degraded_projects')
  int get degradedProjects;

  /// Create a copy of GlobalDashboardMetricsDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$GlobalDashboardMetricsDtoImplCopyWith<_$GlobalDashboardMetricsDtoImpl>
      get copyWith => throw _privateConstructorUsedError;
}
