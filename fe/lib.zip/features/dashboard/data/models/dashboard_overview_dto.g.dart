// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dashboard_overview_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$DashboardOverviewDtoImpl _$$DashboardOverviewDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$DashboardOverviewDtoImpl(
      totalServices: (json['total_services'] as num).toInt(),
      activeServices: (json['active_services'] as num).toInt(),
      servicesHealthy: (json['services_healthy'] as num).toInt(),
      servicesWarning: (json['services_warning'] as num).toInt(),
      servicesDown: (json['services_down'] as num).toInt(),
      servicesUnknown: (json['services_unknown'] as num).toInt(),
      openIncidents: (json['open_incidents'] as num).toInt(),
      criticalIncidents: (json['critical_incidents'] as num).toInt(),
      errorServices: (json['error_services'] as num).toInt(),
      inactiveServices: (json['inactive_services'] as num).toInt(),
      services: (json['services'] as List<dynamic>)
          .map((e) =>
              ServiceHealthSummaryDto.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$DashboardOverviewDtoImplToJson(
        _$DashboardOverviewDtoImpl instance) =>
    <String, dynamic>{
      'total_services': instance.totalServices,
      'active_services': instance.activeServices,
      'services_healthy': instance.servicesHealthy,
      'services_warning': instance.servicesWarning,
      'services_down': instance.servicesDown,
      'services_unknown': instance.servicesUnknown,
      'open_incidents': instance.openIncidents,
      'critical_incidents': instance.criticalIncidents,
      'error_services': instance.errorServices,
      'inactive_services': instance.inactiveServices,
      'services': instance.services,
    };
