// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'service_health_summary_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ServiceHealthSummaryDtoImpl _$$ServiceHealthSummaryDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ServiceHealthSummaryDtoImpl(
      id: (json['id'] as num).toInt(),
      name: json['name'] as String,
      status: json['status'] as String,
      lastCheckIsAlive: json['last_check_is_alive'] as bool?,
      lastCheckLatencyMs: (json['last_check_latency_ms'] as num?)?.toInt(),
      lastCheckedAt: json['last_checked_at'] == null
          ? null
          : DateTime.parse(json['last_checked_at'] as String),
      activeIncidentId: (json['active_incident_id'] as num?)?.toInt(),
      activeIncidentSeverity: json['active_incident_severity'] as String?,
    );

Map<String, dynamic> _$$ServiceHealthSummaryDtoImplToJson(
        _$ServiceHealthSummaryDtoImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'status': instance.status,
      'last_check_is_alive': instance.lastCheckIsAlive,
      'last_check_latency_ms': instance.lastCheckLatencyMs,
      'last_checked_at': instance.lastCheckedAt?.toIso8601String(),
      'active_incident_id': instance.activeIncidentId,
      'active_incident_severity': instance.activeIncidentSeverity,
    };
