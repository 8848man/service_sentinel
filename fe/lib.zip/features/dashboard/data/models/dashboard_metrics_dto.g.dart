// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dashboard_metrics_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$DashboardMetricsDtoImpl _$$DashboardMetricsDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$DashboardMetricsDtoImpl(
      totalServicesMonitored: (json['totalServicesMonitored'] as num).toInt(),
      successfulChecksLastHour:
          (json['successfulChecksLastHour'] as num).toInt(),
      failedChecksLastHour: (json['failedChecksLastHour'] as num).toInt(),
      avgCheckDurationMs: (json['avgCheckDurationMs'] as num).toDouble(),
      aiAnalysesPerformed: (json['aiAnalysesPerformed'] as num).toInt(),
      totalAiCostUsd: (json['totalAiCostUsd'] as num).toDouble(),
      incidentsOpen: (json['incidentsOpen'] as num).toInt(),
      incidentsResolvedToday: (json['incidentsResolvedToday'] as num).toInt(),
    );

Map<String, dynamic> _$$DashboardMetricsDtoImplToJson(
        _$DashboardMetricsDtoImpl instance) =>
    <String, dynamic>{
      'totalServicesMonitored': instance.totalServicesMonitored,
      'successfulChecksLastHour': instance.successfulChecksLastHour,
      'failedChecksLastHour': instance.failedChecksLastHour,
      'avgCheckDurationMs': instance.avgCheckDurationMs,
      'aiAnalysesPerformed': instance.aiAnalysesPerformed,
      'totalAiCostUsd': instance.totalAiCostUsd,
      'incidentsOpen': instance.incidentsOpen,
      'incidentsResolvedToday': instance.incidentsResolvedToday,
    };
