// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'global_dashboard_metrics_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$GlobalDashboardMetricsDtoImpl _$$GlobalDashboardMetricsDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$GlobalDashboardMetricsDtoImpl(
      totalProjects: (json['total_projects'] as num).toInt(),
      totalServices: (json['total_services'] as num).toInt(),
      healthyServices: (json['healthy_services'] as num).toInt(),
      errorServices: (json['error_services'] as num).toInt(),
      inactiveServices: (json['inactive_services'] as num).toInt(),
      activeIncidents: (json['active_incidents'] as num).toInt(),
      degradedProjects: (json['degraded_projects'] as num).toInt(),
    );

Map<String, dynamic> _$$GlobalDashboardMetricsDtoImplToJson(
        _$GlobalDashboardMetricsDtoImpl instance) =>
    <String, dynamic>{
      'total_projects': instance.totalProjects,
      'total_services': instance.totalServices,
      'healthy_services': instance.healthyServices,
      'error_services': instance.errorServices,
      'inactive_services': instance.inactiveServices,
      'active_incidents': instance.activeIncidents,
      'degraded_projects': instance.degradedProjects,
    };
