// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'service_health_summary_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ServiceHealthSummaryDto _$ServiceHealthSummaryDtoFromJson(
    Map<String, dynamic> json) {
  return _ServiceHealthSummaryDto.fromJson(json);
}

/// @nodoc
mixin _$ServiceHealthSummaryDto {
  int get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  @JsonKey(name: 'last_check_is_alive')
  bool? get lastCheckIsAlive => throw _privateConstructorUsedError;
  @JsonKey(name: 'last_check_latency_ms')
  int? get lastCheckLatencyMs => throw _privateConstructorUsedError;
  @JsonKey(name: 'last_checked_at')
  DateTime? get lastCheckedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'active_incident_id')
  int? get activeIncidentId => throw _privateConstructorUsedError;
  @JsonKey(name: 'active_incident_severity')
  String? get activeIncidentSeverity => throw _privateConstructorUsedError;

  /// Serializes this ServiceHealthSummaryDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ServiceHealthSummaryDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ServiceHealthSummaryDtoCopyWith<ServiceHealthSummaryDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceHealthSummaryDtoCopyWith<$Res> {
  factory $ServiceHealthSummaryDtoCopyWith(ServiceHealthSummaryDto value,
          $Res Function(ServiceHealthSummaryDto) then) =
      _$ServiceHealthSummaryDtoCopyWithImpl<$Res, ServiceHealthSummaryDto>;
  @useResult
  $Res call(
      {int id,
      String name,
      String status,
      @JsonKey(name: 'last_check_is_alive') bool? lastCheckIsAlive,
      @JsonKey(name: 'last_check_latency_ms') int? lastCheckLatencyMs,
      @JsonKey(name: 'last_checked_at') DateTime? lastCheckedAt,
      @JsonKey(name: 'active_incident_id') int? activeIncidentId,
      @JsonKey(name: 'active_incident_severity')
      String? activeIncidentSeverity});
}

/// @nodoc
class _$ServiceHealthSummaryDtoCopyWithImpl<$Res,
        $Val extends ServiceHealthSummaryDto>
    implements $ServiceHealthSummaryDtoCopyWith<$Res> {
  _$ServiceHealthSummaryDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ServiceHealthSummaryDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? status = null,
    Object? lastCheckIsAlive = freezed,
    Object? lastCheckLatencyMs = freezed,
    Object? lastCheckedAt = freezed,
    Object? activeIncidentId = freezed,
    Object? activeIncidentSeverity = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      lastCheckIsAlive: freezed == lastCheckIsAlive
          ? _value.lastCheckIsAlive
          : lastCheckIsAlive // ignore: cast_nullable_to_non_nullable
              as bool?,
      lastCheckLatencyMs: freezed == lastCheckLatencyMs
          ? _value.lastCheckLatencyMs
          : lastCheckLatencyMs // ignore: cast_nullable_to_non_nullable
              as int?,
      lastCheckedAt: freezed == lastCheckedAt
          ? _value.lastCheckedAt
          : lastCheckedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      activeIncidentId: freezed == activeIncidentId
          ? _value.activeIncidentId
          : activeIncidentId // ignore: cast_nullable_to_non_nullable
              as int?,
      activeIncidentSeverity: freezed == activeIncidentSeverity
          ? _value.activeIncidentSeverity
          : activeIncidentSeverity // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ServiceHealthSummaryDtoImplCopyWith<$Res>
    implements $ServiceHealthSummaryDtoCopyWith<$Res> {
  factory _$$ServiceHealthSummaryDtoImplCopyWith(
          _$ServiceHealthSummaryDtoImpl value,
          $Res Function(_$ServiceHealthSummaryDtoImpl) then) =
      __$$ServiceHealthSummaryDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int id,
      String name,
      String status,
      @JsonKey(name: 'last_check_is_alive') bool? lastCheckIsAlive,
      @JsonKey(name: 'last_check_latency_ms') int? lastCheckLatencyMs,
      @JsonKey(name: 'last_checked_at') DateTime? lastCheckedAt,
      @JsonKey(name: 'active_incident_id') int? activeIncidentId,
      @JsonKey(name: 'active_incident_severity')
      String? activeIncidentSeverity});
}

/// @nodoc
class __$$ServiceHealthSummaryDtoImplCopyWithImpl<$Res>
    extends _$ServiceHealthSummaryDtoCopyWithImpl<$Res,
        _$ServiceHealthSummaryDtoImpl>
    implements _$$ServiceHealthSummaryDtoImplCopyWith<$Res> {
  __$$ServiceHealthSummaryDtoImplCopyWithImpl(
      _$ServiceHealthSummaryDtoImpl _value,
      $Res Function(_$ServiceHealthSummaryDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of ServiceHealthSummaryDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? status = null,
    Object? lastCheckIsAlive = freezed,
    Object? lastCheckLatencyMs = freezed,
    Object? lastCheckedAt = freezed,
    Object? activeIncidentId = freezed,
    Object? activeIncidentSeverity = freezed,
  }) {
    return _then(_$ServiceHealthSummaryDtoImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      lastCheckIsAlive: freezed == lastCheckIsAlive
          ? _value.lastCheckIsAlive
          : lastCheckIsAlive // ignore: cast_nullable_to_non_nullable
              as bool?,
      lastCheckLatencyMs: freezed == lastCheckLatencyMs
          ? _value.lastCheckLatencyMs
          : lastCheckLatencyMs // ignore: cast_nullable_to_non_nullable
              as int?,
      lastCheckedAt: freezed == lastCheckedAt
          ? _value.lastCheckedAt
          : lastCheckedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      activeIncidentId: freezed == activeIncidentId
          ? _value.activeIncidentId
          : activeIncidentId // ignore: cast_nullable_to_non_nullable
              as int?,
      activeIncidentSeverity: freezed == activeIncidentSeverity
          ? _value.activeIncidentSeverity
          : activeIncidentSeverity // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ServiceHealthSummaryDtoImpl extends _ServiceHealthSummaryDto {
  const _$ServiceHealthSummaryDtoImpl(
      {required this.id,
      required this.name,
      required this.status,
      @JsonKey(name: 'last_check_is_alive') this.lastCheckIsAlive,
      @JsonKey(name: 'last_check_latency_ms') this.lastCheckLatencyMs,
      @JsonKey(name: 'last_checked_at') this.lastCheckedAt,
      @JsonKey(name: 'active_incident_id') this.activeIncidentId,
      @JsonKey(name: 'active_incident_severity') this.activeIncidentSeverity})
      : super._();

  factory _$ServiceHealthSummaryDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ServiceHealthSummaryDtoImplFromJson(json);

  @override
  final int id;
  @override
  final String name;
  @override
  final String status;
  @override
  @JsonKey(name: 'last_check_is_alive')
  final bool? lastCheckIsAlive;
  @override
  @JsonKey(name: 'last_check_latency_ms')
  final int? lastCheckLatencyMs;
  @override
  @JsonKey(name: 'last_checked_at')
  final DateTime? lastCheckedAt;
  @override
  @JsonKey(name: 'active_incident_id')
  final int? activeIncidentId;
  @override
  @JsonKey(name: 'active_incident_severity')
  final String? activeIncidentSeverity;

  @override
  String toString() {
    return 'ServiceHealthSummaryDto(id: $id, name: $name, status: $status, lastCheckIsAlive: $lastCheckIsAlive, lastCheckLatencyMs: $lastCheckLatencyMs, lastCheckedAt: $lastCheckedAt, activeIncidentId: $activeIncidentId, activeIncidentSeverity: $activeIncidentSeverity)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ServiceHealthSummaryDtoImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.lastCheckIsAlive, lastCheckIsAlive) ||
                other.lastCheckIsAlive == lastCheckIsAlive) &&
            (identical(other.lastCheckLatencyMs, lastCheckLatencyMs) ||
                other.lastCheckLatencyMs == lastCheckLatencyMs) &&
            (identical(other.lastCheckedAt, lastCheckedAt) ||
                other.lastCheckedAt == lastCheckedAt) &&
            (identical(other.activeIncidentId, activeIncidentId) ||
                other.activeIncidentId == activeIncidentId) &&
            (identical(other.activeIncidentSeverity, activeIncidentSeverity) ||
                other.activeIncidentSeverity == activeIncidentSeverity));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      name,
      status,
      lastCheckIsAlive,
      lastCheckLatencyMs,
      lastCheckedAt,
      activeIncidentId,
      activeIncidentSeverity);

  /// Create a copy of ServiceHealthSummaryDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ServiceHealthSummaryDtoImplCopyWith<_$ServiceHealthSummaryDtoImpl>
      get copyWith => __$$ServiceHealthSummaryDtoImplCopyWithImpl<
          _$ServiceHealthSummaryDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ServiceHealthSummaryDtoImplToJson(
      this,
    );
  }
}

abstract class _ServiceHealthSummaryDto extends ServiceHealthSummaryDto {
  const factory _ServiceHealthSummaryDto(
      {required final int id,
      required final String name,
      required final String status,
      @JsonKey(name: 'last_check_is_alive') final bool? lastCheckIsAlive,
      @JsonKey(name: 'last_check_latency_ms') final int? lastCheckLatencyMs,
      @JsonKey(name: 'last_checked_at') final DateTime? lastCheckedAt,
      @JsonKey(name: 'active_incident_id') final int? activeIncidentId,
      @JsonKey(name: 'active_incident_severity')
      final String? activeIncidentSeverity}) = _$ServiceHealthSummaryDtoImpl;
  const _ServiceHealthSummaryDto._() : super._();

  factory _ServiceHealthSummaryDto.fromJson(Map<String, dynamic> json) =
      _$ServiceHealthSummaryDtoImpl.fromJson;

  @override
  int get id;
  @override
  String get name;
  @override
  String get status;
  @override
  @JsonKey(name: 'last_check_is_alive')
  bool? get lastCheckIsAlive;
  @override
  @JsonKey(name: 'last_check_latency_ms')
  int? get lastCheckLatencyMs;
  @override
  @JsonKey(name: 'last_checked_at')
  DateTime? get lastCheckedAt;
  @override
  @JsonKey(name: 'active_incident_id')
  int? get activeIncidentId;
  @override
  @JsonKey(name: 'active_incident_severity')
  String? get activeIncidentSeverity;

  /// Create a copy of ServiceHealthSummaryDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ServiceHealthSummaryDtoImplCopyWith<_$ServiceHealthSummaryDtoImpl>
      get copyWith => throw _privateConstructorUsedError;
}
