// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'dashboard_metrics_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

DashboardMetricsDto _$DashboardMetricsDtoFromJson(Map<String, dynamic> json) {
  return _DashboardMetricsDto.fromJson(json);
}

/// @nodoc
mixin _$DashboardMetricsDto {
  int get totalServicesMonitored => throw _privateConstructorUsedError;
  int get successfulChecksLastHour => throw _privateConstructorUsedError;
  int get failedChecksLastHour => throw _privateConstructorUsedError;
  double get avgCheckDurationMs => throw _privateConstructorUsedError;
  int get aiAnalysesPerformed => throw _privateConstructorUsedError;
  double get totalAiCostUsd => throw _privateConstructorUsedError;
  int get incidentsOpen => throw _privateConstructorUsedError;
  int get incidentsResolvedToday => throw _privateConstructorUsedError;

  /// Serializes this DashboardMetricsDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of DashboardMetricsDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $DashboardMetricsDtoCopyWith<DashboardMetricsDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DashboardMetricsDtoCopyWith<$Res> {
  factory $DashboardMetricsDtoCopyWith(
          DashboardMetricsDto value, $Res Function(DashboardMetricsDto) then) =
      _$DashboardMetricsDtoCopyWithImpl<$Res, DashboardMetricsDto>;
  @useResult
  $Res call(
      {int totalServicesMonitored,
      int successfulChecksLastHour,
      int failedChecksLastHour,
      double avgCheckDurationMs,
      int aiAnalysesPerformed,
      double totalAiCostUsd,
      int incidentsOpen,
      int incidentsResolvedToday});
}

/// @nodoc
class _$DashboardMetricsDtoCopyWithImpl<$Res, $Val extends DashboardMetricsDto>
    implements $DashboardMetricsDtoCopyWith<$Res> {
  _$DashboardMetricsDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of DashboardMetricsDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalServicesMonitored = null,
    Object? successfulChecksLastHour = null,
    Object? failedChecksLastHour = null,
    Object? avgCheckDurationMs = null,
    Object? aiAnalysesPerformed = null,
    Object? totalAiCostUsd = null,
    Object? incidentsOpen = null,
    Object? incidentsResolvedToday = null,
  }) {
    return _then(_value.copyWith(
      totalServicesMonitored: null == totalServicesMonitored
          ? _value.totalServicesMonitored
          : totalServicesMonitored // ignore: cast_nullable_to_non_nullable
              as int,
      successfulChecksLastHour: null == successfulChecksLastHour
          ? _value.successfulChecksLastHour
          : successfulChecksLastHour // ignore: cast_nullable_to_non_nullable
              as int,
      failedChecksLastHour: null == failedChecksLastHour
          ? _value.failedChecksLastHour
          : failedChecksLastHour // ignore: cast_nullable_to_non_nullable
              as int,
      avgCheckDurationMs: null == avgCheckDurationMs
          ? _value.avgCheckDurationMs
          : avgCheckDurationMs // ignore: cast_nullable_to_non_nullable
              as double,
      aiAnalysesPerformed: null == aiAnalysesPerformed
          ? _value.aiAnalysesPerformed
          : aiAnalysesPerformed // ignore: cast_nullable_to_non_nullable
              as int,
      totalAiCostUsd: null == totalAiCostUsd
          ? _value.totalAiCostUsd
          : totalAiCostUsd // ignore: cast_nullable_to_non_nullable
              as double,
      incidentsOpen: null == incidentsOpen
          ? _value.incidentsOpen
          : incidentsOpen // ignore: cast_nullable_to_non_nullable
              as int,
      incidentsResolvedToday: null == incidentsResolvedToday
          ? _value.incidentsResolvedToday
          : incidentsResolvedToday // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DashboardMetricsDtoImplCopyWith<$Res>
    implements $DashboardMetricsDtoCopyWith<$Res> {
  factory _$$DashboardMetricsDtoImplCopyWith(_$DashboardMetricsDtoImpl value,
          $Res Function(_$DashboardMetricsDtoImpl) then) =
      __$$DashboardMetricsDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int totalServicesMonitored,
      int successfulChecksLastHour,
      int failedChecksLastHour,
      double avgCheckDurationMs,
      int aiAnalysesPerformed,
      double totalAiCostUsd,
      int incidentsOpen,
      int incidentsResolvedToday});
}

/// @nodoc
class __$$DashboardMetricsDtoImplCopyWithImpl<$Res>
    extends _$DashboardMetricsDtoCopyWithImpl<$Res, _$DashboardMetricsDtoImpl>
    implements _$$DashboardMetricsDtoImplCopyWith<$Res> {
  __$$DashboardMetricsDtoImplCopyWithImpl(_$DashboardMetricsDtoImpl _value,
      $Res Function(_$DashboardMetricsDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of DashboardMetricsDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? totalServicesMonitored = null,
    Object? successfulChecksLastHour = null,
    Object? failedChecksLastHour = null,
    Object? avgCheckDurationMs = null,
    Object? aiAnalysesPerformed = null,
    Object? totalAiCostUsd = null,
    Object? incidentsOpen = null,
    Object? incidentsResolvedToday = null,
  }) {
    return _then(_$DashboardMetricsDtoImpl(
      totalServicesMonitored: null == totalServicesMonitored
          ? _value.totalServicesMonitored
          : totalServicesMonitored // ignore: cast_nullable_to_non_nullable
              as int,
      successfulChecksLastHour: null == successfulChecksLastHour
          ? _value.successfulChecksLastHour
          : successfulChecksLastHour // ignore: cast_nullable_to_non_nullable
              as int,
      failedChecksLastHour: null == failedChecksLastHour
          ? _value.failedChecksLastHour
          : failedChecksLastHour // ignore: cast_nullable_to_non_nullable
              as int,
      avgCheckDurationMs: null == avgCheckDurationMs
          ? _value.avgCheckDurationMs
          : avgCheckDurationMs // ignore: cast_nullable_to_non_nullable
              as double,
      aiAnalysesPerformed: null == aiAnalysesPerformed
          ? _value.aiAnalysesPerformed
          : aiAnalysesPerformed // ignore: cast_nullable_to_non_nullable
              as int,
      totalAiCostUsd: null == totalAiCostUsd
          ? _value.totalAiCostUsd
          : totalAiCostUsd // ignore: cast_nullable_to_non_nullable
              as double,
      incidentsOpen: null == incidentsOpen
          ? _value.incidentsOpen
          : incidentsOpen // ignore: cast_nullable_to_non_nullable
              as int,
      incidentsResolvedToday: null == incidentsResolvedToday
          ? _value.incidentsResolvedToday
          : incidentsResolvedToday // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DashboardMetricsDtoImpl extends _DashboardMetricsDto {
  const _$DashboardMetricsDtoImpl(
      {required this.totalServicesMonitored,
      required this.successfulChecksLastHour,
      required this.failedChecksLastHour,
      required this.avgCheckDurationMs,
      required this.aiAnalysesPerformed,
      required this.totalAiCostUsd,
      required this.incidentsOpen,
      required this.incidentsResolvedToday})
      : super._();

  factory _$DashboardMetricsDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$DashboardMetricsDtoImplFromJson(json);

  @override
  final int totalServicesMonitored;
  @override
  final int successfulChecksLastHour;
  @override
  final int failedChecksLastHour;
  @override
  final double avgCheckDurationMs;
  @override
  final int aiAnalysesPerformed;
  @override
  final double totalAiCostUsd;
  @override
  final int incidentsOpen;
  @override
  final int incidentsResolvedToday;

  @override
  String toString() {
    return 'DashboardMetricsDto(totalServicesMonitored: $totalServicesMonitored, successfulChecksLastHour: $successfulChecksLastHour, failedChecksLastHour: $failedChecksLastHour, avgCheckDurationMs: $avgCheckDurationMs, aiAnalysesPerformed: $aiAnalysesPerformed, totalAiCostUsd: $totalAiCostUsd, incidentsOpen: $incidentsOpen, incidentsResolvedToday: $incidentsResolvedToday)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DashboardMetricsDtoImpl &&
            (identical(other.totalServicesMonitored, totalServicesMonitored) ||
                other.totalServicesMonitored == totalServicesMonitored) &&
            (identical(
                    other.successfulChecksLastHour, successfulChecksLastHour) ||
                other.successfulChecksLastHour == successfulChecksLastHour) &&
            (identical(other.failedChecksLastHour, failedChecksLastHour) ||
                other.failedChecksLastHour == failedChecksLastHour) &&
            (identical(other.avgCheckDurationMs, avgCheckDurationMs) ||
                other.avgCheckDurationMs == avgCheckDurationMs) &&
            (identical(other.aiAnalysesPerformed, aiAnalysesPerformed) ||
                other.aiAnalysesPerformed == aiAnalysesPerformed) &&
            (identical(other.totalAiCostUsd, totalAiCostUsd) ||
                other.totalAiCostUsd == totalAiCostUsd) &&
            (identical(other.incidentsOpen, incidentsOpen) ||
                other.incidentsOpen == incidentsOpen) &&
            (identical(other.incidentsResolvedToday, incidentsResolvedToday) ||
                other.incidentsResolvedToday == incidentsResolvedToday));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      totalServicesMonitored,
      successfulChecksLastHour,
      failedChecksLastHour,
      avgCheckDurationMs,
      aiAnalysesPerformed,
      totalAiCostUsd,
      incidentsOpen,
      incidentsResolvedToday);

  /// Create a copy of DashboardMetricsDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$DashboardMetricsDtoImplCopyWith<_$DashboardMetricsDtoImpl> get copyWith =>
      __$$DashboardMetricsDtoImplCopyWithImpl<_$DashboardMetricsDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DashboardMetricsDtoImplToJson(
      this,
    );
  }
}

abstract class _DashboardMetricsDto extends DashboardMetricsDto {
  const factory _DashboardMetricsDto(
      {required final int totalServicesMonitored,
      required final int successfulChecksLastHour,
      required final int failedChecksLastHour,
      required final double avgCheckDurationMs,
      required final int aiAnalysesPerformed,
      required final double totalAiCostUsd,
      required final int incidentsOpen,
      required final int incidentsResolvedToday}) = _$DashboardMetricsDtoImpl;
  const _DashboardMetricsDto._() : super._();

  factory _DashboardMetricsDto.fromJson(Map<String, dynamic> json) =
      _$DashboardMetricsDtoImpl.fromJson;

  @override
  int get totalServicesMonitored;
  @override
  int get successfulChecksLastHour;
  @override
  int get failedChecksLastHour;
  @override
  double get avgCheckDurationMs;
  @override
  int get aiAnalysesPerformed;
  @override
  double get totalAiCostUsd;
  @override
  int get incidentsOpen;
  @override
  int get incidentsResolvedToday;

  /// Create a copy of DashboardMetricsDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$DashboardMetricsDtoImplCopyWith<_$DashboardMetricsDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
