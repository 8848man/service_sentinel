// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'subscription_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

SubscriptionDto _$SubscriptionDtoFromJson(Map<String, dynamic> json) {
  return _SubscriptionDto.fromJson(json);
}

/// @nodoc
mixin _$SubscriptionDto {
  int get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'user_id')
  int get userId => throw _privateConstructorUsedError;
  String get plan => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  @JsonKey(name: 'started_at')
  String get startedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'expires_at')
  String? get expiresAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'previous_plan')
  String? get previousPlan => throw _privateConstructorUsedError;
  @JsonKey(name: 'plan_changed_at')
  String? get planChangedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'monitoring_suspended_at')
  String? get monitoringSuspendedAt => throw _privateConstructorUsedError;

  /// Serializes this SubscriptionDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of SubscriptionDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $SubscriptionDtoCopyWith<SubscriptionDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubscriptionDtoCopyWith<$Res> {
  factory $SubscriptionDtoCopyWith(
          SubscriptionDto value, $Res Function(SubscriptionDto) then) =
      _$SubscriptionDtoCopyWithImpl<$Res, SubscriptionDto>;
  @useResult
  $Res call(
      {int id,
      @JsonKey(name: 'user_id') int userId,
      String plan,
      String status,
      @JsonKey(name: 'started_at') String startedAt,
      @JsonKey(name: 'expires_at') String? expiresAt,
      @JsonKey(name: 'previous_plan') String? previousPlan,
      @JsonKey(name: 'plan_changed_at') String? planChangedAt,
      @JsonKey(name: 'monitoring_suspended_at') String? monitoringSuspendedAt});
}

/// @nodoc
class _$SubscriptionDtoCopyWithImpl<$Res, $Val extends SubscriptionDto>
    implements $SubscriptionDtoCopyWith<$Res> {
  _$SubscriptionDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of SubscriptionDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? userId = null,
    Object? plan = null,
    Object? status = null,
    Object? startedAt = null,
    Object? expiresAt = freezed,
    Object? previousPlan = freezed,
    Object? planChangedAt = freezed,
    Object? monitoringSuspendedAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      userId: null == userId
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as int,
      plan: null == plan
          ? _value.plan
          : plan // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      startedAt: null == startedAt
          ? _value.startedAt
          : startedAt // ignore: cast_nullable_to_non_nullable
              as String,
      expiresAt: freezed == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as String?,
      previousPlan: freezed == previousPlan
          ? _value.previousPlan
          : previousPlan // ignore: cast_nullable_to_non_nullable
              as String?,
      planChangedAt: freezed == planChangedAt
          ? _value.planChangedAt
          : planChangedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      monitoringSuspendedAt: freezed == monitoringSuspendedAt
          ? _value.monitoringSuspendedAt
          : monitoringSuspendedAt // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SubscriptionDtoImplCopyWith<$Res>
    implements $SubscriptionDtoCopyWith<$Res> {
  factory _$$SubscriptionDtoImplCopyWith(_$SubscriptionDtoImpl value,
          $Res Function(_$SubscriptionDtoImpl) then) =
      __$$SubscriptionDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int id,
      @JsonKey(name: 'user_id') int userId,
      String plan,
      String status,
      @JsonKey(name: 'started_at') String startedAt,
      @JsonKey(name: 'expires_at') String? expiresAt,
      @JsonKey(name: 'previous_plan') String? previousPlan,
      @JsonKey(name: 'plan_changed_at') String? planChangedAt,
      @JsonKey(name: 'monitoring_suspended_at') String? monitoringSuspendedAt});
}

/// @nodoc
class __$$SubscriptionDtoImplCopyWithImpl<$Res>
    extends _$SubscriptionDtoCopyWithImpl<$Res, _$SubscriptionDtoImpl>
    implements _$$SubscriptionDtoImplCopyWith<$Res> {
  __$$SubscriptionDtoImplCopyWithImpl(
      _$SubscriptionDtoImpl _value, $Res Function(_$SubscriptionDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of SubscriptionDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? userId = null,
    Object? plan = null,
    Object? status = null,
    Object? startedAt = null,
    Object? expiresAt = freezed,
    Object? previousPlan = freezed,
    Object? planChangedAt = freezed,
    Object? monitoringSuspendedAt = freezed,
  }) {
    return _then(_$SubscriptionDtoImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      userId: null == userId
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as int,
      plan: null == plan
          ? _value.plan
          : plan // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      startedAt: null == startedAt
          ? _value.startedAt
          : startedAt // ignore: cast_nullable_to_non_nullable
              as String,
      expiresAt: freezed == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as String?,
      previousPlan: freezed == previousPlan
          ? _value.previousPlan
          : previousPlan // ignore: cast_nullable_to_non_nullable
              as String?,
      planChangedAt: freezed == planChangedAt
          ? _value.planChangedAt
          : planChangedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      monitoringSuspendedAt: freezed == monitoringSuspendedAt
          ? _value.monitoringSuspendedAt
          : monitoringSuspendedAt // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SubscriptionDtoImpl extends _SubscriptionDto {
  const _$SubscriptionDtoImpl(
      {required this.id,
      @JsonKey(name: 'user_id') required this.userId,
      required this.plan,
      required this.status,
      @JsonKey(name: 'started_at') required this.startedAt,
      @JsonKey(name: 'expires_at') this.expiresAt,
      @JsonKey(name: 'previous_plan') this.previousPlan,
      @JsonKey(name: 'plan_changed_at') this.planChangedAt,
      @JsonKey(name: 'monitoring_suspended_at') this.monitoringSuspendedAt})
      : super._();

  factory _$SubscriptionDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$SubscriptionDtoImplFromJson(json);

  @override
  final int id;
  @override
  @JsonKey(name: 'user_id')
  final int userId;
  @override
  final String plan;
  @override
  final String status;
  @override
  @JsonKey(name: 'started_at')
  final String startedAt;
  @override
  @JsonKey(name: 'expires_at')
  final String? expiresAt;
  @override
  @JsonKey(name: 'previous_plan')
  final String? previousPlan;
  @override
  @JsonKey(name: 'plan_changed_at')
  final String? planChangedAt;
  @override
  @JsonKey(name: 'monitoring_suspended_at')
  final String? monitoringSuspendedAt;

  @override
  String toString() {
    return 'SubscriptionDto(id: $id, userId: $userId, plan: $plan, status: $status, startedAt: $startedAt, expiresAt: $expiresAt, previousPlan: $previousPlan, planChangedAt: $planChangedAt, monitoringSuspendedAt: $monitoringSuspendedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubscriptionDtoImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.userId, userId) || other.userId == userId) &&
            (identical(other.plan, plan) || other.plan == plan) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.startedAt, startedAt) ||
                other.startedAt == startedAt) &&
            (identical(other.expiresAt, expiresAt) ||
                other.expiresAt == expiresAt) &&
            (identical(other.previousPlan, previousPlan) ||
                other.previousPlan == previousPlan) &&
            (identical(other.planChangedAt, planChangedAt) ||
                other.planChangedAt == planChangedAt) &&
            (identical(other.monitoringSuspendedAt, monitoringSuspendedAt) ||
                other.monitoringSuspendedAt == monitoringSuspendedAt));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, id, userId, plan, status,
      startedAt, expiresAt, previousPlan, planChangedAt, monitoringSuspendedAt);

  /// Create a copy of SubscriptionDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$SubscriptionDtoImplCopyWith<_$SubscriptionDtoImpl> get copyWith =>
      __$$SubscriptionDtoImplCopyWithImpl<_$SubscriptionDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SubscriptionDtoImplToJson(
      this,
    );
  }
}

abstract class _SubscriptionDto extends SubscriptionDto {
  const factory _SubscriptionDto(
      {required final int id,
      @JsonKey(name: 'user_id') required final int userId,
      required final String plan,
      required final String status,
      @JsonKey(name: 'started_at') required final String startedAt,
      @JsonKey(name: 'expires_at') final String? expiresAt,
      @JsonKey(name: 'previous_plan') final String? previousPlan,
      @JsonKey(name: 'plan_changed_at') final String? planChangedAt,
      @JsonKey(name: 'monitoring_suspended_at')
      final String? monitoringSuspendedAt}) = _$SubscriptionDtoImpl;
  const _SubscriptionDto._() : super._();

  factory _SubscriptionDto.fromJson(Map<String, dynamic> json) =
      _$SubscriptionDtoImpl.fromJson;

  @override
  int get id;
  @override
  @JsonKey(name: 'user_id')
  int get userId;
  @override
  String get plan;
  @override
  String get status;
  @override
  @JsonKey(name: 'started_at')
  String get startedAt;
  @override
  @JsonKey(name: 'expires_at')
  String? get expiresAt;
  @override
  @JsonKey(name: 'previous_plan')
  String? get previousPlan;
  @override
  @JsonKey(name: 'plan_changed_at')
  String? get planChangedAt;
  @override
  @JsonKey(name: 'monitoring_suspended_at')
  String? get monitoringSuspendedAt;

  /// Create a copy of SubscriptionDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$SubscriptionDtoImplCopyWith<_$SubscriptionDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
