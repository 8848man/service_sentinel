// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'subscription_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SubscriptionDtoImpl _$$SubscriptionDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$SubscriptionDtoImpl(
      id: (json['id'] as num).toInt(),
      userId: (json['user_id'] as num).toInt(),
      plan: json['plan'] as String,
      status: json['status'] as String,
      startedAt: json['started_at'] as String,
      expiresAt: json['expires_at'] as String?,
      previousPlan: json['previous_plan'] as String?,
      planChangedAt: json['plan_changed_at'] as String?,
      monitoringSuspendedAt: json['monitoring_suspended_at'] as String?,
    );

Map<String, dynamic> _$$SubscriptionDtoImplToJson(
        _$SubscriptionDtoImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'user_id': instance.userId,
      'plan': instance.plan,
      'status': instance.status,
      'started_at': instance.startedAt,
      'expires_at': instance.expiresAt,
      'previous_plan': instance.previousPlan,
      'plan_changed_at': instance.planChangedAt,
      'monitoring_suspended_at': instance.monitoringSuspendedAt,
    };
