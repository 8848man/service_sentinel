// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'subscription.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$Subscription {
  int get id => throw _privateConstructorUsedError;
  int get userId => throw _privateConstructorUsedError;
  String get plan => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  DateTime get startedAt => throw _privateConstructorUsedError;
  DateTime? get expiresAt => throw _privateConstructorUsedError;
  String? get previousPlan => throw _privateConstructorUsedError;
  DateTime? get planChangedAt => throw _privateConstructorUsedError;
  DateTime? get monitoringSuspendedAt => throw _privateConstructorUsedError;

  /// Create a copy of Subscription
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $SubscriptionCopyWith<Subscription> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SubscriptionCopyWith<$Res> {
  factory $SubscriptionCopyWith(
          Subscription value, $Res Function(Subscription) then) =
      _$SubscriptionCopyWithImpl<$Res, Subscription>;
  @useResult
  $Res call(
      {int id,
      int userId,
      String plan,
      String status,
      DateTime startedAt,
      DateTime? expiresAt,
      String? previousPlan,
      DateTime? planChangedAt,
      DateTime? monitoringSuspendedAt});
}

/// @nodoc
class _$SubscriptionCopyWithImpl<$Res, $Val extends Subscription>
    implements $SubscriptionCopyWith<$Res> {
  _$SubscriptionCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of Subscription
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? userId = null,
    Object? plan = null,
    Object? status = null,
    Object? startedAt = null,
    Object? expiresAt = freezed,
    Object? previousPlan = freezed,
    Object? planChangedAt = freezed,
    Object? monitoringSuspendedAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      userId: null == userId
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as int,
      plan: null == plan
          ? _value.plan
          : plan // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      startedAt: null == startedAt
          ? _value.startedAt
          : startedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      expiresAt: freezed == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      previousPlan: freezed == previousPlan
          ? _value.previousPlan
          : previousPlan // ignore: cast_nullable_to_non_nullable
              as String?,
      planChangedAt: freezed == planChangedAt
          ? _value.planChangedAt
          : planChangedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      monitoringSuspendedAt: freezed == monitoringSuspendedAt
          ? _value.monitoringSuspendedAt
          : monitoringSuspendedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SubscriptionImplCopyWith<$Res>
    implements $SubscriptionCopyWith<$Res> {
  factory _$$SubscriptionImplCopyWith(
          _$SubscriptionImpl value, $Res Function(_$SubscriptionImpl) then) =
      __$$SubscriptionImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int id,
      int userId,
      String plan,
      String status,
      DateTime startedAt,
      DateTime? expiresAt,
      String? previousPlan,
      DateTime? planChangedAt,
      DateTime? monitoringSuspendedAt});
}

/// @nodoc
class __$$SubscriptionImplCopyWithImpl<$Res>
    extends _$SubscriptionCopyWithImpl<$Res, _$SubscriptionImpl>
    implements _$$SubscriptionImplCopyWith<$Res> {
  __$$SubscriptionImplCopyWithImpl(
      _$SubscriptionImpl _value, $Res Function(_$SubscriptionImpl) _then)
      : super(_value, _then);

  /// Create a copy of Subscription
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? userId = null,
    Object? plan = null,
    Object? status = null,
    Object? startedAt = null,
    Object? expiresAt = freezed,
    Object? previousPlan = freezed,
    Object? planChangedAt = freezed,
    Object? monitoringSuspendedAt = freezed,
  }) {
    return _then(_$SubscriptionImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      userId: null == userId
          ? _value.userId
          : userId // ignore: cast_nullable_to_non_nullable
              as int,
      plan: null == plan
          ? _value.plan
          : plan // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      startedAt: null == startedAt
          ? _value.startedAt
          : startedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      expiresAt: freezed == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      previousPlan: freezed == previousPlan
          ? _value.previousPlan
          : previousPlan // ignore: cast_nullable_to_non_nullable
              as String?,
      planChangedAt: freezed == planChangedAt
          ? _value.planChangedAt
          : planChangedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      monitoringSuspendedAt: freezed == monitoringSuspendedAt
          ? _value.monitoringSuspendedAt
          : monitoringSuspendedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$SubscriptionImpl extends _Subscription {
  const _$SubscriptionImpl(
      {required this.id,
      required this.userId,
      required this.plan,
      required this.status,
      required this.startedAt,
      this.expiresAt,
      this.previousPlan,
      this.planChangedAt,
      this.monitoringSuspendedAt})
      : super._();

  @override
  final int id;
  @override
  final int userId;
  @override
  final String plan;
  @override
  final String status;
  @override
  final DateTime startedAt;
  @override
  final DateTime? expiresAt;
  @override
  final String? previousPlan;
  @override
  final DateTime? planChangedAt;
  @override
  final DateTime? monitoringSuspendedAt;

  @override
  String toString() {
    return 'Subscription(id: $id, userId: $userId, plan: $plan, status: $status, startedAt: $startedAt, expiresAt: $expiresAt, previousPlan: $previousPlan, planChangedAt: $planChangedAt, monitoringSuspendedAt: $monitoringSuspendedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SubscriptionImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.userId, userId) || other.userId == userId) &&
            (identical(other.plan, plan) || other.plan == plan) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.startedAt, startedAt) ||
                other.startedAt == startedAt) &&
            (identical(other.expiresAt, expiresAt) ||
                other.expiresAt == expiresAt) &&
            (identical(other.previousPlan, previousPlan) ||
                other.previousPlan == previousPlan) &&
            (identical(other.planChangedAt, planChangedAt) ||
                other.planChangedAt == planChangedAt) &&
            (identical(other.monitoringSuspendedAt, monitoringSuspendedAt) ||
                other.monitoringSuspendedAt == monitoringSuspendedAt));
  }

  @override
  int get hashCode => Object.hash(runtimeType, id, userId, plan, status,
      startedAt, expiresAt, previousPlan, planChangedAt, monitoringSuspendedAt);

  /// Create a copy of Subscription
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$SubscriptionImplCopyWith<_$SubscriptionImpl> get copyWith =>
      __$$SubscriptionImplCopyWithImpl<_$SubscriptionImpl>(this, _$identity);
}

abstract class _Subscription extends Subscription {
  const factory _Subscription(
      {required final int id,
      required final int userId,
      required final String plan,
      required final String status,
      required final DateTime startedAt,
      final DateTime? expiresAt,
      final String? previousPlan,
      final DateTime? planChangedAt,
      final DateTime? monitoringSuspendedAt}) = _$SubscriptionImpl;
  const _Subscription._() : super._();

  @override
  int get id;
  @override
  int get userId;
  @override
  String get plan;
  @override
  String get status;
  @override
  DateTime get startedAt;
  @override
  DateTime? get expiresAt;
  @override
  String? get previousPlan;
  @override
  DateTime? get planChangedAt;
  @override
  DateTime? get monitoringSuspendedAt;

  /// Create a copy of Subscription
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$SubscriptionImplCopyWith<_$SubscriptionImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
