// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'service_stats_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ServiceStatsDtoImpl _$$ServiceStatsDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ServiceStatsDtoImpl(
      serviceId: json['service_id'] as String,
      uptimePercentage: (json['uptime_percentage'] as num).toDouble(),
      totalChecks: (json['total_checks'] as num).toInt(),
      successfulChecks: (json['successful_checks'] as num).toInt(),
      failedChecks: (json['failed_checks'] as num).toInt(),
      averageLatencyMs: (json['average_latency_ms'] as num).toDouble(),
    );

Map<String, dynamic> _$$ServiceStatsDtoImplToJson(
        _$ServiceStatsDtoImpl instance) =>
    <String, dynamic>{
      'service_id': instance.serviceId,
      'uptime_percentage': instance.uptimePercentage,
      'total_checks': instance.totalChecks,
      'successful_checks': instance.successfulChecks,
      'failed_checks': instance.failedChecks,
      'average_latency_ms': instance.averageLatencyMs,
    };
