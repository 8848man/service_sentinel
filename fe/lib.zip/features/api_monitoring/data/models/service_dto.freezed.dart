// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'service_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ServiceDto _$ServiceDtoFromJson(Map<String, dynamic> json) {
  return _ServiceDto.fromJson(json);
}

/// @nodoc
mixin _$ServiceDto {
  int get id => throw _privateConstructorUsedError; // 🔥 String → int
  @JsonKey(name: 'project_id')
  int? get projectId => throw _privateConstructorUsedError; // 🔥 nullable
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  @JsonKey(name: 'endpoint_url')
  String get endpointUrl => throw _privateConstructorUsedError;
  @JsonKey(name: 'http_method')
  String get httpMethod => throw _privateConstructorUsedError;
  @JsonKey(name: 'service_type')
  String get serviceType => throw _privateConstructorUsedError;
  Map<String, String>? get headers =>
      throw _privateConstructorUsedError; // 🔥 안전하게
  @JsonKey(name: 'request_body')
  String? get requestBody => throw _privateConstructorUsedError;
  @JsonKey(name: 'expected_status_codes')
  List<int> get expectedStatusCodes => throw _privateConstructorUsedError;
  @JsonKey(name: 'timeout_seconds')
  int get timeoutSeconds => throw _privateConstructorUsedError;
  @JsonKey(name: 'check_interval_seconds')
  int get checkIntervalSeconds => throw _privateConstructorUsedError;
  @JsonKey(name: 'failure_threshold')
  int get failureThreshold => throw _privateConstructorUsedError;
  @JsonKey(name: 'is_active')
  bool get isActive => throw _privateConstructorUsedError;
  @JsonKey(name: 'service_state')
  String? get serviceState => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_at')
  String get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'updated_at')
  String get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'last_checked_at')
  String? get lastCheckedAt => throw _privateConstructorUsedError;

  /// Serializes this ServiceDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ServiceDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ServiceDtoCopyWith<ServiceDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceDtoCopyWith<$Res> {
  factory $ServiceDtoCopyWith(
          ServiceDto value, $Res Function(ServiceDto) then) =
      _$ServiceDtoCopyWithImpl<$Res, ServiceDto>;
  @useResult
  $Res call(
      {int id,
      @JsonKey(name: 'project_id') int? projectId,
      String name,
      String? description,
      @JsonKey(name: 'endpoint_url') String endpointUrl,
      @JsonKey(name: 'http_method') String httpMethod,
      @JsonKey(name: 'service_type') String serviceType,
      Map<String, String>? headers,
      @JsonKey(name: 'request_body') String? requestBody,
      @JsonKey(name: 'expected_status_codes') List<int> expectedStatusCodes,
      @JsonKey(name: 'timeout_seconds') int timeoutSeconds,
      @JsonKey(name: 'check_interval_seconds') int checkIntervalSeconds,
      @JsonKey(name: 'failure_threshold') int failureThreshold,
      @JsonKey(name: 'is_active') bool isActive,
      @JsonKey(name: 'service_state') String? serviceState,
      @JsonKey(name: 'created_at') String createdAt,
      @JsonKey(name: 'updated_at') String updatedAt,
      @JsonKey(name: 'last_checked_at') String? lastCheckedAt});
}

/// @nodoc
class _$ServiceDtoCopyWithImpl<$Res, $Val extends ServiceDto>
    implements $ServiceDtoCopyWith<$Res> {
  _$ServiceDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ServiceDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? projectId = freezed,
    Object? name = null,
    Object? description = freezed,
    Object? endpointUrl = null,
    Object? httpMethod = null,
    Object? serviceType = null,
    Object? headers = freezed,
    Object? requestBody = freezed,
    Object? expectedStatusCodes = null,
    Object? timeoutSeconds = null,
    Object? checkIntervalSeconds = null,
    Object? failureThreshold = null,
    Object? isActive = null,
    Object? serviceState = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
    Object? lastCheckedAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      projectId: freezed == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as int?,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      endpointUrl: null == endpointUrl
          ? _value.endpointUrl
          : endpointUrl // ignore: cast_nullable_to_non_nullable
              as String,
      httpMethod: null == httpMethod
          ? _value.httpMethod
          : httpMethod // ignore: cast_nullable_to_non_nullable
              as String,
      serviceType: null == serviceType
          ? _value.serviceType
          : serviceType // ignore: cast_nullable_to_non_nullable
              as String,
      headers: freezed == headers
          ? _value.headers
          : headers // ignore: cast_nullable_to_non_nullable
              as Map<String, String>?,
      requestBody: freezed == requestBody
          ? _value.requestBody
          : requestBody // ignore: cast_nullable_to_non_nullable
              as String?,
      expectedStatusCodes: null == expectedStatusCodes
          ? _value.expectedStatusCodes
          : expectedStatusCodes // ignore: cast_nullable_to_non_nullable
              as List<int>,
      timeoutSeconds: null == timeoutSeconds
          ? _value.timeoutSeconds
          : timeoutSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      checkIntervalSeconds: null == checkIntervalSeconds
          ? _value.checkIntervalSeconds
          : checkIntervalSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      failureThreshold: null == failureThreshold
          ? _value.failureThreshold
          : failureThreshold // ignore: cast_nullable_to_non_nullable
              as int,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      serviceState: freezed == serviceState
          ? _value.serviceState
          : serviceState // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String,
      lastCheckedAt: freezed == lastCheckedAt
          ? _value.lastCheckedAt
          : lastCheckedAt // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ServiceDtoImplCopyWith<$Res>
    implements $ServiceDtoCopyWith<$Res> {
  factory _$$ServiceDtoImplCopyWith(
          _$ServiceDtoImpl value, $Res Function(_$ServiceDtoImpl) then) =
      __$$ServiceDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int id,
      @JsonKey(name: 'project_id') int? projectId,
      String name,
      String? description,
      @JsonKey(name: 'endpoint_url') String endpointUrl,
      @JsonKey(name: 'http_method') String httpMethod,
      @JsonKey(name: 'service_type') String serviceType,
      Map<String, String>? headers,
      @JsonKey(name: 'request_body') String? requestBody,
      @JsonKey(name: 'expected_status_codes') List<int> expectedStatusCodes,
      @JsonKey(name: 'timeout_seconds') int timeoutSeconds,
      @JsonKey(name: 'check_interval_seconds') int checkIntervalSeconds,
      @JsonKey(name: 'failure_threshold') int failureThreshold,
      @JsonKey(name: 'is_active') bool isActive,
      @JsonKey(name: 'service_state') String? serviceState,
      @JsonKey(name: 'created_at') String createdAt,
      @JsonKey(name: 'updated_at') String updatedAt,
      @JsonKey(name: 'last_checked_at') String? lastCheckedAt});
}

/// @nodoc
class __$$ServiceDtoImplCopyWithImpl<$Res>
    extends _$ServiceDtoCopyWithImpl<$Res, _$ServiceDtoImpl>
    implements _$$ServiceDtoImplCopyWith<$Res> {
  __$$ServiceDtoImplCopyWithImpl(
      _$ServiceDtoImpl _value, $Res Function(_$ServiceDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of ServiceDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? projectId = freezed,
    Object? name = null,
    Object? description = freezed,
    Object? endpointUrl = null,
    Object? httpMethod = null,
    Object? serviceType = null,
    Object? headers = freezed,
    Object? requestBody = freezed,
    Object? expectedStatusCodes = null,
    Object? timeoutSeconds = null,
    Object? checkIntervalSeconds = null,
    Object? failureThreshold = null,
    Object? isActive = null,
    Object? serviceState = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
    Object? lastCheckedAt = freezed,
  }) {
    return _then(_$ServiceDtoImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      projectId: freezed == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as int?,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      endpointUrl: null == endpointUrl
          ? _value.endpointUrl
          : endpointUrl // ignore: cast_nullable_to_non_nullable
              as String,
      httpMethod: null == httpMethod
          ? _value.httpMethod
          : httpMethod // ignore: cast_nullable_to_non_nullable
              as String,
      serviceType: null == serviceType
          ? _value.serviceType
          : serviceType // ignore: cast_nullable_to_non_nullable
              as String,
      headers: freezed == headers
          ? _value._headers
          : headers // ignore: cast_nullable_to_non_nullable
              as Map<String, String>?,
      requestBody: freezed == requestBody
          ? _value.requestBody
          : requestBody // ignore: cast_nullable_to_non_nullable
              as String?,
      expectedStatusCodes: null == expectedStatusCodes
          ? _value._expectedStatusCodes
          : expectedStatusCodes // ignore: cast_nullable_to_non_nullable
              as List<int>,
      timeoutSeconds: null == timeoutSeconds
          ? _value.timeoutSeconds
          : timeoutSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      checkIntervalSeconds: null == checkIntervalSeconds
          ? _value.checkIntervalSeconds
          : checkIntervalSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      failureThreshold: null == failureThreshold
          ? _value.failureThreshold
          : failureThreshold // ignore: cast_nullable_to_non_nullable
              as int,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      serviceState: freezed == serviceState
          ? _value.serviceState
          : serviceState // ignore: cast_nullable_to_non_nullable
              as String?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String,
      lastCheckedAt: freezed == lastCheckedAt
          ? _value.lastCheckedAt
          : lastCheckedAt // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ServiceDtoImpl extends _ServiceDto {
  const _$ServiceDtoImpl(
      {required this.id,
      @JsonKey(name: 'project_id') this.projectId,
      required this.name,
      this.description,
      @JsonKey(name: 'endpoint_url') required this.endpointUrl,
      @JsonKey(name: 'http_method') required this.httpMethod,
      @JsonKey(name: 'service_type') required this.serviceType,
      final Map<String, String>? headers,
      @JsonKey(name: 'request_body') this.requestBody,
      @JsonKey(name: 'expected_status_codes')
      required final List<int> expectedStatusCodes,
      @JsonKey(name: 'timeout_seconds') required this.timeoutSeconds,
      @JsonKey(name: 'check_interval_seconds')
      required this.checkIntervalSeconds,
      @JsonKey(name: 'failure_threshold') required this.failureThreshold,
      @JsonKey(name: 'is_active') required this.isActive,
      @JsonKey(name: 'service_state') this.serviceState,
      @JsonKey(name: 'created_at') required this.createdAt,
      @JsonKey(name: 'updated_at') required this.updatedAt,
      @JsonKey(name: 'last_checked_at') this.lastCheckedAt})
      : _headers = headers,
        _expectedStatusCodes = expectedStatusCodes,
        super._();

  factory _$ServiceDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ServiceDtoImplFromJson(json);

  @override
  final int id;
// 🔥 String → int
  @override
  @JsonKey(name: 'project_id')
  final int? projectId;
// 🔥 nullable
  @override
  final String name;
  @override
  final String? description;
  @override
  @JsonKey(name: 'endpoint_url')
  final String endpointUrl;
  @override
  @JsonKey(name: 'http_method')
  final String httpMethod;
  @override
  @JsonKey(name: 'service_type')
  final String serviceType;
  final Map<String, String>? _headers;
  @override
  Map<String, String>? get headers {
    final value = _headers;
    if (value == null) return null;
    if (_headers is EqualUnmodifiableMapView) return _headers;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(value);
  }

// 🔥 안전하게
  @override
  @JsonKey(name: 'request_body')
  final String? requestBody;
  final List<int> _expectedStatusCodes;
  @override
  @JsonKey(name: 'expected_status_codes')
  List<int> get expectedStatusCodes {
    if (_expectedStatusCodes is EqualUnmodifiableListView)
      return _expectedStatusCodes;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_expectedStatusCodes);
  }

  @override
  @JsonKey(name: 'timeout_seconds')
  final int timeoutSeconds;
  @override
  @JsonKey(name: 'check_interval_seconds')
  final int checkIntervalSeconds;
  @override
  @JsonKey(name: 'failure_threshold')
  final int failureThreshold;
  @override
  @JsonKey(name: 'is_active')
  final bool isActive;
  @override
  @JsonKey(name: 'service_state')
  final String? serviceState;
  @override
  @JsonKey(name: 'created_at')
  final String createdAt;
  @override
  @JsonKey(name: 'updated_at')
  final String updatedAt;
  @override
  @JsonKey(name: 'last_checked_at')
  final String? lastCheckedAt;

  @override
  String toString() {
    return 'ServiceDto(id: $id, projectId: $projectId, name: $name, description: $description, endpointUrl: $endpointUrl, httpMethod: $httpMethod, serviceType: $serviceType, headers: $headers, requestBody: $requestBody, expectedStatusCodes: $expectedStatusCodes, timeoutSeconds: $timeoutSeconds, checkIntervalSeconds: $checkIntervalSeconds, failureThreshold: $failureThreshold, isActive: $isActive, serviceState: $serviceState, createdAt: $createdAt, updatedAt: $updatedAt, lastCheckedAt: $lastCheckedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ServiceDtoImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.projectId, projectId) ||
                other.projectId == projectId) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.endpointUrl, endpointUrl) ||
                other.endpointUrl == endpointUrl) &&
            (identical(other.httpMethod, httpMethod) ||
                other.httpMethod == httpMethod) &&
            (identical(other.serviceType, serviceType) ||
                other.serviceType == serviceType) &&
            const DeepCollectionEquality().equals(other._headers, _headers) &&
            (identical(other.requestBody, requestBody) ||
                other.requestBody == requestBody) &&
            const DeepCollectionEquality()
                .equals(other._expectedStatusCodes, _expectedStatusCodes) &&
            (identical(other.timeoutSeconds, timeoutSeconds) ||
                other.timeoutSeconds == timeoutSeconds) &&
            (identical(other.checkIntervalSeconds, checkIntervalSeconds) ||
                other.checkIntervalSeconds == checkIntervalSeconds) &&
            (identical(other.failureThreshold, failureThreshold) ||
                other.failureThreshold == failureThreshold) &&
            (identical(other.isActive, isActive) ||
                other.isActive == isActive) &&
            (identical(other.serviceState, serviceState) ||
                other.serviceState == serviceState) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.lastCheckedAt, lastCheckedAt) ||
                other.lastCheckedAt == lastCheckedAt));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      projectId,
      name,
      description,
      endpointUrl,
      httpMethod,
      serviceType,
      const DeepCollectionEquality().hash(_headers),
      requestBody,
      const DeepCollectionEquality().hash(_expectedStatusCodes),
      timeoutSeconds,
      checkIntervalSeconds,
      failureThreshold,
      isActive,
      serviceState,
      createdAt,
      updatedAt,
      lastCheckedAt);

  /// Create a copy of ServiceDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ServiceDtoImplCopyWith<_$ServiceDtoImpl> get copyWith =>
      __$$ServiceDtoImplCopyWithImpl<_$ServiceDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ServiceDtoImplToJson(
      this,
    );
  }
}

abstract class _ServiceDto extends ServiceDto {
  const factory _ServiceDto(
      {required final int id,
      @JsonKey(name: 'project_id') final int? projectId,
      required final String name,
      final String? description,
      @JsonKey(name: 'endpoint_url') required final String endpointUrl,
      @JsonKey(name: 'http_method') required final String httpMethod,
      @JsonKey(name: 'service_type') required final String serviceType,
      final Map<String, String>? headers,
      @JsonKey(name: 'request_body') final String? requestBody,
      @JsonKey(name: 'expected_status_codes')
      required final List<int> expectedStatusCodes,
      @JsonKey(name: 'timeout_seconds') required final int timeoutSeconds,
      @JsonKey(name: 'check_interval_seconds')
      required final int checkIntervalSeconds,
      @JsonKey(name: 'failure_threshold') required final int failureThreshold,
      @JsonKey(name: 'is_active') required final bool isActive,
      @JsonKey(name: 'service_state') final String? serviceState,
      @JsonKey(name: 'created_at') required final String createdAt,
      @JsonKey(name: 'updated_at') required final String updatedAt,
      @JsonKey(name: 'last_checked_at')
      final String? lastCheckedAt}) = _$ServiceDtoImpl;
  const _ServiceDto._() : super._();

  factory _ServiceDto.fromJson(Map<String, dynamic> json) =
      _$ServiceDtoImpl.fromJson;

  @override
  int get id; // 🔥 String → int
  @override
  @JsonKey(name: 'project_id')
  int? get projectId; // 🔥 nullable
  @override
  String get name;
  @override
  String? get description;
  @override
  @JsonKey(name: 'endpoint_url')
  String get endpointUrl;
  @override
  @JsonKey(name: 'http_method')
  String get httpMethod;
  @override
  @JsonKey(name: 'service_type')
  String get serviceType;
  @override
  Map<String, String>? get headers; // 🔥 안전하게
  @override
  @JsonKey(name: 'request_body')
  String? get requestBody;
  @override
  @JsonKey(name: 'expected_status_codes')
  List<int> get expectedStatusCodes;
  @override
  @JsonKey(name: 'timeout_seconds')
  int get timeoutSeconds;
  @override
  @JsonKey(name: 'check_interval_seconds')
  int get checkIntervalSeconds;
  @override
  @JsonKey(name: 'failure_threshold')
  int get failureThreshold;
  @override
  @JsonKey(name: 'is_active')
  bool get isActive;
  @override
  @JsonKey(name: 'service_state')
  String? get serviceState;
  @override
  @JsonKey(name: 'created_at')
  String get createdAt;
  @override
  @JsonKey(name: 'updated_at')
  String get updatedAt;
  @override
  @JsonKey(name: 'last_checked_at')
  String? get lastCheckedAt;

  /// Create a copy of ServiceDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ServiceDtoImplCopyWith<_$ServiceDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ServiceCreateDto _$ServiceCreateDtoFromJson(Map<String, dynamic> json) {
  return _ServiceCreateDto.fromJson(json);
}

/// @nodoc
mixin _$ServiceCreateDto {
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  @JsonKey(name: 'endpoint_url')
  String get endpointUrl => throw _privateConstructorUsedError;
  @JsonKey(name: 'http_method')
  String get httpMethod => throw _privateConstructorUsedError;
  @JsonKey(name: 'service_type')
  String get serviceType => throw _privateConstructorUsedError;
  Map<String, String>? get headers => throw _privateConstructorUsedError;
  @JsonKey(name: 'request_body')
  String? get requestBody => throw _privateConstructorUsedError;
  @JsonKey(name: 'expected_status_codes')
  List<int> get expectedStatusCodes => throw _privateConstructorUsedError;
  @JsonKey(name: 'timeout_seconds')
  int get timeoutSeconds => throw _privateConstructorUsedError;
  @JsonKey(name: 'check_interval_seconds')
  int get checkIntervalSeconds => throw _privateConstructorUsedError;
  @JsonKey(name: 'failure_threshold')
  int get failureThreshold => throw _privateConstructorUsedError;

  /// Serializes this ServiceCreateDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ServiceCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ServiceCreateDtoCopyWith<ServiceCreateDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceCreateDtoCopyWith<$Res> {
  factory $ServiceCreateDtoCopyWith(
          ServiceCreateDto value, $Res Function(ServiceCreateDto) then) =
      _$ServiceCreateDtoCopyWithImpl<$Res, ServiceCreateDto>;
  @useResult
  $Res call(
      {String name,
      String? description,
      @JsonKey(name: 'endpoint_url') String endpointUrl,
      @JsonKey(name: 'http_method') String httpMethod,
      @JsonKey(name: 'service_type') String serviceType,
      Map<String, String>? headers,
      @JsonKey(name: 'request_body') String? requestBody,
      @JsonKey(name: 'expected_status_codes') List<int> expectedStatusCodes,
      @JsonKey(name: 'timeout_seconds') int timeoutSeconds,
      @JsonKey(name: 'check_interval_seconds') int checkIntervalSeconds,
      @JsonKey(name: 'failure_threshold') int failureThreshold});
}

/// @nodoc
class _$ServiceCreateDtoCopyWithImpl<$Res, $Val extends ServiceCreateDto>
    implements $ServiceCreateDtoCopyWith<$Res> {
  _$ServiceCreateDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ServiceCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
    Object? endpointUrl = null,
    Object? httpMethod = null,
    Object? serviceType = null,
    Object? headers = freezed,
    Object? requestBody = freezed,
    Object? expectedStatusCodes = null,
    Object? timeoutSeconds = null,
    Object? checkIntervalSeconds = null,
    Object? failureThreshold = null,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      endpointUrl: null == endpointUrl
          ? _value.endpointUrl
          : endpointUrl // ignore: cast_nullable_to_non_nullable
              as String,
      httpMethod: null == httpMethod
          ? _value.httpMethod
          : httpMethod // ignore: cast_nullable_to_non_nullable
              as String,
      serviceType: null == serviceType
          ? _value.serviceType
          : serviceType // ignore: cast_nullable_to_non_nullable
              as String,
      headers: freezed == headers
          ? _value.headers
          : headers // ignore: cast_nullable_to_non_nullable
              as Map<String, String>?,
      requestBody: freezed == requestBody
          ? _value.requestBody
          : requestBody // ignore: cast_nullable_to_non_nullable
              as String?,
      expectedStatusCodes: null == expectedStatusCodes
          ? _value.expectedStatusCodes
          : expectedStatusCodes // ignore: cast_nullable_to_non_nullable
              as List<int>,
      timeoutSeconds: null == timeoutSeconds
          ? _value.timeoutSeconds
          : timeoutSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      checkIntervalSeconds: null == checkIntervalSeconds
          ? _value.checkIntervalSeconds
          : checkIntervalSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      failureThreshold: null == failureThreshold
          ? _value.failureThreshold
          : failureThreshold // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ServiceCreateDtoImplCopyWith<$Res>
    implements $ServiceCreateDtoCopyWith<$Res> {
  factory _$$ServiceCreateDtoImplCopyWith(_$ServiceCreateDtoImpl value,
          $Res Function(_$ServiceCreateDtoImpl) then) =
      __$$ServiceCreateDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String name,
      String? description,
      @JsonKey(name: 'endpoint_url') String endpointUrl,
      @JsonKey(name: 'http_method') String httpMethod,
      @JsonKey(name: 'service_type') String serviceType,
      Map<String, String>? headers,
      @JsonKey(name: 'request_body') String? requestBody,
      @JsonKey(name: 'expected_status_codes') List<int> expectedStatusCodes,
      @JsonKey(name: 'timeout_seconds') int timeoutSeconds,
      @JsonKey(name: 'check_interval_seconds') int checkIntervalSeconds,
      @JsonKey(name: 'failure_threshold') int failureThreshold});
}

/// @nodoc
class __$$ServiceCreateDtoImplCopyWithImpl<$Res>
    extends _$ServiceCreateDtoCopyWithImpl<$Res, _$ServiceCreateDtoImpl>
    implements _$$ServiceCreateDtoImplCopyWith<$Res> {
  __$$ServiceCreateDtoImplCopyWithImpl(_$ServiceCreateDtoImpl _value,
      $Res Function(_$ServiceCreateDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of ServiceCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
    Object? endpointUrl = null,
    Object? httpMethod = null,
    Object? serviceType = null,
    Object? headers = freezed,
    Object? requestBody = freezed,
    Object? expectedStatusCodes = null,
    Object? timeoutSeconds = null,
    Object? checkIntervalSeconds = null,
    Object? failureThreshold = null,
  }) {
    return _then(_$ServiceCreateDtoImpl(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      endpointUrl: null == endpointUrl
          ? _value.endpointUrl
          : endpointUrl // ignore: cast_nullable_to_non_nullable
              as String,
      httpMethod: null == httpMethod
          ? _value.httpMethod
          : httpMethod // ignore: cast_nullable_to_non_nullable
              as String,
      serviceType: null == serviceType
          ? _value.serviceType
          : serviceType // ignore: cast_nullable_to_non_nullable
              as String,
      headers: freezed == headers
          ? _value._headers
          : headers // ignore: cast_nullable_to_non_nullable
              as Map<String, String>?,
      requestBody: freezed == requestBody
          ? _value.requestBody
          : requestBody // ignore: cast_nullable_to_non_nullable
              as String?,
      expectedStatusCodes: null == expectedStatusCodes
          ? _value._expectedStatusCodes
          : expectedStatusCodes // ignore: cast_nullable_to_non_nullable
              as List<int>,
      timeoutSeconds: null == timeoutSeconds
          ? _value.timeoutSeconds
          : timeoutSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      checkIntervalSeconds: null == checkIntervalSeconds
          ? _value.checkIntervalSeconds
          : checkIntervalSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      failureThreshold: null == failureThreshold
          ? _value.failureThreshold
          : failureThreshold // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ServiceCreateDtoImpl implements _ServiceCreateDto {
  const _$ServiceCreateDtoImpl(
      {required this.name,
      this.description,
      @JsonKey(name: 'endpoint_url') required this.endpointUrl,
      @JsonKey(name: 'http_method') required this.httpMethod,
      @JsonKey(name: 'service_type') required this.serviceType,
      final Map<String, String>? headers,
      @JsonKey(name: 'request_body') this.requestBody,
      @JsonKey(name: 'expected_status_codes')
      required final List<int> expectedStatusCodes,
      @JsonKey(name: 'timeout_seconds') required this.timeoutSeconds,
      @JsonKey(name: 'check_interval_seconds')
      required this.checkIntervalSeconds,
      @JsonKey(name: 'failure_threshold') required this.failureThreshold})
      : _headers = headers,
        _expectedStatusCodes = expectedStatusCodes;

  factory _$ServiceCreateDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ServiceCreateDtoImplFromJson(json);

  @override
  final String name;
  @override
  final String? description;
  @override
  @JsonKey(name: 'endpoint_url')
  final String endpointUrl;
  @override
  @JsonKey(name: 'http_method')
  final String httpMethod;
  @override
  @JsonKey(name: 'service_type')
  final String serviceType;
  final Map<String, String>? _headers;
  @override
  Map<String, String>? get headers {
    final value = _headers;
    if (value == null) return null;
    if (_headers is EqualUnmodifiableMapView) return _headers;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(value);
  }

  @override
  @JsonKey(name: 'request_body')
  final String? requestBody;
  final List<int> _expectedStatusCodes;
  @override
  @JsonKey(name: 'expected_status_codes')
  List<int> get expectedStatusCodes {
    if (_expectedStatusCodes is EqualUnmodifiableListView)
      return _expectedStatusCodes;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_expectedStatusCodes);
  }

  @override
  @JsonKey(name: 'timeout_seconds')
  final int timeoutSeconds;
  @override
  @JsonKey(name: 'check_interval_seconds')
  final int checkIntervalSeconds;
  @override
  @JsonKey(name: 'failure_threshold')
  final int failureThreshold;

  @override
  String toString() {
    return 'ServiceCreateDto(name: $name, description: $description, endpointUrl: $endpointUrl, httpMethod: $httpMethod, serviceType: $serviceType, headers: $headers, requestBody: $requestBody, expectedStatusCodes: $expectedStatusCodes, timeoutSeconds: $timeoutSeconds, checkIntervalSeconds: $checkIntervalSeconds, failureThreshold: $failureThreshold)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ServiceCreateDtoImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.endpointUrl, endpointUrl) ||
                other.endpointUrl == endpointUrl) &&
            (identical(other.httpMethod, httpMethod) ||
                other.httpMethod == httpMethod) &&
            (identical(other.serviceType, serviceType) ||
                other.serviceType == serviceType) &&
            const DeepCollectionEquality().equals(other._headers, _headers) &&
            (identical(other.requestBody, requestBody) ||
                other.requestBody == requestBody) &&
            const DeepCollectionEquality()
                .equals(other._expectedStatusCodes, _expectedStatusCodes) &&
            (identical(other.timeoutSeconds, timeoutSeconds) ||
                other.timeoutSeconds == timeoutSeconds) &&
            (identical(other.checkIntervalSeconds, checkIntervalSeconds) ||
                other.checkIntervalSeconds == checkIntervalSeconds) &&
            (identical(other.failureThreshold, failureThreshold) ||
                other.failureThreshold == failureThreshold));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      name,
      description,
      endpointUrl,
      httpMethod,
      serviceType,
      const DeepCollectionEquality().hash(_headers),
      requestBody,
      const DeepCollectionEquality().hash(_expectedStatusCodes),
      timeoutSeconds,
      checkIntervalSeconds,
      failureThreshold);

  /// Create a copy of ServiceCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ServiceCreateDtoImplCopyWith<_$ServiceCreateDtoImpl> get copyWith =>
      __$$ServiceCreateDtoImplCopyWithImpl<_$ServiceCreateDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ServiceCreateDtoImplToJson(
      this,
    );
  }
}

abstract class _ServiceCreateDto implements ServiceCreateDto {
  const factory _ServiceCreateDto(
      {required final String name,
      final String? description,
      @JsonKey(name: 'endpoint_url') required final String endpointUrl,
      @JsonKey(name: 'http_method') required final String httpMethod,
      @JsonKey(name: 'service_type') required final String serviceType,
      final Map<String, String>? headers,
      @JsonKey(name: 'request_body') final String? requestBody,
      @JsonKey(name: 'expected_status_codes')
      required final List<int> expectedStatusCodes,
      @JsonKey(name: 'timeout_seconds') required final int timeoutSeconds,
      @JsonKey(name: 'check_interval_seconds')
      required final int checkIntervalSeconds,
      @JsonKey(name: 'failure_threshold')
      required final int failureThreshold}) = _$ServiceCreateDtoImpl;

  factory _ServiceCreateDto.fromJson(Map<String, dynamic> json) =
      _$ServiceCreateDtoImpl.fromJson;

  @override
  String get name;
  @override
  String? get description;
  @override
  @JsonKey(name: 'endpoint_url')
  String get endpointUrl;
  @override
  @JsonKey(name: 'http_method')
  String get httpMethod;
  @override
  @JsonKey(name: 'service_type')
  String get serviceType;
  @override
  Map<String, String>? get headers;
  @override
  @JsonKey(name: 'request_body')
  String? get requestBody;
  @override
  @JsonKey(name: 'expected_status_codes')
  List<int> get expectedStatusCodes;
  @override
  @JsonKey(name: 'timeout_seconds')
  int get timeoutSeconds;
  @override
  @JsonKey(name: 'check_interval_seconds')
  int get checkIntervalSeconds;
  @override
  @JsonKey(name: 'failure_threshold')
  int get failureThreshold;

  /// Create a copy of ServiceCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ServiceCreateDtoImplCopyWith<_$ServiceCreateDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ServiceUpdateDto _$ServiceUpdateDtoFromJson(Map<String, dynamic> json) {
  return _ServiceUpdateDto.fromJson(json);
}

/// @nodoc
mixin _$ServiceUpdateDto {
  String? get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  @JsonKey(name: 'endpoint_url')
  String? get endpointUrl => throw _privateConstructorUsedError;
  @JsonKey(name: 'http_method')
  String? get httpMethod => throw _privateConstructorUsedError;
  @JsonKey(name: 'service_type')
  String? get serviceType => throw _privateConstructorUsedError;
  Map<String, String>? get headers => throw _privateConstructorUsedError;
  @JsonKey(name: 'request_body')
  String? get requestBody => throw _privateConstructorUsedError;
  @JsonKey(name: 'expected_status_codes')
  List<int>? get expectedStatusCodes => throw _privateConstructorUsedError;
  @JsonKey(name: 'timeout_seconds')
  int? get timeoutSeconds => throw _privateConstructorUsedError;
  @JsonKey(name: 'check_interval_seconds')
  int? get checkIntervalSeconds => throw _privateConstructorUsedError;
  @JsonKey(name: 'failure_threshold')
  int? get failureThreshold => throw _privateConstructorUsedError;
  @JsonKey(name: 'is_active')
  bool? get isActive => throw _privateConstructorUsedError;

  /// Serializes this ServiceUpdateDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ServiceUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ServiceUpdateDtoCopyWith<ServiceUpdateDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceUpdateDtoCopyWith<$Res> {
  factory $ServiceUpdateDtoCopyWith(
          ServiceUpdateDto value, $Res Function(ServiceUpdateDto) then) =
      _$ServiceUpdateDtoCopyWithImpl<$Res, ServiceUpdateDto>;
  @useResult
  $Res call(
      {String? name,
      String? description,
      @JsonKey(name: 'endpoint_url') String? endpointUrl,
      @JsonKey(name: 'http_method') String? httpMethod,
      @JsonKey(name: 'service_type') String? serviceType,
      Map<String, String>? headers,
      @JsonKey(name: 'request_body') String? requestBody,
      @JsonKey(name: 'expected_status_codes') List<int>? expectedStatusCodes,
      @JsonKey(name: 'timeout_seconds') int? timeoutSeconds,
      @JsonKey(name: 'check_interval_seconds') int? checkIntervalSeconds,
      @JsonKey(name: 'failure_threshold') int? failureThreshold,
      @JsonKey(name: 'is_active') bool? isActive});
}

/// @nodoc
class _$ServiceUpdateDtoCopyWithImpl<$Res, $Val extends ServiceUpdateDto>
    implements $ServiceUpdateDtoCopyWith<$Res> {
  _$ServiceUpdateDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ServiceUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = freezed,
    Object? description = freezed,
    Object? endpointUrl = freezed,
    Object? httpMethod = freezed,
    Object? serviceType = freezed,
    Object? headers = freezed,
    Object? requestBody = freezed,
    Object? expectedStatusCodes = freezed,
    Object? timeoutSeconds = freezed,
    Object? checkIntervalSeconds = freezed,
    Object? failureThreshold = freezed,
    Object? isActive = freezed,
  }) {
    return _then(_value.copyWith(
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      endpointUrl: freezed == endpointUrl
          ? _value.endpointUrl
          : endpointUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      httpMethod: freezed == httpMethod
          ? _value.httpMethod
          : httpMethod // ignore: cast_nullable_to_non_nullable
              as String?,
      serviceType: freezed == serviceType
          ? _value.serviceType
          : serviceType // ignore: cast_nullable_to_non_nullable
              as String?,
      headers: freezed == headers
          ? _value.headers
          : headers // ignore: cast_nullable_to_non_nullable
              as Map<String, String>?,
      requestBody: freezed == requestBody
          ? _value.requestBody
          : requestBody // ignore: cast_nullable_to_non_nullable
              as String?,
      expectedStatusCodes: freezed == expectedStatusCodes
          ? _value.expectedStatusCodes
          : expectedStatusCodes // ignore: cast_nullable_to_non_nullable
              as List<int>?,
      timeoutSeconds: freezed == timeoutSeconds
          ? _value.timeoutSeconds
          : timeoutSeconds // ignore: cast_nullable_to_non_nullable
              as int?,
      checkIntervalSeconds: freezed == checkIntervalSeconds
          ? _value.checkIntervalSeconds
          : checkIntervalSeconds // ignore: cast_nullable_to_non_nullable
              as int?,
      failureThreshold: freezed == failureThreshold
          ? _value.failureThreshold
          : failureThreshold // ignore: cast_nullable_to_non_nullable
              as int?,
      isActive: freezed == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ServiceUpdateDtoImplCopyWith<$Res>
    implements $ServiceUpdateDtoCopyWith<$Res> {
  factory _$$ServiceUpdateDtoImplCopyWith(_$ServiceUpdateDtoImpl value,
          $Res Function(_$ServiceUpdateDtoImpl) then) =
      __$$ServiceUpdateDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? name,
      String? description,
      @JsonKey(name: 'endpoint_url') String? endpointUrl,
      @JsonKey(name: 'http_method') String? httpMethod,
      @JsonKey(name: 'service_type') String? serviceType,
      Map<String, String>? headers,
      @JsonKey(name: 'request_body') String? requestBody,
      @JsonKey(name: 'expected_status_codes') List<int>? expectedStatusCodes,
      @JsonKey(name: 'timeout_seconds') int? timeoutSeconds,
      @JsonKey(name: 'check_interval_seconds') int? checkIntervalSeconds,
      @JsonKey(name: 'failure_threshold') int? failureThreshold,
      @JsonKey(name: 'is_active') bool? isActive});
}

/// @nodoc
class __$$ServiceUpdateDtoImplCopyWithImpl<$Res>
    extends _$ServiceUpdateDtoCopyWithImpl<$Res, _$ServiceUpdateDtoImpl>
    implements _$$ServiceUpdateDtoImplCopyWith<$Res> {
  __$$ServiceUpdateDtoImplCopyWithImpl(_$ServiceUpdateDtoImpl _value,
      $Res Function(_$ServiceUpdateDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of ServiceUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = freezed,
    Object? description = freezed,
    Object? endpointUrl = freezed,
    Object? httpMethod = freezed,
    Object? serviceType = freezed,
    Object? headers = freezed,
    Object? requestBody = freezed,
    Object? expectedStatusCodes = freezed,
    Object? timeoutSeconds = freezed,
    Object? checkIntervalSeconds = freezed,
    Object? failureThreshold = freezed,
    Object? isActive = freezed,
  }) {
    return _then(_$ServiceUpdateDtoImpl(
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      endpointUrl: freezed == endpointUrl
          ? _value.endpointUrl
          : endpointUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      httpMethod: freezed == httpMethod
          ? _value.httpMethod
          : httpMethod // ignore: cast_nullable_to_non_nullable
              as String?,
      serviceType: freezed == serviceType
          ? _value.serviceType
          : serviceType // ignore: cast_nullable_to_non_nullable
              as String?,
      headers: freezed == headers
          ? _value._headers
          : headers // ignore: cast_nullable_to_non_nullable
              as Map<String, String>?,
      requestBody: freezed == requestBody
          ? _value.requestBody
          : requestBody // ignore: cast_nullable_to_non_nullable
              as String?,
      expectedStatusCodes: freezed == expectedStatusCodes
          ? _value._expectedStatusCodes
          : expectedStatusCodes // ignore: cast_nullable_to_non_nullable
              as List<int>?,
      timeoutSeconds: freezed == timeoutSeconds
          ? _value.timeoutSeconds
          : timeoutSeconds // ignore: cast_nullable_to_non_nullable
              as int?,
      checkIntervalSeconds: freezed == checkIntervalSeconds
          ? _value.checkIntervalSeconds
          : checkIntervalSeconds // ignore: cast_nullable_to_non_nullable
              as int?,
      failureThreshold: freezed == failureThreshold
          ? _value.failureThreshold
          : failureThreshold // ignore: cast_nullable_to_non_nullable
              as int?,
      isActive: freezed == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ServiceUpdateDtoImpl implements _ServiceUpdateDto {
  const _$ServiceUpdateDtoImpl(
      {this.name,
      this.description,
      @JsonKey(name: 'endpoint_url') this.endpointUrl,
      @JsonKey(name: 'http_method') this.httpMethod,
      @JsonKey(name: 'service_type') this.serviceType,
      final Map<String, String>? headers,
      @JsonKey(name: 'request_body') this.requestBody,
      @JsonKey(name: 'expected_status_codes')
      final List<int>? expectedStatusCodes,
      @JsonKey(name: 'timeout_seconds') this.timeoutSeconds,
      @JsonKey(name: 'check_interval_seconds') this.checkIntervalSeconds,
      @JsonKey(name: 'failure_threshold') this.failureThreshold,
      @JsonKey(name: 'is_active') this.isActive})
      : _headers = headers,
        _expectedStatusCodes = expectedStatusCodes;

  factory _$ServiceUpdateDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ServiceUpdateDtoImplFromJson(json);

  @override
  final String? name;
  @override
  final String? description;
  @override
  @JsonKey(name: 'endpoint_url')
  final String? endpointUrl;
  @override
  @JsonKey(name: 'http_method')
  final String? httpMethod;
  @override
  @JsonKey(name: 'service_type')
  final String? serviceType;
  final Map<String, String>? _headers;
  @override
  Map<String, String>? get headers {
    final value = _headers;
    if (value == null) return null;
    if (_headers is EqualUnmodifiableMapView) return _headers;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(value);
  }

  @override
  @JsonKey(name: 'request_body')
  final String? requestBody;
  final List<int>? _expectedStatusCodes;
  @override
  @JsonKey(name: 'expected_status_codes')
  List<int>? get expectedStatusCodes {
    final value = _expectedStatusCodes;
    if (value == null) return null;
    if (_expectedStatusCodes is EqualUnmodifiableListView)
      return _expectedStatusCodes;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey(name: 'timeout_seconds')
  final int? timeoutSeconds;
  @override
  @JsonKey(name: 'check_interval_seconds')
  final int? checkIntervalSeconds;
  @override
  @JsonKey(name: 'failure_threshold')
  final int? failureThreshold;
  @override
  @JsonKey(name: 'is_active')
  final bool? isActive;

  @override
  String toString() {
    return 'ServiceUpdateDto(name: $name, description: $description, endpointUrl: $endpointUrl, httpMethod: $httpMethod, serviceType: $serviceType, headers: $headers, requestBody: $requestBody, expectedStatusCodes: $expectedStatusCodes, timeoutSeconds: $timeoutSeconds, checkIntervalSeconds: $checkIntervalSeconds, failureThreshold: $failureThreshold, isActive: $isActive)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ServiceUpdateDtoImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.endpointUrl, endpointUrl) ||
                other.endpointUrl == endpointUrl) &&
            (identical(other.httpMethod, httpMethod) ||
                other.httpMethod == httpMethod) &&
            (identical(other.serviceType, serviceType) ||
                other.serviceType == serviceType) &&
            const DeepCollectionEquality().equals(other._headers, _headers) &&
            (identical(other.requestBody, requestBody) ||
                other.requestBody == requestBody) &&
            const DeepCollectionEquality()
                .equals(other._expectedStatusCodes, _expectedStatusCodes) &&
            (identical(other.timeoutSeconds, timeoutSeconds) ||
                other.timeoutSeconds == timeoutSeconds) &&
            (identical(other.checkIntervalSeconds, checkIntervalSeconds) ||
                other.checkIntervalSeconds == checkIntervalSeconds) &&
            (identical(other.failureThreshold, failureThreshold) ||
                other.failureThreshold == failureThreshold) &&
            (identical(other.isActive, isActive) ||
                other.isActive == isActive));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      name,
      description,
      endpointUrl,
      httpMethod,
      serviceType,
      const DeepCollectionEquality().hash(_headers),
      requestBody,
      const DeepCollectionEquality().hash(_expectedStatusCodes),
      timeoutSeconds,
      checkIntervalSeconds,
      failureThreshold,
      isActive);

  /// Create a copy of ServiceUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ServiceUpdateDtoImplCopyWith<_$ServiceUpdateDtoImpl> get copyWith =>
      __$$ServiceUpdateDtoImplCopyWithImpl<_$ServiceUpdateDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ServiceUpdateDtoImplToJson(
      this,
    );
  }
}

abstract class _ServiceUpdateDto implements ServiceUpdateDto {
  const factory _ServiceUpdateDto(
      {final String? name,
      final String? description,
      @JsonKey(name: 'endpoint_url') final String? endpointUrl,
      @JsonKey(name: 'http_method') final String? httpMethod,
      @JsonKey(name: 'service_type') final String? serviceType,
      final Map<String, String>? headers,
      @JsonKey(name: 'request_body') final String? requestBody,
      @JsonKey(name: 'expected_status_codes')
      final List<int>? expectedStatusCodes,
      @JsonKey(name: 'timeout_seconds') final int? timeoutSeconds,
      @JsonKey(name: 'check_interval_seconds') final int? checkIntervalSeconds,
      @JsonKey(name: 'failure_threshold') final int? failureThreshold,
      @JsonKey(name: 'is_active')
      final bool? isActive}) = _$ServiceUpdateDtoImpl;

  factory _ServiceUpdateDto.fromJson(Map<String, dynamic> json) =
      _$ServiceUpdateDtoImpl.fromJson;

  @override
  String? get name;
  @override
  String? get description;
  @override
  @JsonKey(name: 'endpoint_url')
  String? get endpointUrl;
  @override
  @JsonKey(name: 'http_method')
  String? get httpMethod;
  @override
  @JsonKey(name: 'service_type')
  String? get serviceType;
  @override
  Map<String, String>? get headers;
  @override
  @JsonKey(name: 'request_body')
  String? get requestBody;
  @override
  @JsonKey(name: 'expected_status_codes')
  List<int>? get expectedStatusCodes;
  @override
  @JsonKey(name: 'timeout_seconds')
  int? get timeoutSeconds;
  @override
  @JsonKey(name: 'check_interval_seconds')
  int? get checkIntervalSeconds;
  @override
  @JsonKey(name: 'failure_threshold')
  int? get failureThreshold;
  @override
  @JsonKey(name: 'is_active')
  bool? get isActive;

  /// Create a copy of ServiceUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ServiceUpdateDtoImplCopyWith<_$ServiceUpdateDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
