// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'health_check_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

HealthCheckDto _$HealthCheckDtoFromJson(Map<String, dynamic> json) {
  return _HealthCheckDto.fromJson(json);
}

/// @nodoc
mixin _$HealthCheckDto {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'service_id')
  String get serviceId => throw _privateConstructorUsedError;
  @JsonKey(name: 'is_alive')
  bool get isAlive => throw _privateConstructorUsedError;
  @JsonKey(name: 'status_code')
  int? get statusCode => throw _privateConstructorUsedError;
  @JsonKey(name: 'latency_ms')
  int? get latencyMs => throw _privateConstructorUsedError;
  @JsonKey(name: 'response_body')
  String? get responseBody => throw _privateConstructorUsedError;
  @JsonKey(name: 'error_message')
  String? get errorMessage => throw _privateConstructorUsedError;
  @JsonKey(name: 'error_type')
  String? get errorType => throw _privateConstructorUsedError;
  @JsonKey(name: 'checked_at')
  String get checkedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'needs_analysis')
  bool get needsAnalysis => throw _privateConstructorUsedError;

  /// Serializes this HealthCheckDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of HealthCheckDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $HealthCheckDtoCopyWith<HealthCheckDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HealthCheckDtoCopyWith<$Res> {
  factory $HealthCheckDtoCopyWith(
          HealthCheckDto value, $Res Function(HealthCheckDto) then) =
      _$HealthCheckDtoCopyWithImpl<$Res, HealthCheckDto>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'service_id') String serviceId,
      @JsonKey(name: 'is_alive') bool isAlive,
      @JsonKey(name: 'status_code') int? statusCode,
      @JsonKey(name: 'latency_ms') int? latencyMs,
      @JsonKey(name: 'response_body') String? responseBody,
      @JsonKey(name: 'error_message') String? errorMessage,
      @JsonKey(name: 'error_type') String? errorType,
      @JsonKey(name: 'checked_at') String checkedAt,
      @JsonKey(name: 'needs_analysis') bool needsAnalysis});
}

/// @nodoc
class _$HealthCheckDtoCopyWithImpl<$Res, $Val extends HealthCheckDto>
    implements $HealthCheckDtoCopyWith<$Res> {
  _$HealthCheckDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of HealthCheckDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? serviceId = null,
    Object? isAlive = null,
    Object? statusCode = freezed,
    Object? latencyMs = freezed,
    Object? responseBody = freezed,
    Object? errorMessage = freezed,
    Object? errorType = freezed,
    Object? checkedAt = null,
    Object? needsAnalysis = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      serviceId: null == serviceId
          ? _value.serviceId
          : serviceId // ignore: cast_nullable_to_non_nullable
              as String,
      isAlive: null == isAlive
          ? _value.isAlive
          : isAlive // ignore: cast_nullable_to_non_nullable
              as bool,
      statusCode: freezed == statusCode
          ? _value.statusCode
          : statusCode // ignore: cast_nullable_to_non_nullable
              as int?,
      latencyMs: freezed == latencyMs
          ? _value.latencyMs
          : latencyMs // ignore: cast_nullable_to_non_nullable
              as int?,
      responseBody: freezed == responseBody
          ? _value.responseBody
          : responseBody // ignore: cast_nullable_to_non_nullable
              as String?,
      errorMessage: freezed == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String?,
      errorType: freezed == errorType
          ? _value.errorType
          : errorType // ignore: cast_nullable_to_non_nullable
              as String?,
      checkedAt: null == checkedAt
          ? _value.checkedAt
          : checkedAt // ignore: cast_nullable_to_non_nullable
              as String,
      needsAnalysis: null == needsAnalysis
          ? _value.needsAnalysis
          : needsAnalysis // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$HealthCheckDtoImplCopyWith<$Res>
    implements $HealthCheckDtoCopyWith<$Res> {
  factory _$$HealthCheckDtoImplCopyWith(_$HealthCheckDtoImpl value,
          $Res Function(_$HealthCheckDtoImpl) then) =
      __$$HealthCheckDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'service_id') String serviceId,
      @JsonKey(name: 'is_alive') bool isAlive,
      @JsonKey(name: 'status_code') int? statusCode,
      @JsonKey(name: 'latency_ms') int? latencyMs,
      @JsonKey(name: 'response_body') String? responseBody,
      @JsonKey(name: 'error_message') String? errorMessage,
      @JsonKey(name: 'error_type') String? errorType,
      @JsonKey(name: 'checked_at') String checkedAt,
      @JsonKey(name: 'needs_analysis') bool needsAnalysis});
}

/// @nodoc
class __$$HealthCheckDtoImplCopyWithImpl<$Res>
    extends _$HealthCheckDtoCopyWithImpl<$Res, _$HealthCheckDtoImpl>
    implements _$$HealthCheckDtoImplCopyWith<$Res> {
  __$$HealthCheckDtoImplCopyWithImpl(
      _$HealthCheckDtoImpl _value, $Res Function(_$HealthCheckDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of HealthCheckDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? serviceId = null,
    Object? isAlive = null,
    Object? statusCode = freezed,
    Object? latencyMs = freezed,
    Object? responseBody = freezed,
    Object? errorMessage = freezed,
    Object? errorType = freezed,
    Object? checkedAt = null,
    Object? needsAnalysis = null,
  }) {
    return _then(_$HealthCheckDtoImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      serviceId: null == serviceId
          ? _value.serviceId
          : serviceId // ignore: cast_nullable_to_non_nullable
              as String,
      isAlive: null == isAlive
          ? _value.isAlive
          : isAlive // ignore: cast_nullable_to_non_nullable
              as bool,
      statusCode: freezed == statusCode
          ? _value.statusCode
          : statusCode // ignore: cast_nullable_to_non_nullable
              as int?,
      latencyMs: freezed == latencyMs
          ? _value.latencyMs
          : latencyMs // ignore: cast_nullable_to_non_nullable
              as int?,
      responseBody: freezed == responseBody
          ? _value.responseBody
          : responseBody // ignore: cast_nullable_to_non_nullable
              as String?,
      errorMessage: freezed == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String?,
      errorType: freezed == errorType
          ? _value.errorType
          : errorType // ignore: cast_nullable_to_non_nullable
              as String?,
      checkedAt: null == checkedAt
          ? _value.checkedAt
          : checkedAt // ignore: cast_nullable_to_non_nullable
              as String,
      needsAnalysis: null == needsAnalysis
          ? _value.needsAnalysis
          : needsAnalysis // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$HealthCheckDtoImpl extends _HealthCheckDto {
  const _$HealthCheckDtoImpl(
      {required this.id,
      @JsonKey(name: 'service_id') required this.serviceId,
      @JsonKey(name: 'is_alive') required this.isAlive,
      @JsonKey(name: 'status_code') this.statusCode,
      @JsonKey(name: 'latency_ms') this.latencyMs,
      @JsonKey(name: 'response_body') this.responseBody,
      @JsonKey(name: 'error_message') this.errorMessage,
      @JsonKey(name: 'error_type') this.errorType,
      @JsonKey(name: 'checked_at') required this.checkedAt,
      @JsonKey(name: 'needs_analysis') required this.needsAnalysis})
      : super._();

  factory _$HealthCheckDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$HealthCheckDtoImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'service_id')
  final String serviceId;
  @override
  @JsonKey(name: 'is_alive')
  final bool isAlive;
  @override
  @JsonKey(name: 'status_code')
  final int? statusCode;
  @override
  @JsonKey(name: 'latency_ms')
  final int? latencyMs;
  @override
  @JsonKey(name: 'response_body')
  final String? responseBody;
  @override
  @JsonKey(name: 'error_message')
  final String? errorMessage;
  @override
  @JsonKey(name: 'error_type')
  final String? errorType;
  @override
  @JsonKey(name: 'checked_at')
  final String checkedAt;
  @override
  @JsonKey(name: 'needs_analysis')
  final bool needsAnalysis;

  @override
  String toString() {
    return 'HealthCheckDto(id: $id, serviceId: $serviceId, isAlive: $isAlive, statusCode: $statusCode, latencyMs: $latencyMs, responseBody: $responseBody, errorMessage: $errorMessage, errorType: $errorType, checkedAt: $checkedAt, needsAnalysis: $needsAnalysis)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$HealthCheckDtoImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.serviceId, serviceId) ||
                other.serviceId == serviceId) &&
            (identical(other.isAlive, isAlive) || other.isAlive == isAlive) &&
            (identical(other.statusCode, statusCode) ||
                other.statusCode == statusCode) &&
            (identical(other.latencyMs, latencyMs) ||
                other.latencyMs == latencyMs) &&
            (identical(other.responseBody, responseBody) ||
                other.responseBody == responseBody) &&
            (identical(other.errorMessage, errorMessage) ||
                other.errorMessage == errorMessage) &&
            (identical(other.errorType, errorType) ||
                other.errorType == errorType) &&
            (identical(other.checkedAt, checkedAt) ||
                other.checkedAt == checkedAt) &&
            (identical(other.needsAnalysis, needsAnalysis) ||
                other.needsAnalysis == needsAnalysis));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      serviceId,
      isAlive,
      statusCode,
      latencyMs,
      responseBody,
      errorMessage,
      errorType,
      checkedAt,
      needsAnalysis);

  /// Create a copy of HealthCheckDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$HealthCheckDtoImplCopyWith<_$HealthCheckDtoImpl> get copyWith =>
      __$$HealthCheckDtoImplCopyWithImpl<_$HealthCheckDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$HealthCheckDtoImplToJson(
      this,
    );
  }
}

abstract class _HealthCheckDto extends HealthCheckDto {
  const factory _HealthCheckDto(
          {required final String id,
          @JsonKey(name: 'service_id') required final String serviceId,
          @JsonKey(name: 'is_alive') required final bool isAlive,
          @JsonKey(name: 'status_code') final int? statusCode,
          @JsonKey(name: 'latency_ms') final int? latencyMs,
          @JsonKey(name: 'response_body') final String? responseBody,
          @JsonKey(name: 'error_message') final String? errorMessage,
          @JsonKey(name: 'error_type') final String? errorType,
          @JsonKey(name: 'checked_at') required final String checkedAt,
          @JsonKey(name: 'needs_analysis') required final bool needsAnalysis}) =
      _$HealthCheckDtoImpl;
  const _HealthCheckDto._() : super._();

  factory _HealthCheckDto.fromJson(Map<String, dynamic> json) =
      _$HealthCheckDtoImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'service_id')
  String get serviceId;
  @override
  @JsonKey(name: 'is_alive')
  bool get isAlive;
  @override
  @JsonKey(name: 'status_code')
  int? get statusCode;
  @override
  @JsonKey(name: 'latency_ms')
  int? get latencyMs;
  @override
  @JsonKey(name: 'response_body')
  String? get responseBody;
  @override
  @JsonKey(name: 'error_message')
  String? get errorMessage;
  @override
  @JsonKey(name: 'error_type')
  String? get errorType;
  @override
  @JsonKey(name: 'checked_at')
  String get checkedAt;
  @override
  @JsonKey(name: 'needs_analysis')
  bool get needsAnalysis;

  /// Create a copy of HealthCheckDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$HealthCheckDtoImplCopyWith<_$HealthCheckDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
