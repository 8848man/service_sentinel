// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'health_check_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$HealthCheckDtoImpl _$$HealthCheckDtoImplFromJson(Map<String, dynamic> json) =>
    _$HealthCheckDtoImpl(
      id: json['id'] as String,
      serviceId: json['service_id'] as String,
      isAlive: json['is_alive'] as bool,
      statusCode: (json['status_code'] as num?)?.toInt(),
      latencyMs: (json['latency_ms'] as num?)?.toInt(),
      responseBody: json['response_body'] as String?,
      errorMessage: json['error_message'] as String?,
      errorType: json['error_type'] as String?,
      checkedAt: json['checked_at'] as String,
      needsAnalysis: json['needs_analysis'] as bool,
    );

Map<String, dynamic> _$$HealthCheckDtoImplToJson(
        _$HealthCheckDtoImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'service_id': instance.serviceId,
      'is_alive': instance.isAlive,
      'status_code': instance.statusCode,
      'latency_ms': instance.latencyMs,
      'response_body': instance.responseBody,
      'error_message': instance.errorMessage,
      'error_type': instance.errorType,
      'checked_at': instance.checkedAt,
      'needs_analysis': instance.needsAnalysis,
    };
