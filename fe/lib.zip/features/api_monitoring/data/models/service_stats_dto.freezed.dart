// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'service_stats_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ServiceStatsDto _$ServiceStatsDtoFromJson(Map<String, dynamic> json) {
  return _ServiceStatsDto.fromJson(json);
}

/// @nodoc
mixin _$ServiceStatsDto {
  @JsonKey(name: 'service_id')
  String get serviceId => throw _privateConstructorUsedError;
  @JsonKey(name: 'uptime_percentage')
  double get uptimePercentage => throw _privateConstructorUsedError;
  @JsonKey(name: 'total_checks')
  int get totalChecks => throw _privateConstructorUsedError;
  @JsonKey(name: 'successful_checks')
  int get successfulChecks => throw _privateConstructorUsedError;
  @JsonKey(name: 'failed_checks')
  int get failedChecks => throw _privateConstructorUsedError;
  @JsonKey(name: 'average_latency_ms')
  double get averageLatencyMs => throw _privateConstructorUsedError;

  /// Serializes this ServiceStatsDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ServiceStatsDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ServiceStatsDtoCopyWith<ServiceStatsDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceStatsDtoCopyWith<$Res> {
  factory $ServiceStatsDtoCopyWith(
          ServiceStatsDto value, $Res Function(ServiceStatsDto) then) =
      _$ServiceStatsDtoCopyWithImpl<$Res, ServiceStatsDto>;
  @useResult
  $Res call(
      {@JsonKey(name: 'service_id') String serviceId,
      @JsonKey(name: 'uptime_percentage') double uptimePercentage,
      @JsonKey(name: 'total_checks') int totalChecks,
      @JsonKey(name: 'successful_checks') int successfulChecks,
      @JsonKey(name: 'failed_checks') int failedChecks,
      @JsonKey(name: 'average_latency_ms') double averageLatencyMs});
}

/// @nodoc
class _$ServiceStatsDtoCopyWithImpl<$Res, $Val extends ServiceStatsDto>
    implements $ServiceStatsDtoCopyWith<$Res> {
  _$ServiceStatsDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ServiceStatsDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? serviceId = null,
    Object? uptimePercentage = null,
    Object? totalChecks = null,
    Object? successfulChecks = null,
    Object? failedChecks = null,
    Object? averageLatencyMs = null,
  }) {
    return _then(_value.copyWith(
      serviceId: null == serviceId
          ? _value.serviceId
          : serviceId // ignore: cast_nullable_to_non_nullable
              as String,
      uptimePercentage: null == uptimePercentage
          ? _value.uptimePercentage
          : uptimePercentage // ignore: cast_nullable_to_non_nullable
              as double,
      totalChecks: null == totalChecks
          ? _value.totalChecks
          : totalChecks // ignore: cast_nullable_to_non_nullable
              as int,
      successfulChecks: null == successfulChecks
          ? _value.successfulChecks
          : successfulChecks // ignore: cast_nullable_to_non_nullable
              as int,
      failedChecks: null == failedChecks
          ? _value.failedChecks
          : failedChecks // ignore: cast_nullable_to_non_nullable
              as int,
      averageLatencyMs: null == averageLatencyMs
          ? _value.averageLatencyMs
          : averageLatencyMs // ignore: cast_nullable_to_non_nullable
              as double,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ServiceStatsDtoImplCopyWith<$Res>
    implements $ServiceStatsDtoCopyWith<$Res> {
  factory _$$ServiceStatsDtoImplCopyWith(_$ServiceStatsDtoImpl value,
          $Res Function(_$ServiceStatsDtoImpl) then) =
      __$$ServiceStatsDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: 'service_id') String serviceId,
      @JsonKey(name: 'uptime_percentage') double uptimePercentage,
      @JsonKey(name: 'total_checks') int totalChecks,
      @JsonKey(name: 'successful_checks') int successfulChecks,
      @JsonKey(name: 'failed_checks') int failedChecks,
      @JsonKey(name: 'average_latency_ms') double averageLatencyMs});
}

/// @nodoc
class __$$ServiceStatsDtoImplCopyWithImpl<$Res>
    extends _$ServiceStatsDtoCopyWithImpl<$Res, _$ServiceStatsDtoImpl>
    implements _$$ServiceStatsDtoImplCopyWith<$Res> {
  __$$ServiceStatsDtoImplCopyWithImpl(
      _$ServiceStatsDtoImpl _value, $Res Function(_$ServiceStatsDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of ServiceStatsDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? serviceId = null,
    Object? uptimePercentage = null,
    Object? totalChecks = null,
    Object? successfulChecks = null,
    Object? failedChecks = null,
    Object? averageLatencyMs = null,
  }) {
    return _then(_$ServiceStatsDtoImpl(
      serviceId: null == serviceId
          ? _value.serviceId
          : serviceId // ignore: cast_nullable_to_non_nullable
              as String,
      uptimePercentage: null == uptimePercentage
          ? _value.uptimePercentage
          : uptimePercentage // ignore: cast_nullable_to_non_nullable
              as double,
      totalChecks: null == totalChecks
          ? _value.totalChecks
          : totalChecks // ignore: cast_nullable_to_non_nullable
              as int,
      successfulChecks: null == successfulChecks
          ? _value.successfulChecks
          : successfulChecks // ignore: cast_nullable_to_non_nullable
              as int,
      failedChecks: null == failedChecks
          ? _value.failedChecks
          : failedChecks // ignore: cast_nullable_to_non_nullable
              as int,
      averageLatencyMs: null == averageLatencyMs
          ? _value.averageLatencyMs
          : averageLatencyMs // ignore: cast_nullable_to_non_nullable
              as double,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ServiceStatsDtoImpl extends _ServiceStatsDto {
  const _$ServiceStatsDtoImpl(
      {@JsonKey(name: 'service_id') required this.serviceId,
      @JsonKey(name: 'uptime_percentage') required this.uptimePercentage,
      @JsonKey(name: 'total_checks') required this.totalChecks,
      @JsonKey(name: 'successful_checks') required this.successfulChecks,
      @JsonKey(name: 'failed_checks') required this.failedChecks,
      @JsonKey(name: 'average_latency_ms') required this.averageLatencyMs})
      : super._();

  factory _$ServiceStatsDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ServiceStatsDtoImplFromJson(json);

  @override
  @JsonKey(name: 'service_id')
  final String serviceId;
  @override
  @JsonKey(name: 'uptime_percentage')
  final double uptimePercentage;
  @override
  @JsonKey(name: 'total_checks')
  final int totalChecks;
  @override
  @JsonKey(name: 'successful_checks')
  final int successfulChecks;
  @override
  @JsonKey(name: 'failed_checks')
  final int failedChecks;
  @override
  @JsonKey(name: 'average_latency_ms')
  final double averageLatencyMs;

  @override
  String toString() {
    return 'ServiceStatsDto(serviceId: $serviceId, uptimePercentage: $uptimePercentage, totalChecks: $totalChecks, successfulChecks: $successfulChecks, failedChecks: $failedChecks, averageLatencyMs: $averageLatencyMs)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ServiceStatsDtoImpl &&
            (identical(other.serviceId, serviceId) ||
                other.serviceId == serviceId) &&
            (identical(other.uptimePercentage, uptimePercentage) ||
                other.uptimePercentage == uptimePercentage) &&
            (identical(other.totalChecks, totalChecks) ||
                other.totalChecks == totalChecks) &&
            (identical(other.successfulChecks, successfulChecks) ||
                other.successfulChecks == successfulChecks) &&
            (identical(other.failedChecks, failedChecks) ||
                other.failedChecks == failedChecks) &&
            (identical(other.averageLatencyMs, averageLatencyMs) ||
                other.averageLatencyMs == averageLatencyMs));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, serviceId, uptimePercentage,
      totalChecks, successfulChecks, failedChecks, averageLatencyMs);

  /// Create a copy of ServiceStatsDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ServiceStatsDtoImplCopyWith<_$ServiceStatsDtoImpl> get copyWith =>
      __$$ServiceStatsDtoImplCopyWithImpl<_$ServiceStatsDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ServiceStatsDtoImplToJson(
      this,
    );
  }
}

abstract class _ServiceStatsDto extends ServiceStatsDto {
  const factory _ServiceStatsDto(
      {@JsonKey(name: 'service_id') required final String serviceId,
      @JsonKey(name: 'uptime_percentage')
      required final double uptimePercentage,
      @JsonKey(name: 'total_checks') required final int totalChecks,
      @JsonKey(name: 'successful_checks') required final int successfulChecks,
      @JsonKey(name: 'failed_checks') required final int failedChecks,
      @JsonKey(name: 'average_latency_ms')
      required final double averageLatencyMs}) = _$ServiceStatsDtoImpl;
  const _ServiceStatsDto._() : super._();

  factory _ServiceStatsDto.fromJson(Map<String, dynamic> json) =
      _$ServiceStatsDtoImpl.fromJson;

  @override
  @JsonKey(name: 'service_id')
  String get serviceId;
  @override
  @JsonKey(name: 'uptime_percentage')
  double get uptimePercentage;
  @override
  @JsonKey(name: 'total_checks')
  int get totalChecks;
  @override
  @JsonKey(name: 'successful_checks')
  int get successfulChecks;
  @override
  @JsonKey(name: 'failed_checks')
  int get failedChecks;
  @override
  @JsonKey(name: 'average_latency_ms')
  double get averageLatencyMs;

  /// Create a copy of ServiceStatsDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ServiceStatsDtoImplCopyWith<_$ServiceStatsDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
