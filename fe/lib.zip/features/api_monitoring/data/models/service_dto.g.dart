// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'service_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ServiceDtoImpl _$$ServiceDtoImplFromJson(Map<String, dynamic> json) =>
    _$ServiceDtoImpl(
      id: (json['id'] as num).toInt(),
      projectId: (json['project_id'] as num?)?.toInt(),
      name: json['name'] as String,
      description: json['description'] as String?,
      endpointUrl: json['endpoint_url'] as String,
      httpMethod: json['http_method'] as String,
      serviceType: json['service_type'] as String,
      headers: (json['headers'] as Map<String, dynamic>?)?.map(
        (k, e) => MapEntry(k, e as String),
      ),
      requestBody: json['request_body'] as String?,
      expectedStatusCodes: (json['expected_status_codes'] as List<dynamic>)
          .map((e) => (e as num).toInt())
          .toList(),
      timeoutSeconds: (json['timeout_seconds'] as num).toInt(),
      checkIntervalSeconds: (json['check_interval_seconds'] as num).toInt(),
      failureThreshold: (json['failure_threshold'] as num).toInt(),
      isActive: json['is_active'] as bool,
      serviceState: json['service_state'] as String?,
      createdAt: json['created_at'] as String,
      updatedAt: json['updated_at'] as String,
      lastCheckedAt: json['last_checked_at'] as String?,
    );

Map<String, dynamic> _$$ServiceDtoImplToJson(_$ServiceDtoImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'project_id': instance.projectId,
      'name': instance.name,
      'description': instance.description,
      'endpoint_url': instance.endpointUrl,
      'http_method': instance.httpMethod,
      'service_type': instance.serviceType,
      'headers': instance.headers,
      'request_body': instance.requestBody,
      'expected_status_codes': instance.expectedStatusCodes,
      'timeout_seconds': instance.timeoutSeconds,
      'check_interval_seconds': instance.checkIntervalSeconds,
      'failure_threshold': instance.failureThreshold,
      'is_active': instance.isActive,
      'service_state': instance.serviceState,
      'created_at': instance.createdAt,
      'updated_at': instance.updatedAt,
      'last_checked_at': instance.lastCheckedAt,
    };

_$ServiceCreateDtoImpl _$$ServiceCreateDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ServiceCreateDtoImpl(
      name: json['name'] as String,
      description: json['description'] as String?,
      endpointUrl: json['endpoint_url'] as String,
      httpMethod: json['http_method'] as String,
      serviceType: json['service_type'] as String,
      headers: (json['headers'] as Map<String, dynamic>?)?.map(
        (k, e) => MapEntry(k, e as String),
      ),
      requestBody: json['request_body'] as String?,
      expectedStatusCodes: (json['expected_status_codes'] as List<dynamic>)
          .map((e) => (e as num).toInt())
          .toList(),
      timeoutSeconds: (json['timeout_seconds'] as num).toInt(),
      checkIntervalSeconds: (json['check_interval_seconds'] as num).toInt(),
      failureThreshold: (json['failure_threshold'] as num).toInt(),
    );

Map<String, dynamic> _$$ServiceCreateDtoImplToJson(
        _$ServiceCreateDtoImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
      'description': instance.description,
      'endpoint_url': instance.endpointUrl,
      'http_method': instance.httpMethod,
      'service_type': instance.serviceType,
      'headers': instance.headers,
      'request_body': instance.requestBody,
      'expected_status_codes': instance.expectedStatusCodes,
      'timeout_seconds': instance.timeoutSeconds,
      'check_interval_seconds': instance.checkIntervalSeconds,
      'failure_threshold': instance.failureThreshold,
    };

_$ServiceUpdateDtoImpl _$$ServiceUpdateDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ServiceUpdateDtoImpl(
      name: json['name'] as String?,
      description: json['description'] as String?,
      endpointUrl: json['endpoint_url'] as String?,
      httpMethod: json['http_method'] as String?,
      serviceType: json['service_type'] as String?,
      headers: (json['headers'] as Map<String, dynamic>?)?.map(
        (k, e) => MapEntry(k, e as String),
      ),
      requestBody: json['request_body'] as String?,
      expectedStatusCodes: (json['expected_status_codes'] as List<dynamic>?)
          ?.map((e) => (e as num).toInt())
          .toList(),
      timeoutSeconds: (json['timeout_seconds'] as num?)?.toInt(),
      checkIntervalSeconds: (json['check_interval_seconds'] as num?)?.toInt(),
      failureThreshold: (json['failure_threshold'] as num?)?.toInt(),
      isActive: json['is_active'] as bool?,
    );

Map<String, dynamic> _$$ServiceUpdateDtoImplToJson(
        _$ServiceUpdateDtoImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
      'description': instance.description,
      'endpoint_url': instance.endpointUrl,
      'http_method': instance.httpMethod,
      'service_type': instance.serviceType,
      'headers': instance.headers,
      'request_body': instance.requestBody,
      'expected_status_codes': instance.expectedStatusCodes,
      'timeout_seconds': instance.timeoutSeconds,
      'check_interval_seconds': instance.checkIntervalSeconds,
      'failure_threshold': instance.failureThreshold,
      'is_active': instance.isActive,
    };
