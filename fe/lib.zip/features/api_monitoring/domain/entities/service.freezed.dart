// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'service.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$Service {
  int get id => throw _privateConstructorUsedError;
  int get projectId => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  String get endpointUrl => throw _privateConstructorUsedError;
  HttpMethod get httpMethod => throw _privateConstructorUsedError;
  ServiceType get serviceType => throw _privateConstructorUsedError;
  Map<String, String>? get headers => throw _privateConstructorUsedError;
  String? get requestBody => throw _privateConstructorUsedError;
  List<int> get expectedStatusCodes => throw _privateConstructorUsedError;
  int get timeoutSeconds => throw _privateConstructorUsedError;
  int get checkIntervalSeconds => throw _privateConstructorUsedError;
  int get failureThreshold => throw _privateConstructorUsedError;
  bool get isActive => throw _privateConstructorUsedError;
  ServiceState? get serviceState => throw _privateConstructorUsedError;
  DateTime get createdAt => throw _privateConstructorUsedError;
  DateTime get updatedAt => throw _privateConstructorUsedError;
  DateTime? get lastCheckedAt => throw _privateConstructorUsedError;

  /// Create a copy of Service
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ServiceCopyWith<Service> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceCopyWith<$Res> {
  factory $ServiceCopyWith(Service value, $Res Function(Service) then) =
      _$ServiceCopyWithImpl<$Res, Service>;
  @useResult
  $Res call(
      {int id,
      int projectId,
      String name,
      String? description,
      String endpointUrl,
      HttpMethod httpMethod,
      ServiceType serviceType,
      Map<String, String>? headers,
      String? requestBody,
      List<int> expectedStatusCodes,
      int timeoutSeconds,
      int checkIntervalSeconds,
      int failureThreshold,
      bool isActive,
      ServiceState? serviceState,
      DateTime createdAt,
      DateTime updatedAt,
      DateTime? lastCheckedAt});
}

/// @nodoc
class _$ServiceCopyWithImpl<$Res, $Val extends Service>
    implements $ServiceCopyWith<$Res> {
  _$ServiceCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of Service
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? projectId = null,
    Object? name = null,
    Object? description = freezed,
    Object? endpointUrl = null,
    Object? httpMethod = null,
    Object? serviceType = null,
    Object? headers = freezed,
    Object? requestBody = freezed,
    Object? expectedStatusCodes = null,
    Object? timeoutSeconds = null,
    Object? checkIntervalSeconds = null,
    Object? failureThreshold = null,
    Object? isActive = null,
    Object? serviceState = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
    Object? lastCheckedAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      projectId: null == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      endpointUrl: null == endpointUrl
          ? _value.endpointUrl
          : endpointUrl // ignore: cast_nullable_to_non_nullable
              as String,
      httpMethod: null == httpMethod
          ? _value.httpMethod
          : httpMethod // ignore: cast_nullable_to_non_nullable
              as HttpMethod,
      serviceType: null == serviceType
          ? _value.serviceType
          : serviceType // ignore: cast_nullable_to_non_nullable
              as ServiceType,
      headers: freezed == headers
          ? _value.headers
          : headers // ignore: cast_nullable_to_non_nullable
              as Map<String, String>?,
      requestBody: freezed == requestBody
          ? _value.requestBody
          : requestBody // ignore: cast_nullable_to_non_nullable
              as String?,
      expectedStatusCodes: null == expectedStatusCodes
          ? _value.expectedStatusCodes
          : expectedStatusCodes // ignore: cast_nullable_to_non_nullable
              as List<int>,
      timeoutSeconds: null == timeoutSeconds
          ? _value.timeoutSeconds
          : timeoutSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      checkIntervalSeconds: null == checkIntervalSeconds
          ? _value.checkIntervalSeconds
          : checkIntervalSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      failureThreshold: null == failureThreshold
          ? _value.failureThreshold
          : failureThreshold // ignore: cast_nullable_to_non_nullable
              as int,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      serviceState: freezed == serviceState
          ? _value.serviceState
          : serviceState // ignore: cast_nullable_to_non_nullable
              as ServiceState?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      lastCheckedAt: freezed == lastCheckedAt
          ? _value.lastCheckedAt
          : lastCheckedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ServiceImplCopyWith<$Res> implements $ServiceCopyWith<$Res> {
  factory _$$ServiceImplCopyWith(
          _$ServiceImpl value, $Res Function(_$ServiceImpl) then) =
      __$$ServiceImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int id,
      int projectId,
      String name,
      String? description,
      String endpointUrl,
      HttpMethod httpMethod,
      ServiceType serviceType,
      Map<String, String>? headers,
      String? requestBody,
      List<int> expectedStatusCodes,
      int timeoutSeconds,
      int checkIntervalSeconds,
      int failureThreshold,
      bool isActive,
      ServiceState? serviceState,
      DateTime createdAt,
      DateTime updatedAt,
      DateTime? lastCheckedAt});
}

/// @nodoc
class __$$ServiceImplCopyWithImpl<$Res>
    extends _$ServiceCopyWithImpl<$Res, _$ServiceImpl>
    implements _$$ServiceImplCopyWith<$Res> {
  __$$ServiceImplCopyWithImpl(
      _$ServiceImpl _value, $Res Function(_$ServiceImpl) _then)
      : super(_value, _then);

  /// Create a copy of Service
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? projectId = null,
    Object? name = null,
    Object? description = freezed,
    Object? endpointUrl = null,
    Object? httpMethod = null,
    Object? serviceType = null,
    Object? headers = freezed,
    Object? requestBody = freezed,
    Object? expectedStatusCodes = null,
    Object? timeoutSeconds = null,
    Object? checkIntervalSeconds = null,
    Object? failureThreshold = null,
    Object? isActive = null,
    Object? serviceState = freezed,
    Object? createdAt = null,
    Object? updatedAt = null,
    Object? lastCheckedAt = freezed,
  }) {
    return _then(_$ServiceImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      projectId: null == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      endpointUrl: null == endpointUrl
          ? _value.endpointUrl
          : endpointUrl // ignore: cast_nullable_to_non_nullable
              as String,
      httpMethod: null == httpMethod
          ? _value.httpMethod
          : httpMethod // ignore: cast_nullable_to_non_nullable
              as HttpMethod,
      serviceType: null == serviceType
          ? _value.serviceType
          : serviceType // ignore: cast_nullable_to_non_nullable
              as ServiceType,
      headers: freezed == headers
          ? _value._headers
          : headers // ignore: cast_nullable_to_non_nullable
              as Map<String, String>?,
      requestBody: freezed == requestBody
          ? _value.requestBody
          : requestBody // ignore: cast_nullable_to_non_nullable
              as String?,
      expectedStatusCodes: null == expectedStatusCodes
          ? _value._expectedStatusCodes
          : expectedStatusCodes // ignore: cast_nullable_to_non_nullable
              as List<int>,
      timeoutSeconds: null == timeoutSeconds
          ? _value.timeoutSeconds
          : timeoutSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      checkIntervalSeconds: null == checkIntervalSeconds
          ? _value.checkIntervalSeconds
          : checkIntervalSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      failureThreshold: null == failureThreshold
          ? _value.failureThreshold
          : failureThreshold // ignore: cast_nullable_to_non_nullable
              as int,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      serviceState: freezed == serviceState
          ? _value.serviceState
          : serviceState // ignore: cast_nullable_to_non_nullable
              as ServiceState?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      lastCheckedAt: freezed == lastCheckedAt
          ? _value.lastCheckedAt
          : lastCheckedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$ServiceImpl extends _Service {
  const _$ServiceImpl(
      {required this.id,
      required this.projectId,
      required this.name,
      this.description,
      required this.endpointUrl,
      required this.httpMethod,
      required this.serviceType,
      final Map<String, String>? headers,
      this.requestBody,
      required final List<int> expectedStatusCodes,
      required this.timeoutSeconds,
      required this.checkIntervalSeconds,
      required this.failureThreshold,
      required this.isActive,
      this.serviceState,
      required this.createdAt,
      required this.updatedAt,
      this.lastCheckedAt})
      : _headers = headers,
        _expectedStatusCodes = expectedStatusCodes,
        super._();

  @override
  final int id;
  @override
  final int projectId;
  @override
  final String name;
  @override
  final String? description;
  @override
  final String endpointUrl;
  @override
  final HttpMethod httpMethod;
  @override
  final ServiceType serviceType;
  final Map<String, String>? _headers;
  @override
  Map<String, String>? get headers {
    final value = _headers;
    if (value == null) return null;
    if (_headers is EqualUnmodifiableMapView) return _headers;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(value);
  }

  @override
  final String? requestBody;
  final List<int> _expectedStatusCodes;
  @override
  List<int> get expectedStatusCodes {
    if (_expectedStatusCodes is EqualUnmodifiableListView)
      return _expectedStatusCodes;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_expectedStatusCodes);
  }

  @override
  final int timeoutSeconds;
  @override
  final int checkIntervalSeconds;
  @override
  final int failureThreshold;
  @override
  final bool isActive;
  @override
  final ServiceState? serviceState;
  @override
  final DateTime createdAt;
  @override
  final DateTime updatedAt;
  @override
  final DateTime? lastCheckedAt;

  @override
  String toString() {
    return 'Service(id: $id, projectId: $projectId, name: $name, description: $description, endpointUrl: $endpointUrl, httpMethod: $httpMethod, serviceType: $serviceType, headers: $headers, requestBody: $requestBody, expectedStatusCodes: $expectedStatusCodes, timeoutSeconds: $timeoutSeconds, checkIntervalSeconds: $checkIntervalSeconds, failureThreshold: $failureThreshold, isActive: $isActive, serviceState: $serviceState, createdAt: $createdAt, updatedAt: $updatedAt, lastCheckedAt: $lastCheckedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ServiceImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.projectId, projectId) ||
                other.projectId == projectId) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.endpointUrl, endpointUrl) ||
                other.endpointUrl == endpointUrl) &&
            (identical(other.httpMethod, httpMethod) ||
                other.httpMethod == httpMethod) &&
            (identical(other.serviceType, serviceType) ||
                other.serviceType == serviceType) &&
            const DeepCollectionEquality().equals(other._headers, _headers) &&
            (identical(other.requestBody, requestBody) ||
                other.requestBody == requestBody) &&
            const DeepCollectionEquality()
                .equals(other._expectedStatusCodes, _expectedStatusCodes) &&
            (identical(other.timeoutSeconds, timeoutSeconds) ||
                other.timeoutSeconds == timeoutSeconds) &&
            (identical(other.checkIntervalSeconds, checkIntervalSeconds) ||
                other.checkIntervalSeconds == checkIntervalSeconds) &&
            (identical(other.failureThreshold, failureThreshold) ||
                other.failureThreshold == failureThreshold) &&
            (identical(other.isActive, isActive) ||
                other.isActive == isActive) &&
            (identical(other.serviceState, serviceState) ||
                other.serviceState == serviceState) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.lastCheckedAt, lastCheckedAt) ||
                other.lastCheckedAt == lastCheckedAt));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      projectId,
      name,
      description,
      endpointUrl,
      httpMethod,
      serviceType,
      const DeepCollectionEquality().hash(_headers),
      requestBody,
      const DeepCollectionEquality().hash(_expectedStatusCodes),
      timeoutSeconds,
      checkIntervalSeconds,
      failureThreshold,
      isActive,
      serviceState,
      createdAt,
      updatedAt,
      lastCheckedAt);

  /// Create a copy of Service
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ServiceImplCopyWith<_$ServiceImpl> get copyWith =>
      __$$ServiceImplCopyWithImpl<_$ServiceImpl>(this, _$identity);
}

abstract class _Service extends Service {
  const factory _Service(
      {required final int id,
      required final int projectId,
      required final String name,
      final String? description,
      required final String endpointUrl,
      required final HttpMethod httpMethod,
      required final ServiceType serviceType,
      final Map<String, String>? headers,
      final String? requestBody,
      required final List<int> expectedStatusCodes,
      required final int timeoutSeconds,
      required final int checkIntervalSeconds,
      required final int failureThreshold,
      required final bool isActive,
      final ServiceState? serviceState,
      required final DateTime createdAt,
      required final DateTime updatedAt,
      final DateTime? lastCheckedAt}) = _$ServiceImpl;
  const _Service._() : super._();

  @override
  int get id;
  @override
  int get projectId;
  @override
  String get name;
  @override
  String? get description;
  @override
  String get endpointUrl;
  @override
  HttpMethod get httpMethod;
  @override
  ServiceType get serviceType;
  @override
  Map<String, String>? get headers;
  @override
  String? get requestBody;
  @override
  List<int> get expectedStatusCodes;
  @override
  int get timeoutSeconds;
  @override
  int get checkIntervalSeconds;
  @override
  int get failureThreshold;
  @override
  bool get isActive;
  @override
  ServiceState? get serviceState;
  @override
  DateTime get createdAt;
  @override
  DateTime get updatedAt;
  @override
  DateTime? get lastCheckedAt;

  /// Create a copy of Service
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ServiceImplCopyWith<_$ServiceImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ServiceCreate {
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  String get endpointUrl => throw _privateConstructorUsedError;
  HttpMethod get httpMethod => throw _privateConstructorUsedError;
  ServiceType get serviceType => throw _privateConstructorUsedError;
  Map<String, String>? get headers => throw _privateConstructorUsedError;
  String? get requestBody => throw _privateConstructorUsedError;
  List<int> get expectedStatusCodes => throw _privateConstructorUsedError;
  int get timeoutSeconds => throw _privateConstructorUsedError;
  int get checkIntervalSeconds => throw _privateConstructorUsedError;
  int get failureThreshold => throw _privateConstructorUsedError;

  /// Create a copy of ServiceCreate
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ServiceCreateCopyWith<ServiceCreate> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceCreateCopyWith<$Res> {
  factory $ServiceCreateCopyWith(
          ServiceCreate value, $Res Function(ServiceCreate) then) =
      _$ServiceCreateCopyWithImpl<$Res, ServiceCreate>;
  @useResult
  $Res call(
      {String name,
      String? description,
      String endpointUrl,
      HttpMethod httpMethod,
      ServiceType serviceType,
      Map<String, String>? headers,
      String? requestBody,
      List<int> expectedStatusCodes,
      int timeoutSeconds,
      int checkIntervalSeconds,
      int failureThreshold});
}

/// @nodoc
class _$ServiceCreateCopyWithImpl<$Res, $Val extends ServiceCreate>
    implements $ServiceCreateCopyWith<$Res> {
  _$ServiceCreateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ServiceCreate
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
    Object? endpointUrl = null,
    Object? httpMethod = null,
    Object? serviceType = null,
    Object? headers = freezed,
    Object? requestBody = freezed,
    Object? expectedStatusCodes = null,
    Object? timeoutSeconds = null,
    Object? checkIntervalSeconds = null,
    Object? failureThreshold = null,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      endpointUrl: null == endpointUrl
          ? _value.endpointUrl
          : endpointUrl // ignore: cast_nullable_to_non_nullable
              as String,
      httpMethod: null == httpMethod
          ? _value.httpMethod
          : httpMethod // ignore: cast_nullable_to_non_nullable
              as HttpMethod,
      serviceType: null == serviceType
          ? _value.serviceType
          : serviceType // ignore: cast_nullable_to_non_nullable
              as ServiceType,
      headers: freezed == headers
          ? _value.headers
          : headers // ignore: cast_nullable_to_non_nullable
              as Map<String, String>?,
      requestBody: freezed == requestBody
          ? _value.requestBody
          : requestBody // ignore: cast_nullable_to_non_nullable
              as String?,
      expectedStatusCodes: null == expectedStatusCodes
          ? _value.expectedStatusCodes
          : expectedStatusCodes // ignore: cast_nullable_to_non_nullable
              as List<int>,
      timeoutSeconds: null == timeoutSeconds
          ? _value.timeoutSeconds
          : timeoutSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      checkIntervalSeconds: null == checkIntervalSeconds
          ? _value.checkIntervalSeconds
          : checkIntervalSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      failureThreshold: null == failureThreshold
          ? _value.failureThreshold
          : failureThreshold // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ServiceCreateImplCopyWith<$Res>
    implements $ServiceCreateCopyWith<$Res> {
  factory _$$ServiceCreateImplCopyWith(
          _$ServiceCreateImpl value, $Res Function(_$ServiceCreateImpl) then) =
      __$$ServiceCreateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String name,
      String? description,
      String endpointUrl,
      HttpMethod httpMethod,
      ServiceType serviceType,
      Map<String, String>? headers,
      String? requestBody,
      List<int> expectedStatusCodes,
      int timeoutSeconds,
      int checkIntervalSeconds,
      int failureThreshold});
}

/// @nodoc
class __$$ServiceCreateImplCopyWithImpl<$Res>
    extends _$ServiceCreateCopyWithImpl<$Res, _$ServiceCreateImpl>
    implements _$$ServiceCreateImplCopyWith<$Res> {
  __$$ServiceCreateImplCopyWithImpl(
      _$ServiceCreateImpl _value, $Res Function(_$ServiceCreateImpl) _then)
      : super(_value, _then);

  /// Create a copy of ServiceCreate
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
    Object? endpointUrl = null,
    Object? httpMethod = null,
    Object? serviceType = null,
    Object? headers = freezed,
    Object? requestBody = freezed,
    Object? expectedStatusCodes = null,
    Object? timeoutSeconds = null,
    Object? checkIntervalSeconds = null,
    Object? failureThreshold = null,
  }) {
    return _then(_$ServiceCreateImpl(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      endpointUrl: null == endpointUrl
          ? _value.endpointUrl
          : endpointUrl // ignore: cast_nullable_to_non_nullable
              as String,
      httpMethod: null == httpMethod
          ? _value.httpMethod
          : httpMethod // ignore: cast_nullable_to_non_nullable
              as HttpMethod,
      serviceType: null == serviceType
          ? _value.serviceType
          : serviceType // ignore: cast_nullable_to_non_nullable
              as ServiceType,
      headers: freezed == headers
          ? _value._headers
          : headers // ignore: cast_nullable_to_non_nullable
              as Map<String, String>?,
      requestBody: freezed == requestBody
          ? _value.requestBody
          : requestBody // ignore: cast_nullable_to_non_nullable
              as String?,
      expectedStatusCodes: null == expectedStatusCodes
          ? _value._expectedStatusCodes
          : expectedStatusCodes // ignore: cast_nullable_to_non_nullable
              as List<int>,
      timeoutSeconds: null == timeoutSeconds
          ? _value.timeoutSeconds
          : timeoutSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      checkIntervalSeconds: null == checkIntervalSeconds
          ? _value.checkIntervalSeconds
          : checkIntervalSeconds // ignore: cast_nullable_to_non_nullable
              as int,
      failureThreshold: null == failureThreshold
          ? _value.failureThreshold
          : failureThreshold // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$ServiceCreateImpl implements _ServiceCreate {
  const _$ServiceCreateImpl(
      {required this.name,
      this.description,
      required this.endpointUrl,
      required this.httpMethod,
      required this.serviceType,
      final Map<String, String>? headers,
      this.requestBody,
      final List<int> expectedStatusCodes = const [200],
      this.timeoutSeconds = 10,
      this.checkIntervalSeconds = 60,
      this.failureThreshold = 3})
      : _headers = headers,
        _expectedStatusCodes = expectedStatusCodes;

  @override
  final String name;
  @override
  final String? description;
  @override
  final String endpointUrl;
  @override
  final HttpMethod httpMethod;
  @override
  final ServiceType serviceType;
  final Map<String, String>? _headers;
  @override
  Map<String, String>? get headers {
    final value = _headers;
    if (value == null) return null;
    if (_headers is EqualUnmodifiableMapView) return _headers;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(value);
  }

  @override
  final String? requestBody;
  final List<int> _expectedStatusCodes;
  @override
  @JsonKey()
  List<int> get expectedStatusCodes {
    if (_expectedStatusCodes is EqualUnmodifiableListView)
      return _expectedStatusCodes;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_expectedStatusCodes);
  }

  @override
  @JsonKey()
  final int timeoutSeconds;
  @override
  @JsonKey()
  final int checkIntervalSeconds;
  @override
  @JsonKey()
  final int failureThreshold;

  @override
  String toString() {
    return 'ServiceCreate(name: $name, description: $description, endpointUrl: $endpointUrl, httpMethod: $httpMethod, serviceType: $serviceType, headers: $headers, requestBody: $requestBody, expectedStatusCodes: $expectedStatusCodes, timeoutSeconds: $timeoutSeconds, checkIntervalSeconds: $checkIntervalSeconds, failureThreshold: $failureThreshold)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ServiceCreateImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.endpointUrl, endpointUrl) ||
                other.endpointUrl == endpointUrl) &&
            (identical(other.httpMethod, httpMethod) ||
                other.httpMethod == httpMethod) &&
            (identical(other.serviceType, serviceType) ||
                other.serviceType == serviceType) &&
            const DeepCollectionEquality().equals(other._headers, _headers) &&
            (identical(other.requestBody, requestBody) ||
                other.requestBody == requestBody) &&
            const DeepCollectionEquality()
                .equals(other._expectedStatusCodes, _expectedStatusCodes) &&
            (identical(other.timeoutSeconds, timeoutSeconds) ||
                other.timeoutSeconds == timeoutSeconds) &&
            (identical(other.checkIntervalSeconds, checkIntervalSeconds) ||
                other.checkIntervalSeconds == checkIntervalSeconds) &&
            (identical(other.failureThreshold, failureThreshold) ||
                other.failureThreshold == failureThreshold));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      name,
      description,
      endpointUrl,
      httpMethod,
      serviceType,
      const DeepCollectionEquality().hash(_headers),
      requestBody,
      const DeepCollectionEquality().hash(_expectedStatusCodes),
      timeoutSeconds,
      checkIntervalSeconds,
      failureThreshold);

  /// Create a copy of ServiceCreate
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ServiceCreateImplCopyWith<_$ServiceCreateImpl> get copyWith =>
      __$$ServiceCreateImplCopyWithImpl<_$ServiceCreateImpl>(this, _$identity);
}

abstract class _ServiceCreate implements ServiceCreate {
  const factory _ServiceCreate(
      {required final String name,
      final String? description,
      required final String endpointUrl,
      required final HttpMethod httpMethod,
      required final ServiceType serviceType,
      final Map<String, String>? headers,
      final String? requestBody,
      final List<int> expectedStatusCodes,
      final int timeoutSeconds,
      final int checkIntervalSeconds,
      final int failureThreshold}) = _$ServiceCreateImpl;

  @override
  String get name;
  @override
  String? get description;
  @override
  String get endpointUrl;
  @override
  HttpMethod get httpMethod;
  @override
  ServiceType get serviceType;
  @override
  Map<String, String>? get headers;
  @override
  String? get requestBody;
  @override
  List<int> get expectedStatusCodes;
  @override
  int get timeoutSeconds;
  @override
  int get checkIntervalSeconds;
  @override
  int get failureThreshold;

  /// Create a copy of ServiceCreate
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ServiceCreateImplCopyWith<_$ServiceCreateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ServiceUpdate {
  String? get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  String? get endpointUrl => throw _privateConstructorUsedError;
  HttpMethod? get httpMethod => throw _privateConstructorUsedError;
  ServiceType? get serviceType => throw _privateConstructorUsedError;
  Map<String, String>? get headers => throw _privateConstructorUsedError;
  String? get requestBody => throw _privateConstructorUsedError;
  List<int>? get expectedStatusCodes => throw _privateConstructorUsedError;
  int? get timeoutSeconds => throw _privateConstructorUsedError;
  int? get checkIntervalSeconds => throw _privateConstructorUsedError;
  int? get failureThreshold => throw _privateConstructorUsedError;
  bool? get isActive => throw _privateConstructorUsedError;

  /// Create a copy of ServiceUpdate
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ServiceUpdateCopyWith<ServiceUpdate> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ServiceUpdateCopyWith<$Res> {
  factory $ServiceUpdateCopyWith(
          ServiceUpdate value, $Res Function(ServiceUpdate) then) =
      _$ServiceUpdateCopyWithImpl<$Res, ServiceUpdate>;
  @useResult
  $Res call(
      {String? name,
      String? description,
      String? endpointUrl,
      HttpMethod? httpMethod,
      ServiceType? serviceType,
      Map<String, String>? headers,
      String? requestBody,
      List<int>? expectedStatusCodes,
      int? timeoutSeconds,
      int? checkIntervalSeconds,
      int? failureThreshold,
      bool? isActive});
}

/// @nodoc
class _$ServiceUpdateCopyWithImpl<$Res, $Val extends ServiceUpdate>
    implements $ServiceUpdateCopyWith<$Res> {
  _$ServiceUpdateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ServiceUpdate
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = freezed,
    Object? description = freezed,
    Object? endpointUrl = freezed,
    Object? httpMethod = freezed,
    Object? serviceType = freezed,
    Object? headers = freezed,
    Object? requestBody = freezed,
    Object? expectedStatusCodes = freezed,
    Object? timeoutSeconds = freezed,
    Object? checkIntervalSeconds = freezed,
    Object? failureThreshold = freezed,
    Object? isActive = freezed,
  }) {
    return _then(_value.copyWith(
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      endpointUrl: freezed == endpointUrl
          ? _value.endpointUrl
          : endpointUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      httpMethod: freezed == httpMethod
          ? _value.httpMethod
          : httpMethod // ignore: cast_nullable_to_non_nullable
              as HttpMethod?,
      serviceType: freezed == serviceType
          ? _value.serviceType
          : serviceType // ignore: cast_nullable_to_non_nullable
              as ServiceType?,
      headers: freezed == headers
          ? _value.headers
          : headers // ignore: cast_nullable_to_non_nullable
              as Map<String, String>?,
      requestBody: freezed == requestBody
          ? _value.requestBody
          : requestBody // ignore: cast_nullable_to_non_nullable
              as String?,
      expectedStatusCodes: freezed == expectedStatusCodes
          ? _value.expectedStatusCodes
          : expectedStatusCodes // ignore: cast_nullable_to_non_nullable
              as List<int>?,
      timeoutSeconds: freezed == timeoutSeconds
          ? _value.timeoutSeconds
          : timeoutSeconds // ignore: cast_nullable_to_non_nullable
              as int?,
      checkIntervalSeconds: freezed == checkIntervalSeconds
          ? _value.checkIntervalSeconds
          : checkIntervalSeconds // ignore: cast_nullable_to_non_nullable
              as int?,
      failureThreshold: freezed == failureThreshold
          ? _value.failureThreshold
          : failureThreshold // ignore: cast_nullable_to_non_nullable
              as int?,
      isActive: freezed == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ServiceUpdateImplCopyWith<$Res>
    implements $ServiceUpdateCopyWith<$Res> {
  factory _$$ServiceUpdateImplCopyWith(
          _$ServiceUpdateImpl value, $Res Function(_$ServiceUpdateImpl) then) =
      __$$ServiceUpdateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? name,
      String? description,
      String? endpointUrl,
      HttpMethod? httpMethod,
      ServiceType? serviceType,
      Map<String, String>? headers,
      String? requestBody,
      List<int>? expectedStatusCodes,
      int? timeoutSeconds,
      int? checkIntervalSeconds,
      int? failureThreshold,
      bool? isActive});
}

/// @nodoc
class __$$ServiceUpdateImplCopyWithImpl<$Res>
    extends _$ServiceUpdateCopyWithImpl<$Res, _$ServiceUpdateImpl>
    implements _$$ServiceUpdateImplCopyWith<$Res> {
  __$$ServiceUpdateImplCopyWithImpl(
      _$ServiceUpdateImpl _value, $Res Function(_$ServiceUpdateImpl) _then)
      : super(_value, _then);

  /// Create a copy of ServiceUpdate
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = freezed,
    Object? description = freezed,
    Object? endpointUrl = freezed,
    Object? httpMethod = freezed,
    Object? serviceType = freezed,
    Object? headers = freezed,
    Object? requestBody = freezed,
    Object? expectedStatusCodes = freezed,
    Object? timeoutSeconds = freezed,
    Object? checkIntervalSeconds = freezed,
    Object? failureThreshold = freezed,
    Object? isActive = freezed,
  }) {
    return _then(_$ServiceUpdateImpl(
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      endpointUrl: freezed == endpointUrl
          ? _value.endpointUrl
          : endpointUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      httpMethod: freezed == httpMethod
          ? _value.httpMethod
          : httpMethod // ignore: cast_nullable_to_non_nullable
              as HttpMethod?,
      serviceType: freezed == serviceType
          ? _value.serviceType
          : serviceType // ignore: cast_nullable_to_non_nullable
              as ServiceType?,
      headers: freezed == headers
          ? _value._headers
          : headers // ignore: cast_nullable_to_non_nullable
              as Map<String, String>?,
      requestBody: freezed == requestBody
          ? _value.requestBody
          : requestBody // ignore: cast_nullable_to_non_nullable
              as String?,
      expectedStatusCodes: freezed == expectedStatusCodes
          ? _value._expectedStatusCodes
          : expectedStatusCodes // ignore: cast_nullable_to_non_nullable
              as List<int>?,
      timeoutSeconds: freezed == timeoutSeconds
          ? _value.timeoutSeconds
          : timeoutSeconds // ignore: cast_nullable_to_non_nullable
              as int?,
      checkIntervalSeconds: freezed == checkIntervalSeconds
          ? _value.checkIntervalSeconds
          : checkIntervalSeconds // ignore: cast_nullable_to_non_nullable
              as int?,
      failureThreshold: freezed == failureThreshold
          ? _value.failureThreshold
          : failureThreshold // ignore: cast_nullable_to_non_nullable
              as int?,
      isActive: freezed == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$ServiceUpdateImpl implements _ServiceUpdate {
  const _$ServiceUpdateImpl(
      {this.name,
      this.description,
      this.endpointUrl,
      this.httpMethod,
      this.serviceType,
      final Map<String, String>? headers,
      this.requestBody,
      final List<int>? expectedStatusCodes,
      this.timeoutSeconds,
      this.checkIntervalSeconds,
      this.failureThreshold,
      this.isActive})
      : _headers = headers,
        _expectedStatusCodes = expectedStatusCodes;

  @override
  final String? name;
  @override
  final String? description;
  @override
  final String? endpointUrl;
  @override
  final HttpMethod? httpMethod;
  @override
  final ServiceType? serviceType;
  final Map<String, String>? _headers;
  @override
  Map<String, String>? get headers {
    final value = _headers;
    if (value == null) return null;
    if (_headers is EqualUnmodifiableMapView) return _headers;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(value);
  }

  @override
  final String? requestBody;
  final List<int>? _expectedStatusCodes;
  @override
  List<int>? get expectedStatusCodes {
    final value = _expectedStatusCodes;
    if (value == null) return null;
    if (_expectedStatusCodes is EqualUnmodifiableListView)
      return _expectedStatusCodes;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  final int? timeoutSeconds;
  @override
  final int? checkIntervalSeconds;
  @override
  final int? failureThreshold;
  @override
  final bool? isActive;

  @override
  String toString() {
    return 'ServiceUpdate(name: $name, description: $description, endpointUrl: $endpointUrl, httpMethod: $httpMethod, serviceType: $serviceType, headers: $headers, requestBody: $requestBody, expectedStatusCodes: $expectedStatusCodes, timeoutSeconds: $timeoutSeconds, checkIntervalSeconds: $checkIntervalSeconds, failureThreshold: $failureThreshold, isActive: $isActive)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ServiceUpdateImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.endpointUrl, endpointUrl) ||
                other.endpointUrl == endpointUrl) &&
            (identical(other.httpMethod, httpMethod) ||
                other.httpMethod == httpMethod) &&
            (identical(other.serviceType, serviceType) ||
                other.serviceType == serviceType) &&
            const DeepCollectionEquality().equals(other._headers, _headers) &&
            (identical(other.requestBody, requestBody) ||
                other.requestBody == requestBody) &&
            const DeepCollectionEquality()
                .equals(other._expectedStatusCodes, _expectedStatusCodes) &&
            (identical(other.timeoutSeconds, timeoutSeconds) ||
                other.timeoutSeconds == timeoutSeconds) &&
            (identical(other.checkIntervalSeconds, checkIntervalSeconds) ||
                other.checkIntervalSeconds == checkIntervalSeconds) &&
            (identical(other.failureThreshold, failureThreshold) ||
                other.failureThreshold == failureThreshold) &&
            (identical(other.isActive, isActive) ||
                other.isActive == isActive));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      name,
      description,
      endpointUrl,
      httpMethod,
      serviceType,
      const DeepCollectionEquality().hash(_headers),
      requestBody,
      const DeepCollectionEquality().hash(_expectedStatusCodes),
      timeoutSeconds,
      checkIntervalSeconds,
      failureThreshold,
      isActive);

  /// Create a copy of ServiceUpdate
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ServiceUpdateImplCopyWith<_$ServiceUpdateImpl> get copyWith =>
      __$$ServiceUpdateImplCopyWithImpl<_$ServiceUpdateImpl>(this, _$identity);
}

abstract class _ServiceUpdate implements ServiceUpdate {
  const factory _ServiceUpdate(
      {final String? name,
      final String? description,
      final String? endpointUrl,
      final HttpMethod? httpMethod,
      final ServiceType? serviceType,
      final Map<String, String>? headers,
      final String? requestBody,
      final List<int>? expectedStatusCodes,
      final int? timeoutSeconds,
      final int? checkIntervalSeconds,
      final int? failureThreshold,
      final bool? isActive}) = _$ServiceUpdateImpl;

  @override
  String? get name;
  @override
  String? get description;
  @override
  String? get endpointUrl;
  @override
  HttpMethod? get httpMethod;
  @override
  ServiceType? get serviceType;
  @override
  Map<String, String>? get headers;
  @override
  String? get requestBody;
  @override
  List<int>? get expectedStatusCodes;
  @override
  int? get timeoutSeconds;
  @override
  int? get checkIntervalSeconds;
  @override
  int? get failureThreshold;
  @override
  bool? get isActive;

  /// Create a copy of ServiceUpdate
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ServiceUpdateImplCopyWith<_$ServiceUpdateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
