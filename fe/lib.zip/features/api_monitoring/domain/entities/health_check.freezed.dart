// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'health_check.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$HealthCheck {
  String get id => throw _privateConstructorUsedError;
  String get serviceId => throw _privateConstructorUsedError;
  bool get isAlive => throw _privateConstructorUsedError;
  int? get statusCode => throw _privateConstructorUsedError;
  int? get latencyMs => throw _privateConstructorUsedError;
  String? get responseBody => throw _privateConstructorUsedError;
  String? get errorMessage => throw _privateConstructorUsedError;
  String? get errorType => throw _privateConstructorUsedError;
  DateTime get checkedAt => throw _privateConstructorUsedError;
  bool get needsAnalysis => throw _privateConstructorUsedError;

  /// Create a copy of HealthCheck
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $HealthCheckCopyWith<HealthCheck> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HealthCheckCopyWith<$Res> {
  factory $HealthCheckCopyWith(
          HealthCheck value, $Res Function(HealthCheck) then) =
      _$HealthCheckCopyWithImpl<$Res, HealthCheck>;
  @useResult
  $Res call(
      {String id,
      String serviceId,
      bool isAlive,
      int? statusCode,
      int? latencyMs,
      String? responseBody,
      String? errorMessage,
      String? errorType,
      DateTime checkedAt,
      bool needsAnalysis});
}

/// @nodoc
class _$HealthCheckCopyWithImpl<$Res, $Val extends HealthCheck>
    implements $HealthCheckCopyWith<$Res> {
  _$HealthCheckCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of HealthCheck
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? serviceId = null,
    Object? isAlive = null,
    Object? statusCode = freezed,
    Object? latencyMs = freezed,
    Object? responseBody = freezed,
    Object? errorMessage = freezed,
    Object? errorType = freezed,
    Object? checkedAt = null,
    Object? needsAnalysis = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      serviceId: null == serviceId
          ? _value.serviceId
          : serviceId // ignore: cast_nullable_to_non_nullable
              as String,
      isAlive: null == isAlive
          ? _value.isAlive
          : isAlive // ignore: cast_nullable_to_non_nullable
              as bool,
      statusCode: freezed == statusCode
          ? _value.statusCode
          : statusCode // ignore: cast_nullable_to_non_nullable
              as int?,
      latencyMs: freezed == latencyMs
          ? _value.latencyMs
          : latencyMs // ignore: cast_nullable_to_non_nullable
              as int?,
      responseBody: freezed == responseBody
          ? _value.responseBody
          : responseBody // ignore: cast_nullable_to_non_nullable
              as String?,
      errorMessage: freezed == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String?,
      errorType: freezed == errorType
          ? _value.errorType
          : errorType // ignore: cast_nullable_to_non_nullable
              as String?,
      checkedAt: null == checkedAt
          ? _value.checkedAt
          : checkedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      needsAnalysis: null == needsAnalysis
          ? _value.needsAnalysis
          : needsAnalysis // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$HealthCheckImplCopyWith<$Res>
    implements $HealthCheckCopyWith<$Res> {
  factory _$$HealthCheckImplCopyWith(
          _$HealthCheckImpl value, $Res Function(_$HealthCheckImpl) then) =
      __$$HealthCheckImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String serviceId,
      bool isAlive,
      int? statusCode,
      int? latencyMs,
      String? responseBody,
      String? errorMessage,
      String? errorType,
      DateTime checkedAt,
      bool needsAnalysis});
}

/// @nodoc
class __$$HealthCheckImplCopyWithImpl<$Res>
    extends _$HealthCheckCopyWithImpl<$Res, _$HealthCheckImpl>
    implements _$$HealthCheckImplCopyWith<$Res> {
  __$$HealthCheckImplCopyWithImpl(
      _$HealthCheckImpl _value, $Res Function(_$HealthCheckImpl) _then)
      : super(_value, _then);

  /// Create a copy of HealthCheck
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? serviceId = null,
    Object? isAlive = null,
    Object? statusCode = freezed,
    Object? latencyMs = freezed,
    Object? responseBody = freezed,
    Object? errorMessage = freezed,
    Object? errorType = freezed,
    Object? checkedAt = null,
    Object? needsAnalysis = null,
  }) {
    return _then(_$HealthCheckImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      serviceId: null == serviceId
          ? _value.serviceId
          : serviceId // ignore: cast_nullable_to_non_nullable
              as String,
      isAlive: null == isAlive
          ? _value.isAlive
          : isAlive // ignore: cast_nullable_to_non_nullable
              as bool,
      statusCode: freezed == statusCode
          ? _value.statusCode
          : statusCode // ignore: cast_nullable_to_non_nullable
              as int?,
      latencyMs: freezed == latencyMs
          ? _value.latencyMs
          : latencyMs // ignore: cast_nullable_to_non_nullable
              as int?,
      responseBody: freezed == responseBody
          ? _value.responseBody
          : responseBody // ignore: cast_nullable_to_non_nullable
              as String?,
      errorMessage: freezed == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as String?,
      errorType: freezed == errorType
          ? _value.errorType
          : errorType // ignore: cast_nullable_to_non_nullable
              as String?,
      checkedAt: null == checkedAt
          ? _value.checkedAt
          : checkedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      needsAnalysis: null == needsAnalysis
          ? _value.needsAnalysis
          : needsAnalysis // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$HealthCheckImpl extends _HealthCheck {
  const _$HealthCheckImpl(
      {required this.id,
      required this.serviceId,
      required this.isAlive,
      this.statusCode,
      this.latencyMs,
      this.responseBody,
      this.errorMessage,
      this.errorType,
      required this.checkedAt,
      required this.needsAnalysis})
      : super._();

  @override
  final String id;
  @override
  final String serviceId;
  @override
  final bool isAlive;
  @override
  final int? statusCode;
  @override
  final int? latencyMs;
  @override
  final String? responseBody;
  @override
  final String? errorMessage;
  @override
  final String? errorType;
  @override
  final DateTime checkedAt;
  @override
  final bool needsAnalysis;

  @override
  String toString() {
    return 'HealthCheck(id: $id, serviceId: $serviceId, isAlive: $isAlive, statusCode: $statusCode, latencyMs: $latencyMs, responseBody: $responseBody, errorMessage: $errorMessage, errorType: $errorType, checkedAt: $checkedAt, needsAnalysis: $needsAnalysis)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$HealthCheckImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.serviceId, serviceId) ||
                other.serviceId == serviceId) &&
            (identical(other.isAlive, isAlive) || other.isAlive == isAlive) &&
            (identical(other.statusCode, statusCode) ||
                other.statusCode == statusCode) &&
            (identical(other.latencyMs, latencyMs) ||
                other.latencyMs == latencyMs) &&
            (identical(other.responseBody, responseBody) ||
                other.responseBody == responseBody) &&
            (identical(other.errorMessage, errorMessage) ||
                other.errorMessage == errorMessage) &&
            (identical(other.errorType, errorType) ||
                other.errorType == errorType) &&
            (identical(other.checkedAt, checkedAt) ||
                other.checkedAt == checkedAt) &&
            (identical(other.needsAnalysis, needsAnalysis) ||
                other.needsAnalysis == needsAnalysis));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      serviceId,
      isAlive,
      statusCode,
      latencyMs,
      responseBody,
      errorMessage,
      errorType,
      checkedAt,
      needsAnalysis);

  /// Create a copy of HealthCheck
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$HealthCheckImplCopyWith<_$HealthCheckImpl> get copyWith =>
      __$$HealthCheckImplCopyWithImpl<_$HealthCheckImpl>(this, _$identity);
}

abstract class _HealthCheck extends HealthCheck {
  const factory _HealthCheck(
      {required final String id,
      required final String serviceId,
      required final bool isAlive,
      final int? statusCode,
      final int? latencyMs,
      final String? responseBody,
      final String? errorMessage,
      final String? errorType,
      required final DateTime checkedAt,
      required final bool needsAnalysis}) = _$HealthCheckImpl;
  const _HealthCheck._() : super._();

  @override
  String get id;
  @override
  String get serviceId;
  @override
  bool get isAlive;
  @override
  int? get statusCode;
  @override
  int? get latencyMs;
  @override
  String? get responseBody;
  @override
  String? get errorMessage;
  @override
  String? get errorType;
  @override
  DateTime get checkedAt;
  @override
  bool get needsAnalysis;

  /// Create a copy of HealthCheck
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$HealthCheckImplCopyWith<_$HealthCheckImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
