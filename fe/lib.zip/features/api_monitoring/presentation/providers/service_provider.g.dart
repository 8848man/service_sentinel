// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'service_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$loadServicesHash() => r'87629d5813a1c45905e0091ed526f969daaa0a79';

/// Provider for LoadServices use case
///
/// Copied from [loadServices].
@ProviderFor(loadServices)
final loadServicesProvider = AutoDisposeProvider<LoadServices>.internal(
  loadServices,
  name: r'loadServicesProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$loadServicesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef LoadServicesRef = AutoDisposeProviderRef<LoadServices>;
String _$servicesHash() => r'faf7301981ec28cb2d3df0ad611d6a5a21788013';

/// Provider to fetch all services for current project
/// This provider auto-refreshes when dependencies change
///
/// Copied from [services].
@ProviderFor(services)
final servicesProvider = AutoDisposeFutureProvider<List<Service>>.internal(
  services,
  name: r'servicesProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$servicesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef ServicesRef = AutoDisposeFutureProviderRef<List<Service>>;
String _$activeServicesHash() => r'385bbf830dc70bfdde183345d51c285e41e34d33';

/// Provider to fetch active services only
///
/// Copied from [activeServices].
@ProviderFor(activeServices)
final activeServicesProvider =
    AutoDisposeFutureProvider<List<Service>>.internal(
  activeServices,
  name: r'activeServicesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$activeServicesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef ActiveServicesRef = AutoDisposeFutureProviderRef<List<Service>>;
String _$serviceByIdHash() => r'3bd678af891bf1ae72daa7047764d264da8eed97';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

/// Provider to fetch a service by ID
///
/// Copied from [serviceById].
@ProviderFor(serviceById)
const serviceByIdProvider = ServiceByIdFamily();

/// Provider to fetch a service by ID
///
/// Copied from [serviceById].
class ServiceByIdFamily extends Family<AsyncValue<Service>> {
  /// Provider to fetch a service by ID
  ///
  /// Copied from [serviceById].
  const ServiceByIdFamily();

  /// Provider to fetch a service by ID
  ///
  /// Copied from [serviceById].
  ServiceByIdProvider call(
    int serviceId,
  ) {
    return ServiceByIdProvider(
      serviceId,
    );
  }

  @override
  ServiceByIdProvider getProviderOverride(
    covariant ServiceByIdProvider provider,
  ) {
    return call(
      provider.serviceId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'serviceByIdProvider';
}

/// Provider to fetch a service by ID
///
/// Copied from [serviceById].
class ServiceByIdProvider extends AutoDisposeFutureProvider<Service> {
  /// Provider to fetch a service by ID
  ///
  /// Copied from [serviceById].
  ServiceByIdProvider(
    int serviceId,
  ) : this._internal(
          (ref) => serviceById(
            ref as ServiceByIdRef,
            serviceId,
          ),
          from: serviceByIdProvider,
          name: r'serviceByIdProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$serviceByIdHash,
          dependencies: ServiceByIdFamily._dependencies,
          allTransitiveDependencies:
              ServiceByIdFamily._allTransitiveDependencies,
          serviceId: serviceId,
        );

  ServiceByIdProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.serviceId,
  }) : super.internal();

  final int serviceId;

  @override
  Override overrideWith(
    FutureOr<Service> Function(ServiceByIdRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: ServiceByIdProvider._internal(
        (ref) => create(ref as ServiceByIdRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        serviceId: serviceId,
      ),
    );
  }

  @override
  AutoDisposeFutureProviderElement<Service> createElement() {
    return _ServiceByIdProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is ServiceByIdProvider && other.serviceId == serviceId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, serviceId.hashCode);

    return _SystemHash.finish(hash);
  }
}

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
mixin ServiceByIdRef on AutoDisposeFutureProviderRef<Service> {
  /// The parameter `serviceId` of this provider.
  int get serviceId;
}

class _ServiceByIdProviderElement
    extends AutoDisposeFutureProviderElement<Service> with ServiceByIdRef {
  _ServiceByIdProviderElement(super.provider);

  @override
  int get serviceId => (origin as ServiceByIdProvider).serviceId;
}

String _$serviceStatsHash() => r'b4a82ea9279abf395f9763212f9826d366674aa9';

/// Provider to fetch service statistics
///
/// Copied from [serviceStats].
@ProviderFor(serviceStats)
const serviceStatsProvider = ServiceStatsFamily();

/// Provider to fetch service statistics
///
/// Copied from [serviceStats].
class ServiceStatsFamily extends Family<AsyncValue<ServiceStats>> {
  /// Provider to fetch service statistics
  ///
  /// Copied from [serviceStats].
  const ServiceStatsFamily();

  /// Provider to fetch service statistics
  ///
  /// Copied from [serviceStats].
  ServiceStatsProvider call(
    int serviceId,
    String period,
  ) {
    return ServiceStatsProvider(
      serviceId,
      period,
    );
  }

  @override
  ServiceStatsProvider getProviderOverride(
    covariant ServiceStatsProvider provider,
  ) {
    return call(
      provider.serviceId,
      provider.period,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'serviceStatsProvider';
}

/// Provider to fetch service statistics
///
/// Copied from [serviceStats].
class ServiceStatsProvider extends AutoDisposeFutureProvider<ServiceStats> {
  /// Provider to fetch service statistics
  ///
  /// Copied from [serviceStats].
  ServiceStatsProvider(
    int serviceId,
    String period,
  ) : this._internal(
          (ref) => serviceStats(
            ref as ServiceStatsRef,
            serviceId,
            period,
          ),
          from: serviceStatsProvider,
          name: r'serviceStatsProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$serviceStatsHash,
          dependencies: ServiceStatsFamily._dependencies,
          allTransitiveDependencies:
              ServiceStatsFamily._allTransitiveDependencies,
          serviceId: serviceId,
          period: period,
        );

  ServiceStatsProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.serviceId,
    required this.period,
  }) : super.internal();

  final int serviceId;
  final String period;

  @override
  Override overrideWith(
    FutureOr<ServiceStats> Function(ServiceStatsRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: ServiceStatsProvider._internal(
        (ref) => create(ref as ServiceStatsRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        serviceId: serviceId,
        period: period,
      ),
    );
  }

  @override
  AutoDisposeFutureProviderElement<ServiceStats> createElement() {
    return _ServiceStatsProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is ServiceStatsProvider &&
        other.serviceId == serviceId &&
        other.period == period;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, serviceId.hashCode);
    hash = _SystemHash.combine(hash, period.hashCode);

    return _SystemHash.finish(hash);
  }
}

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
mixin ServiceStatsRef on AutoDisposeFutureProviderRef<ServiceStats> {
  /// The parameter `serviceId` of this provider.
  int get serviceId;

  /// The parameter `period` of this provider.
  String get period;
}

class _ServiceStatsProviderElement
    extends AutoDisposeFutureProviderElement<ServiceStats>
    with ServiceStatsRef {
  _ServiceStatsProviderElement(super.provider);

  @override
  int get serviceId => (origin as ServiceStatsProvider).serviceId;
  @override
  String get period => (origin as ServiceStatsProvider).period;
}

String _$createServiceHash() => r'3d1746f834f03089d0f8a2dfb8e3380fcaa6afe1';

/// Provider for CreateService use case
///
/// Copied from [createService].
@ProviderFor(createService)
final createServiceProvider = AutoDisposeProvider<CreateService>.internal(
  createService,
  name: r'createServiceProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$createServiceHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef CreateServiceRef = AutoDisposeProviderRef<CreateService>;
String _$updateServiceHash() => r'07aa7754c2fb3cdc9936a2f0f913ddf5217538b9';

/// Provider for UpdateService use case
///
/// Copied from [updateService].
@ProviderFor(updateService)
final updateServiceProvider = AutoDisposeProvider<UpdateService>.internal(
  updateService,
  name: r'updateServiceProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$updateServiceHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef UpdateServiceRef = AutoDisposeProviderRef<UpdateService>;
String _$deleteServiceHash() => r'0b2fda2c3686655a51c3c2bec8c0eb39456d23a2';

/// Provider for DeleteService use case
///
/// Copied from [deleteService].
@ProviderFor(deleteService)
final deleteServiceProvider = AutoDisposeProvider<DeleteService>.internal(
  deleteService,
  name: r'deleteServiceProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$deleteServiceHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef DeleteServiceRef = AutoDisposeProviderRef<DeleteService>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
