// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_service_view_model.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$addServiceViewModelHash() =>
    r'9f12779d7d9aac7122d6296ed7a7e4750a36f5ab';

/// See also [AddServiceViewModel].
@ProviderFor(AddServiceViewModel)
final addServiceViewModelProvider =
    AutoDisposeNotifierProvider<AddServiceViewModel, AddServiceState>.internal(
  AddServiceViewModel.new,
  name: r'addServiceViewModelProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$addServiceViewModelHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AddServiceViewModel = AutoDisposeNotifier<AddServiceState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
