// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'add_service_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$AddServiceState {
  bool get isLoading => throw _privateConstructorUsedError;
  Map<String, String> get errorMessage => throw _privateConstructorUsedError;

  /// Create a copy of AddServiceState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $AddServiceStateCopyWith<AddServiceState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AddServiceStateCopyWith<$Res> {
  factory $AddServiceStateCopyWith(
          AddServiceState value, $Res Function(AddServiceState) then) =
      _$AddServiceStateCopyWithImpl<$Res, AddServiceState>;
  @useResult
  $Res call({bool isLoading, Map<String, String> errorMessage});
}

/// @nodoc
class _$AddServiceStateCopyWithImpl<$Res, $Val extends AddServiceState>
    implements $AddServiceStateCopyWith<$Res> {
  _$AddServiceStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of AddServiceState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? errorMessage = null,
  }) {
    return _then(_value.copyWith(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      errorMessage: null == errorMessage
          ? _value.errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as Map<String, String>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AddServiceStateImplCopyWith<$Res>
    implements $AddServiceStateCopyWith<$Res> {
  factory _$$AddServiceStateImplCopyWith(_$AddServiceStateImpl value,
          $Res Function(_$AddServiceStateImpl) then) =
      __$$AddServiceStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({bool isLoading, Map<String, String> errorMessage});
}

/// @nodoc
class __$$AddServiceStateImplCopyWithImpl<$Res>
    extends _$AddServiceStateCopyWithImpl<$Res, _$AddServiceStateImpl>
    implements _$$AddServiceStateImplCopyWith<$Res> {
  __$$AddServiceStateImplCopyWithImpl(
      _$AddServiceStateImpl _value, $Res Function(_$AddServiceStateImpl) _then)
      : super(_value, _then);

  /// Create a copy of AddServiceState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? isLoading = null,
    Object? errorMessage = null,
  }) {
    return _then(_$AddServiceStateImpl(
      isLoading: null == isLoading
          ? _value.isLoading
          : isLoading // ignore: cast_nullable_to_non_nullable
              as bool,
      errorMessage: null == errorMessage
          ? _value._errorMessage
          : errorMessage // ignore: cast_nullable_to_non_nullable
              as Map<String, String>,
    ));
  }
}

/// @nodoc

class _$AddServiceStateImpl implements _AddServiceState {
  const _$AddServiceStateImpl(
      {this.isLoading = false,
      final Map<String, String> errorMessage = const <String, String>{}})
      : _errorMessage = errorMessage;

  @override
  @JsonKey()
  final bool isLoading;
  final Map<String, String> _errorMessage;
  @override
  @JsonKey()
  Map<String, String> get errorMessage {
    if (_errorMessage is EqualUnmodifiableMapView) return _errorMessage;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_errorMessage);
  }

  @override
  String toString() {
    return 'AddServiceState(isLoading: $isLoading, errorMessage: $errorMessage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AddServiceStateImpl &&
            (identical(other.isLoading, isLoading) ||
                other.isLoading == isLoading) &&
            const DeepCollectionEquality()
                .equals(other._errorMessage, _errorMessage));
  }

  @override
  int get hashCode => Object.hash(runtimeType, isLoading,
      const DeepCollectionEquality().hash(_errorMessage));

  /// Create a copy of AddServiceState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$AddServiceStateImplCopyWith<_$AddServiceStateImpl> get copyWith =>
      __$$AddServiceStateImplCopyWithImpl<_$AddServiceStateImpl>(
          this, _$identity);
}

abstract class _AddServiceState implements AddServiceState {
  const factory _AddServiceState(
      {final bool isLoading,
      final Map<String, String> errorMessage}) = _$AddServiceStateImpl;

  @override
  bool get isLoading;
  @override
  Map<String, String> get errorMessage;

  /// Create a copy of AddServiceState
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$AddServiceStateImplCopyWith<_$AddServiceStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
