// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ai_analysis_screen.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$aiAnalysisHash() => r'e4fc19a4ebdd780dd6baf2d6d07681d506b7616e';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

/// Provider to fetch AI analysis for an incident
/// Fetches from repository and caches the result
///
/// Copied from [aiAnalysis].
@ProviderFor(aiAnalysis)
const aiAnalysisProvider = AiAnalysisFamily();

/// Provider to fetch AI analysis for an incident
/// Fetches from repository and caches the result
///
/// Copied from [aiAnalysis].
class AiAnalysisFamily extends Family<AsyncValue<dynamic>> {
  /// Provider to fetch AI analysis for an incident
  /// Fetches from repository and caches the result
  ///
  /// Copied from [aiAnalysis].
  const AiAnalysisFamily();

  /// Provider to fetch AI analysis for an incident
  /// Fetches from repository and caches the result
  ///
  /// Copied from [aiAnalysis].
  AiAnalysisProvider call(
    String incidentId,
  ) {
    return AiAnalysisProvider(
      incidentId,
    );
  }

  @override
  AiAnalysisProvider getProviderOverride(
    covariant AiAnalysisProvider provider,
  ) {
    return call(
      provider.incidentId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'aiAnalysisProvider';
}

/// Provider to fetch AI analysis for an incident
/// Fetches from repository and caches the result
///
/// Copied from [aiAnalysis].
class AiAnalysisProvider extends AutoDisposeFutureProvider<dynamic> {
  /// Provider to fetch AI analysis for an incident
  /// Fetches from repository and caches the result
  ///
  /// Copied from [aiAnalysis].
  AiAnalysisProvider(
    String incidentId,
  ) : this._internal(
          (ref) => aiAnalysis(
            ref as AiAnalysisRef,
            incidentId,
          ),
          from: aiAnalysisProvider,
          name: r'aiAnalysisProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$aiAnalysisHash,
          dependencies: AiAnalysisFamily._dependencies,
          allTransitiveDependencies:
              AiAnalysisFamily._allTransitiveDependencies,
          incidentId: incidentId,
        );

  AiAnalysisProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.incidentId,
  }) : super.internal();

  final String incidentId;

  @override
  Override overrideWith(
    FutureOr<dynamic> Function(AiAnalysisRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: AiAnalysisProvider._internal(
        (ref) => create(ref as AiAnalysisRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        incidentId: incidentId,
      ),
    );
  }

  @override
  AutoDisposeFutureProviderElement<dynamic> createElement() {
    return _AiAnalysisProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is AiAnalysisProvider && other.incidentId == incidentId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, incidentId.hashCode);

    return _SystemHash.finish(hash);
  }
}

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
mixin AiAnalysisRef on AutoDisposeFutureProviderRef<dynamic> {
  /// The parameter `incidentId` of this provider.
  String get incidentId;
}

class _AiAnalysisProviderElement
    extends AutoDisposeFutureProviderElement<dynamic> with AiAnalysisRef {
  _AiAnalysisProviderElement(super.provider);

  @override
  String get incidentId => (origin as AiAnalysisProvider).incidentId;
}
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
