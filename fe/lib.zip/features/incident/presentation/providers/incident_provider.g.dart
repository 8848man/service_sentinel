// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'incident_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$loadIncidentsHash() => r'd3f1b7fbdeca32778a5dd06ceeae0c0f5334669f';

/// Provider for LoadIncidents use case
///
/// Copied from [loadIncidents].
@ProviderFor(loadIncidents)
final loadIncidentsProvider = AutoDisposeProvider<LoadIncidents>.internal(
  loadIncidents,
  name: r'loadIncidentsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$loadIncidentsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef LoadIncidentsRef = AutoDisposeProviderRef<LoadIncidents>;
String _$acknowledgeIncidentHash() =>
    r'e6e2b22f930f7ffb20196249e7841e89e9ab6b71';

/// Provider for AcknowledgeIncident use case
///
/// Copied from [acknowledgeIncident].
@ProviderFor(acknowledgeIncident)
final acknowledgeIncidentProvider =
    AutoDisposeProvider<AcknowledgeIncident>.internal(
  acknowledgeIncident,
  name: r'acknowledgeIncidentProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$acknowledgeIncidentHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef AcknowledgeIncidentRef = AutoDisposeProviderRef<AcknowledgeIncident>;
String _$resolveIncidentHash() => r'014d6b42ac15cfe54013ed317f0966a6b46aa0cd';

/// Provider for ResolveIncident use case
///
/// Copied from [resolveIncident].
@ProviderFor(resolveIncident)
final resolveIncidentProvider = AutoDisposeProvider<ResolveIncident>.internal(
  resolveIncident,
  name: r'resolveIncidentProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$resolveIncidentHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef ResolveIncidentRef = AutoDisposeProviderRef<ResolveIncident>;
String _$updateIncidentHash() => r'081fd3f5c49716d9c6363eb808b11bff8fa1db3b';

/// Provider for UpdateIncident use case
///
/// Copied from [updateIncident].
@ProviderFor(updateIncident)
final updateIncidentProvider = AutoDisposeProvider<UpdateIncident>.internal(
  updateIncident,
  name: r'updateIncidentProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$updateIncidentHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef UpdateIncidentRef = AutoDisposeProviderRef<UpdateIncident>;
String _$requestAiAnalysisHash() => r'67fe6d33a65241263f283542332879d1e11c6e17';

/// Provider for RequestAiAnalysis use case
///
/// Copied from [requestAiAnalysis].
@ProviderFor(requestAiAnalysis)
final requestAiAnalysisProvider =
    AutoDisposeProvider<RequestAiAnalysis>.internal(
  requestAiAnalysis,
  name: r'requestAiAnalysisProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$requestAiAnalysisHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef RequestAiAnalysisRef = AutoDisposeProviderRef<RequestAiAnalysis>;
String _$incidentsHash() => r'ff1b8c9a14cdedfdbc762835b4ff66d19fd05fd0';

/// Provider to fetch all incidents
///
/// Copied from [incidents].
@ProviderFor(incidents)
final incidentsProvider = AutoDisposeFutureProvider<List<Incident>>.internal(
  incidents,
  name: r'incidentsProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$incidentsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef IncidentsRef = AutoDisposeFutureProviderRef<List<Incident>>;
String _$openIncidentsHash() => r'1ebdc4f9b7b5554964c46f042fb0c13b06d5d229';

/// Provider to fetch open incidents only
///
/// Copied from [openIncidents].
@ProviderFor(openIncidents)
final openIncidentsProvider =
    AutoDisposeFutureProvider<List<Incident>>.internal(
  openIncidents,
  name: r'openIncidentsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$openIncidentsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef OpenIncidentsRef = AutoDisposeFutureProviderRef<List<Incident>>;
String _$criticalIncidentsHash() => r'a59d47d475948d5a2761519bcc333a6cae6d7cd1';

/// Provider to fetch critical incidents only
///
/// Copied from [criticalIncidents].
@ProviderFor(criticalIncidents)
final criticalIncidentsProvider =
    AutoDisposeFutureProvider<List<Incident>>.internal(
  criticalIncidents,
  name: r'criticalIncidentsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$criticalIncidentsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef CriticalIncidentsRef = AutoDisposeFutureProviderRef<List<Incident>>;
String _$incidentByIdHash() => r'53a9a392bc337a47285b745b6219d5c62e64615d';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

/// Provider to fetch incident by ID
///
/// Copied from [incidentById].
@ProviderFor(incidentById)
const incidentByIdProvider = IncidentByIdFamily();

/// Provider to fetch incident by ID
///
/// Copied from [incidentById].
class IncidentByIdFamily extends Family<AsyncValue<Incident?>> {
  /// Provider to fetch incident by ID
  ///
  /// Copied from [incidentById].
  const IncidentByIdFamily();

  /// Provider to fetch incident by ID
  ///
  /// Copied from [incidentById].
  IncidentByIdProvider call(
    String id,
  ) {
    return IncidentByIdProvider(
      id,
    );
  }

  @override
  IncidentByIdProvider getProviderOverride(
    covariant IncidentByIdProvider provider,
  ) {
    return call(
      provider.id,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'incidentByIdProvider';
}

/// Provider to fetch incident by ID
///
/// Copied from [incidentById].
class IncidentByIdProvider extends AutoDisposeFutureProvider<Incident?> {
  /// Provider to fetch incident by ID
  ///
  /// Copied from [incidentById].
  IncidentByIdProvider(
    String id,
  ) : this._internal(
          (ref) => incidentById(
            ref as IncidentByIdRef,
            id,
          ),
          from: incidentByIdProvider,
          name: r'incidentByIdProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$incidentByIdHash,
          dependencies: IncidentByIdFamily._dependencies,
          allTransitiveDependencies:
              IncidentByIdFamily._allTransitiveDependencies,
          id: id,
        );

  IncidentByIdProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.id,
  }) : super.internal();

  final String id;

  @override
  Override overrideWith(
    FutureOr<Incident?> Function(IncidentByIdRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: IncidentByIdProvider._internal(
        (ref) => create(ref as IncidentByIdRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        id: id,
      ),
    );
  }

  @override
  AutoDisposeFutureProviderElement<Incident?> createElement() {
    return _IncidentByIdProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is IncidentByIdProvider && other.id == id;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, id.hashCode);

    return _SystemHash.finish(hash);
  }
}

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
mixin IncidentByIdRef on AutoDisposeFutureProviderRef<Incident?> {
  /// The parameter `id` of this provider.
  String get id;
}

class _IncidentByIdProviderElement
    extends AutoDisposeFutureProviderElement<Incident?> with IncidentByIdRef {
  _IncidentByIdProviderElement(super.provider);

  @override
  String get id => (origin as IncidentByIdProvider).id;
}
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
