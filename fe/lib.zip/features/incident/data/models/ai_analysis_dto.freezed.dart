// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'ai_analysis_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

AiAnalysisDto _$AiAnalysisDtoFromJson(Map<String, dynamic> json) {
  return _AiAnalysisDto.fromJson(json);
}

/// @nodoc
mixin _$AiAnalysisDto {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'incident_id')
  String get incidentId => throw _privateConstructorUsedError;
  @JsonKey(name: 'model_used')
  String get modelUsed => throw _privateConstructorUsedError;
  @JsonKey(name: 'prompt_tokens')
  int get promptTokens => throw _privateConstructorUsedError;
  @JsonKey(name: 'completion_tokens')
  int get completionTokens => throw _privateConstructorUsedError;
  @JsonKey(name: 'total_cost_usd')
  double get totalCostUsd => throw _privateConstructorUsedError;
  @JsonKey(name: 'root_cause_hypothesis')
  String get rootCauseHypothesis => throw _privateConstructorUsedError;
  @JsonKey(name: 'confidence_score')
  double get confidenceScore => throw _privateConstructorUsedError;
  @JsonKey(name: 'debug_checklist')
  List<String> get debugChecklist => throw _privateConstructorUsedError;
  @JsonKey(name: 'suggested_actions')
  List<String> get suggestedActions => throw _privateConstructorUsedError;
  @JsonKey(name: 'related_error_patterns')
  List<String> get relatedErrorPatterns => throw _privateConstructorUsedError;
  @JsonKey(name: 'raw_response')
  String? get rawResponse => throw _privateConstructorUsedError;
  @JsonKey(name: 'analyzed_at')
  String get analyzedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'analysis_duration_ms')
  int get analysisDurationMs => throw _privateConstructorUsedError;

  /// Serializes this AiAnalysisDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of AiAnalysisDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $AiAnalysisDtoCopyWith<AiAnalysisDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AiAnalysisDtoCopyWith<$Res> {
  factory $AiAnalysisDtoCopyWith(
          AiAnalysisDto value, $Res Function(AiAnalysisDto) then) =
      _$AiAnalysisDtoCopyWithImpl<$Res, AiAnalysisDto>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'incident_id') String incidentId,
      @JsonKey(name: 'model_used') String modelUsed,
      @JsonKey(name: 'prompt_tokens') int promptTokens,
      @JsonKey(name: 'completion_tokens') int completionTokens,
      @JsonKey(name: 'total_cost_usd') double totalCostUsd,
      @JsonKey(name: 'root_cause_hypothesis') String rootCauseHypothesis,
      @JsonKey(name: 'confidence_score') double confidenceScore,
      @JsonKey(name: 'debug_checklist') List<String> debugChecklist,
      @JsonKey(name: 'suggested_actions') List<String> suggestedActions,
      @JsonKey(name: 'related_error_patterns')
      List<String> relatedErrorPatterns,
      @JsonKey(name: 'raw_response') String? rawResponse,
      @JsonKey(name: 'analyzed_at') String analyzedAt,
      @JsonKey(name: 'analysis_duration_ms') int analysisDurationMs});
}

/// @nodoc
class _$AiAnalysisDtoCopyWithImpl<$Res, $Val extends AiAnalysisDto>
    implements $AiAnalysisDtoCopyWith<$Res> {
  _$AiAnalysisDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of AiAnalysisDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? incidentId = null,
    Object? modelUsed = null,
    Object? promptTokens = null,
    Object? completionTokens = null,
    Object? totalCostUsd = null,
    Object? rootCauseHypothesis = null,
    Object? confidenceScore = null,
    Object? debugChecklist = null,
    Object? suggestedActions = null,
    Object? relatedErrorPatterns = null,
    Object? rawResponse = freezed,
    Object? analyzedAt = null,
    Object? analysisDurationMs = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      incidentId: null == incidentId
          ? _value.incidentId
          : incidentId // ignore: cast_nullable_to_non_nullable
              as String,
      modelUsed: null == modelUsed
          ? _value.modelUsed
          : modelUsed // ignore: cast_nullable_to_non_nullable
              as String,
      promptTokens: null == promptTokens
          ? _value.promptTokens
          : promptTokens // ignore: cast_nullable_to_non_nullable
              as int,
      completionTokens: null == completionTokens
          ? _value.completionTokens
          : completionTokens // ignore: cast_nullable_to_non_nullable
              as int,
      totalCostUsd: null == totalCostUsd
          ? _value.totalCostUsd
          : totalCostUsd // ignore: cast_nullable_to_non_nullable
              as double,
      rootCauseHypothesis: null == rootCauseHypothesis
          ? _value.rootCauseHypothesis
          : rootCauseHypothesis // ignore: cast_nullable_to_non_nullable
              as String,
      confidenceScore: null == confidenceScore
          ? _value.confidenceScore
          : confidenceScore // ignore: cast_nullable_to_non_nullable
              as double,
      debugChecklist: null == debugChecklist
          ? _value.debugChecklist
          : debugChecklist // ignore: cast_nullable_to_non_nullable
              as List<String>,
      suggestedActions: null == suggestedActions
          ? _value.suggestedActions
          : suggestedActions // ignore: cast_nullable_to_non_nullable
              as List<String>,
      relatedErrorPatterns: null == relatedErrorPatterns
          ? _value.relatedErrorPatterns
          : relatedErrorPatterns // ignore: cast_nullable_to_non_nullable
              as List<String>,
      rawResponse: freezed == rawResponse
          ? _value.rawResponse
          : rawResponse // ignore: cast_nullable_to_non_nullable
              as String?,
      analyzedAt: null == analyzedAt
          ? _value.analyzedAt
          : analyzedAt // ignore: cast_nullable_to_non_nullable
              as String,
      analysisDurationMs: null == analysisDurationMs
          ? _value.analysisDurationMs
          : analysisDurationMs // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AiAnalysisDtoImplCopyWith<$Res>
    implements $AiAnalysisDtoCopyWith<$Res> {
  factory _$$AiAnalysisDtoImplCopyWith(
          _$AiAnalysisDtoImpl value, $Res Function(_$AiAnalysisDtoImpl) then) =
      __$$AiAnalysisDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'incident_id') String incidentId,
      @JsonKey(name: 'model_used') String modelUsed,
      @JsonKey(name: 'prompt_tokens') int promptTokens,
      @JsonKey(name: 'completion_tokens') int completionTokens,
      @JsonKey(name: 'total_cost_usd') double totalCostUsd,
      @JsonKey(name: 'root_cause_hypothesis') String rootCauseHypothesis,
      @JsonKey(name: 'confidence_score') double confidenceScore,
      @JsonKey(name: 'debug_checklist') List<String> debugChecklist,
      @JsonKey(name: 'suggested_actions') List<String> suggestedActions,
      @JsonKey(name: 'related_error_patterns')
      List<String> relatedErrorPatterns,
      @JsonKey(name: 'raw_response') String? rawResponse,
      @JsonKey(name: 'analyzed_at') String analyzedAt,
      @JsonKey(name: 'analysis_duration_ms') int analysisDurationMs});
}

/// @nodoc
class __$$AiAnalysisDtoImplCopyWithImpl<$Res>
    extends _$AiAnalysisDtoCopyWithImpl<$Res, _$AiAnalysisDtoImpl>
    implements _$$AiAnalysisDtoImplCopyWith<$Res> {
  __$$AiAnalysisDtoImplCopyWithImpl(
      _$AiAnalysisDtoImpl _value, $Res Function(_$AiAnalysisDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of AiAnalysisDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? incidentId = null,
    Object? modelUsed = null,
    Object? promptTokens = null,
    Object? completionTokens = null,
    Object? totalCostUsd = null,
    Object? rootCauseHypothesis = null,
    Object? confidenceScore = null,
    Object? debugChecklist = null,
    Object? suggestedActions = null,
    Object? relatedErrorPatterns = null,
    Object? rawResponse = freezed,
    Object? analyzedAt = null,
    Object? analysisDurationMs = null,
  }) {
    return _then(_$AiAnalysisDtoImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      incidentId: null == incidentId
          ? _value.incidentId
          : incidentId // ignore: cast_nullable_to_non_nullable
              as String,
      modelUsed: null == modelUsed
          ? _value.modelUsed
          : modelUsed // ignore: cast_nullable_to_non_nullable
              as String,
      promptTokens: null == promptTokens
          ? _value.promptTokens
          : promptTokens // ignore: cast_nullable_to_non_nullable
              as int,
      completionTokens: null == completionTokens
          ? _value.completionTokens
          : completionTokens // ignore: cast_nullable_to_non_nullable
              as int,
      totalCostUsd: null == totalCostUsd
          ? _value.totalCostUsd
          : totalCostUsd // ignore: cast_nullable_to_non_nullable
              as double,
      rootCauseHypothesis: null == rootCauseHypothesis
          ? _value.rootCauseHypothesis
          : rootCauseHypothesis // ignore: cast_nullable_to_non_nullable
              as String,
      confidenceScore: null == confidenceScore
          ? _value.confidenceScore
          : confidenceScore // ignore: cast_nullable_to_non_nullable
              as double,
      debugChecklist: null == debugChecklist
          ? _value._debugChecklist
          : debugChecklist // ignore: cast_nullable_to_non_nullable
              as List<String>,
      suggestedActions: null == suggestedActions
          ? _value._suggestedActions
          : suggestedActions // ignore: cast_nullable_to_non_nullable
              as List<String>,
      relatedErrorPatterns: null == relatedErrorPatterns
          ? _value._relatedErrorPatterns
          : relatedErrorPatterns // ignore: cast_nullable_to_non_nullable
              as List<String>,
      rawResponse: freezed == rawResponse
          ? _value.rawResponse
          : rawResponse // ignore: cast_nullable_to_non_nullable
              as String?,
      analyzedAt: null == analyzedAt
          ? _value.analyzedAt
          : analyzedAt // ignore: cast_nullable_to_non_nullable
              as String,
      analysisDurationMs: null == analysisDurationMs
          ? _value.analysisDurationMs
          : analysisDurationMs // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$AiAnalysisDtoImpl extends _AiAnalysisDto {
  const _$AiAnalysisDtoImpl(
      {required this.id,
      @JsonKey(name: 'incident_id') required this.incidentId,
      @JsonKey(name: 'model_used') required this.modelUsed,
      @JsonKey(name: 'prompt_tokens') required this.promptTokens,
      @JsonKey(name: 'completion_tokens') required this.completionTokens,
      @JsonKey(name: 'total_cost_usd') required this.totalCostUsd,
      @JsonKey(name: 'root_cause_hypothesis') required this.rootCauseHypothesis,
      @JsonKey(name: 'confidence_score') required this.confidenceScore,
      @JsonKey(name: 'debug_checklist')
      required final List<String> debugChecklist,
      @JsonKey(name: 'suggested_actions')
      required final List<String> suggestedActions,
      @JsonKey(name: 'related_error_patterns')
      required final List<String> relatedErrorPatterns,
      @JsonKey(name: 'raw_response') this.rawResponse,
      @JsonKey(name: 'analyzed_at') required this.analyzedAt,
      @JsonKey(name: 'analysis_duration_ms') required this.analysisDurationMs})
      : _debugChecklist = debugChecklist,
        _suggestedActions = suggestedActions,
        _relatedErrorPatterns = relatedErrorPatterns,
        super._();

  factory _$AiAnalysisDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$AiAnalysisDtoImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'incident_id')
  final String incidentId;
  @override
  @JsonKey(name: 'model_used')
  final String modelUsed;
  @override
  @JsonKey(name: 'prompt_tokens')
  final int promptTokens;
  @override
  @JsonKey(name: 'completion_tokens')
  final int completionTokens;
  @override
  @JsonKey(name: 'total_cost_usd')
  final double totalCostUsd;
  @override
  @JsonKey(name: 'root_cause_hypothesis')
  final String rootCauseHypothesis;
  @override
  @JsonKey(name: 'confidence_score')
  final double confidenceScore;
  final List<String> _debugChecklist;
  @override
  @JsonKey(name: 'debug_checklist')
  List<String> get debugChecklist {
    if (_debugChecklist is EqualUnmodifiableListView) return _debugChecklist;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_debugChecklist);
  }

  final List<String> _suggestedActions;
  @override
  @JsonKey(name: 'suggested_actions')
  List<String> get suggestedActions {
    if (_suggestedActions is EqualUnmodifiableListView)
      return _suggestedActions;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_suggestedActions);
  }

  final List<String> _relatedErrorPatterns;
  @override
  @JsonKey(name: 'related_error_patterns')
  List<String> get relatedErrorPatterns {
    if (_relatedErrorPatterns is EqualUnmodifiableListView)
      return _relatedErrorPatterns;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_relatedErrorPatterns);
  }

  @override
  @JsonKey(name: 'raw_response')
  final String? rawResponse;
  @override
  @JsonKey(name: 'analyzed_at')
  final String analyzedAt;
  @override
  @JsonKey(name: 'analysis_duration_ms')
  final int analysisDurationMs;

  @override
  String toString() {
    return 'AiAnalysisDto(id: $id, incidentId: $incidentId, modelUsed: $modelUsed, promptTokens: $promptTokens, completionTokens: $completionTokens, totalCostUsd: $totalCostUsd, rootCauseHypothesis: $rootCauseHypothesis, confidenceScore: $confidenceScore, debugChecklist: $debugChecklist, suggestedActions: $suggestedActions, relatedErrorPatterns: $relatedErrorPatterns, rawResponse: $rawResponse, analyzedAt: $analyzedAt, analysisDurationMs: $analysisDurationMs)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AiAnalysisDtoImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.incidentId, incidentId) ||
                other.incidentId == incidentId) &&
            (identical(other.modelUsed, modelUsed) ||
                other.modelUsed == modelUsed) &&
            (identical(other.promptTokens, promptTokens) ||
                other.promptTokens == promptTokens) &&
            (identical(other.completionTokens, completionTokens) ||
                other.completionTokens == completionTokens) &&
            (identical(other.totalCostUsd, totalCostUsd) ||
                other.totalCostUsd == totalCostUsd) &&
            (identical(other.rootCauseHypothesis, rootCauseHypothesis) ||
                other.rootCauseHypothesis == rootCauseHypothesis) &&
            (identical(other.confidenceScore, confidenceScore) ||
                other.confidenceScore == confidenceScore) &&
            const DeepCollectionEquality()
                .equals(other._debugChecklist, _debugChecklist) &&
            const DeepCollectionEquality()
                .equals(other._suggestedActions, _suggestedActions) &&
            const DeepCollectionEquality()
                .equals(other._relatedErrorPatterns, _relatedErrorPatterns) &&
            (identical(other.rawResponse, rawResponse) ||
                other.rawResponse == rawResponse) &&
            (identical(other.analyzedAt, analyzedAt) ||
                other.analyzedAt == analyzedAt) &&
            (identical(other.analysisDurationMs, analysisDurationMs) ||
                other.analysisDurationMs == analysisDurationMs));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      incidentId,
      modelUsed,
      promptTokens,
      completionTokens,
      totalCostUsd,
      rootCauseHypothesis,
      confidenceScore,
      const DeepCollectionEquality().hash(_debugChecklist),
      const DeepCollectionEquality().hash(_suggestedActions),
      const DeepCollectionEquality().hash(_relatedErrorPatterns),
      rawResponse,
      analyzedAt,
      analysisDurationMs);

  /// Create a copy of AiAnalysisDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$AiAnalysisDtoImplCopyWith<_$AiAnalysisDtoImpl> get copyWith =>
      __$$AiAnalysisDtoImplCopyWithImpl<_$AiAnalysisDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$AiAnalysisDtoImplToJson(
      this,
    );
  }
}

abstract class _AiAnalysisDto extends AiAnalysisDto {
  const factory _AiAnalysisDto(
      {required final String id,
      @JsonKey(name: 'incident_id') required final String incidentId,
      @JsonKey(name: 'model_used') required final String modelUsed,
      @JsonKey(name: 'prompt_tokens') required final int promptTokens,
      @JsonKey(name: 'completion_tokens') required final int completionTokens,
      @JsonKey(name: 'total_cost_usd') required final double totalCostUsd,
      @JsonKey(name: 'root_cause_hypothesis')
      required final String rootCauseHypothesis,
      @JsonKey(name: 'confidence_score') required final double confidenceScore,
      @JsonKey(name: 'debug_checklist')
      required final List<String> debugChecklist,
      @JsonKey(name: 'suggested_actions')
      required final List<String> suggestedActions,
      @JsonKey(name: 'related_error_patterns')
      required final List<String> relatedErrorPatterns,
      @JsonKey(name: 'raw_response') final String? rawResponse,
      @JsonKey(name: 'analyzed_at') required final String analyzedAt,
      @JsonKey(name: 'analysis_duration_ms')
      required final int analysisDurationMs}) = _$AiAnalysisDtoImpl;
  const _AiAnalysisDto._() : super._();

  factory _AiAnalysisDto.fromJson(Map<String, dynamic> json) =
      _$AiAnalysisDtoImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'incident_id')
  String get incidentId;
  @override
  @JsonKey(name: 'model_used')
  String get modelUsed;
  @override
  @JsonKey(name: 'prompt_tokens')
  int get promptTokens;
  @override
  @JsonKey(name: 'completion_tokens')
  int get completionTokens;
  @override
  @JsonKey(name: 'total_cost_usd')
  double get totalCostUsd;
  @override
  @JsonKey(name: 'root_cause_hypothesis')
  String get rootCauseHypothesis;
  @override
  @JsonKey(name: 'confidence_score')
  double get confidenceScore;
  @override
  @JsonKey(name: 'debug_checklist')
  List<String> get debugChecklist;
  @override
  @JsonKey(name: 'suggested_actions')
  List<String> get suggestedActions;
  @override
  @JsonKey(name: 'related_error_patterns')
  List<String> get relatedErrorPatterns;
  @override
  @JsonKey(name: 'raw_response')
  String? get rawResponse;
  @override
  @JsonKey(name: 'analyzed_at')
  String get analyzedAt;
  @override
  @JsonKey(name: 'analysis_duration_ms')
  int get analysisDurationMs;

  /// Create a copy of AiAnalysisDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$AiAnalysisDtoImplCopyWith<_$AiAnalysisDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
