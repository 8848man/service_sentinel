// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'incident_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$IncidentDtoImpl _$$IncidentDtoImplFromJson(Map<String, dynamic> json) =>
    _$IncidentDtoImpl(
      id: (json['id'] as num).toInt(),
      serviceId: (json['service_id'] as num).toInt(),
      triggerCheckId: (json['trigger_check_id'] as num?)?.toInt(),
      title: json['title'] as String,
      description: json['description'] as String?,
      status: json['status'] as String,
      severity: json['severity'] as String,
      consecutiveFailures: (json['consecutive_failures'] as num).toInt(),
      totalAffectedChecks: (json['total_affected_checks'] as num).toInt(),
      detectedAt: json['detected_at'] as String,
      resolvedAt: json['resolved_at'] as String?,
      acknowledgedAt: json['acknowledged_at'] as String?,
      aiAnalysisRequested: json['ai_analysis_requested'] as bool,
      aiAnalysisCompleted: json['ai_analysis_completed'] as bool,
    );

Map<String, dynamic> _$$IncidentDtoImplToJson(_$IncidentDtoImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'service_id': instance.serviceId,
      'trigger_check_id': instance.triggerCheckId,
      'title': instance.title,
      'description': instance.description,
      'status': instance.status,
      'severity': instance.severity,
      'consecutive_failures': instance.consecutiveFailures,
      'total_affected_checks': instance.totalAffectedChecks,
      'detected_at': instance.detectedAt,
      'resolved_at': instance.resolvedAt,
      'acknowledged_at': instance.acknowledgedAt,
      'ai_analysis_requested': instance.aiAnalysisRequested,
      'ai_analysis_completed': instance.aiAnalysisCompleted,
    };

_$IncidentUpdateDtoImpl _$$IncidentUpdateDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$IncidentUpdateDtoImpl(
      title: json['title'] as String?,
      description: json['description'] as String?,
      status: json['status'] as String?,
      severity: json['severity'] as String?,
    );

Map<String, dynamic> _$$IncidentUpdateDtoImplToJson(
        _$IncidentUpdateDtoImpl instance) =>
    <String, dynamic>{
      'title': instance.title,
      'description': instance.description,
      'status': instance.status,
      'severity': instance.severity,
    };
