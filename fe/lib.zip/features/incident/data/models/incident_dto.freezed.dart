// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'incident_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

IncidentDto _$IncidentDtoFromJson(Map<String, dynamic> json) {
  return _IncidentDto.fromJson(json);
}

/// @nodoc
mixin _$IncidentDto {
  int get id => throw _privateConstructorUsedError; // 🔥 String → int
  @JsonKey(name: 'service_id')
  int get serviceId => throw _privateConstructorUsedError; // 🔥
  @JsonKey(name: 'trigger_check_id')
  int? get triggerCheckId => throw _privateConstructorUsedError; // 🔥
  String get title => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  String get severity => throw _privateConstructorUsedError;
  @JsonKey(name: 'consecutive_failures')
  int get consecutiveFailures => throw _privateConstructorUsedError;
  @JsonKey(name: 'total_affected_checks')
  int get totalAffectedChecks => throw _privateConstructorUsedError;
  @JsonKey(name: 'detected_at')
  String get detectedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'resolved_at')
  String? get resolvedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'acknowledged_at')
  String? get acknowledgedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'ai_analysis_requested')
  bool get aiAnalysisRequested => throw _privateConstructorUsedError;
  @JsonKey(name: 'ai_analysis_completed')
  bool get aiAnalysisCompleted => throw _privateConstructorUsedError;

  /// Serializes this IncidentDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of IncidentDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $IncidentDtoCopyWith<IncidentDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IncidentDtoCopyWith<$Res> {
  factory $IncidentDtoCopyWith(
          IncidentDto value, $Res Function(IncidentDto) then) =
      _$IncidentDtoCopyWithImpl<$Res, IncidentDto>;
  @useResult
  $Res call(
      {int id,
      @JsonKey(name: 'service_id') int serviceId,
      @JsonKey(name: 'trigger_check_id') int? triggerCheckId,
      String title,
      String? description,
      String status,
      String severity,
      @JsonKey(name: 'consecutive_failures') int consecutiveFailures,
      @JsonKey(name: 'total_affected_checks') int totalAffectedChecks,
      @JsonKey(name: 'detected_at') String detectedAt,
      @JsonKey(name: 'resolved_at') String? resolvedAt,
      @JsonKey(name: 'acknowledged_at') String? acknowledgedAt,
      @JsonKey(name: 'ai_analysis_requested') bool aiAnalysisRequested,
      @JsonKey(name: 'ai_analysis_completed') bool aiAnalysisCompleted});
}

/// @nodoc
class _$IncidentDtoCopyWithImpl<$Res, $Val extends IncidentDto>
    implements $IncidentDtoCopyWith<$Res> {
  _$IncidentDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of IncidentDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? serviceId = null,
    Object? triggerCheckId = freezed,
    Object? title = null,
    Object? description = freezed,
    Object? status = null,
    Object? severity = null,
    Object? consecutiveFailures = null,
    Object? totalAffectedChecks = null,
    Object? detectedAt = null,
    Object? resolvedAt = freezed,
    Object? acknowledgedAt = freezed,
    Object? aiAnalysisRequested = null,
    Object? aiAnalysisCompleted = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      serviceId: null == serviceId
          ? _value.serviceId
          : serviceId // ignore: cast_nullable_to_non_nullable
              as int,
      triggerCheckId: freezed == triggerCheckId
          ? _value.triggerCheckId
          : triggerCheckId // ignore: cast_nullable_to_non_nullable
              as int?,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      severity: null == severity
          ? _value.severity
          : severity // ignore: cast_nullable_to_non_nullable
              as String,
      consecutiveFailures: null == consecutiveFailures
          ? _value.consecutiveFailures
          : consecutiveFailures // ignore: cast_nullable_to_non_nullable
              as int,
      totalAffectedChecks: null == totalAffectedChecks
          ? _value.totalAffectedChecks
          : totalAffectedChecks // ignore: cast_nullable_to_non_nullable
              as int,
      detectedAt: null == detectedAt
          ? _value.detectedAt
          : detectedAt // ignore: cast_nullable_to_non_nullable
              as String,
      resolvedAt: freezed == resolvedAt
          ? _value.resolvedAt
          : resolvedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      acknowledgedAt: freezed == acknowledgedAt
          ? _value.acknowledgedAt
          : acknowledgedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      aiAnalysisRequested: null == aiAnalysisRequested
          ? _value.aiAnalysisRequested
          : aiAnalysisRequested // ignore: cast_nullable_to_non_nullable
              as bool,
      aiAnalysisCompleted: null == aiAnalysisCompleted
          ? _value.aiAnalysisCompleted
          : aiAnalysisCompleted // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IncidentDtoImplCopyWith<$Res>
    implements $IncidentDtoCopyWith<$Res> {
  factory _$$IncidentDtoImplCopyWith(
          _$IncidentDtoImpl value, $Res Function(_$IncidentDtoImpl) then) =
      __$$IncidentDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int id,
      @JsonKey(name: 'service_id') int serviceId,
      @JsonKey(name: 'trigger_check_id') int? triggerCheckId,
      String title,
      String? description,
      String status,
      String severity,
      @JsonKey(name: 'consecutive_failures') int consecutiveFailures,
      @JsonKey(name: 'total_affected_checks') int totalAffectedChecks,
      @JsonKey(name: 'detected_at') String detectedAt,
      @JsonKey(name: 'resolved_at') String? resolvedAt,
      @JsonKey(name: 'acknowledged_at') String? acknowledgedAt,
      @JsonKey(name: 'ai_analysis_requested') bool aiAnalysisRequested,
      @JsonKey(name: 'ai_analysis_completed') bool aiAnalysisCompleted});
}

/// @nodoc
class __$$IncidentDtoImplCopyWithImpl<$Res>
    extends _$IncidentDtoCopyWithImpl<$Res, _$IncidentDtoImpl>
    implements _$$IncidentDtoImplCopyWith<$Res> {
  __$$IncidentDtoImplCopyWithImpl(
      _$IncidentDtoImpl _value, $Res Function(_$IncidentDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of IncidentDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? serviceId = null,
    Object? triggerCheckId = freezed,
    Object? title = null,
    Object? description = freezed,
    Object? status = null,
    Object? severity = null,
    Object? consecutiveFailures = null,
    Object? totalAffectedChecks = null,
    Object? detectedAt = null,
    Object? resolvedAt = freezed,
    Object? acknowledgedAt = freezed,
    Object? aiAnalysisRequested = null,
    Object? aiAnalysisCompleted = null,
  }) {
    return _then(_$IncidentDtoImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      serviceId: null == serviceId
          ? _value.serviceId
          : serviceId // ignore: cast_nullable_to_non_nullable
              as int,
      triggerCheckId: freezed == triggerCheckId
          ? _value.triggerCheckId
          : triggerCheckId // ignore: cast_nullable_to_non_nullable
              as int?,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      severity: null == severity
          ? _value.severity
          : severity // ignore: cast_nullable_to_non_nullable
              as String,
      consecutiveFailures: null == consecutiveFailures
          ? _value.consecutiveFailures
          : consecutiveFailures // ignore: cast_nullable_to_non_nullable
              as int,
      totalAffectedChecks: null == totalAffectedChecks
          ? _value.totalAffectedChecks
          : totalAffectedChecks // ignore: cast_nullable_to_non_nullable
              as int,
      detectedAt: null == detectedAt
          ? _value.detectedAt
          : detectedAt // ignore: cast_nullable_to_non_nullable
              as String,
      resolvedAt: freezed == resolvedAt
          ? _value.resolvedAt
          : resolvedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      acknowledgedAt: freezed == acknowledgedAt
          ? _value.acknowledgedAt
          : acknowledgedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      aiAnalysisRequested: null == aiAnalysisRequested
          ? _value.aiAnalysisRequested
          : aiAnalysisRequested // ignore: cast_nullable_to_non_nullable
              as bool,
      aiAnalysisCompleted: null == aiAnalysisCompleted
          ? _value.aiAnalysisCompleted
          : aiAnalysisCompleted // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$IncidentDtoImpl extends _IncidentDto {
  const _$IncidentDtoImpl(
      {required this.id,
      @JsonKey(name: 'service_id') required this.serviceId,
      @JsonKey(name: 'trigger_check_id') this.triggerCheckId,
      required this.title,
      this.description,
      required this.status,
      required this.severity,
      @JsonKey(name: 'consecutive_failures') required this.consecutiveFailures,
      @JsonKey(name: 'total_affected_checks') required this.totalAffectedChecks,
      @JsonKey(name: 'detected_at') required this.detectedAt,
      @JsonKey(name: 'resolved_at') this.resolvedAt,
      @JsonKey(name: 'acknowledged_at') this.acknowledgedAt,
      @JsonKey(name: 'ai_analysis_requested') required this.aiAnalysisRequested,
      @JsonKey(name: 'ai_analysis_completed')
      required this.aiAnalysisCompleted})
      : super._();

  factory _$IncidentDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$IncidentDtoImplFromJson(json);

  @override
  final int id;
// 🔥 String → int
  @override
  @JsonKey(name: 'service_id')
  final int serviceId;
// 🔥
  @override
  @JsonKey(name: 'trigger_check_id')
  final int? triggerCheckId;
// 🔥
  @override
  final String title;
  @override
  final String? description;
  @override
  final String status;
  @override
  final String severity;
  @override
  @JsonKey(name: 'consecutive_failures')
  final int consecutiveFailures;
  @override
  @JsonKey(name: 'total_affected_checks')
  final int totalAffectedChecks;
  @override
  @JsonKey(name: 'detected_at')
  final String detectedAt;
  @override
  @JsonKey(name: 'resolved_at')
  final String? resolvedAt;
  @override
  @JsonKey(name: 'acknowledged_at')
  final String? acknowledgedAt;
  @override
  @JsonKey(name: 'ai_analysis_requested')
  final bool aiAnalysisRequested;
  @override
  @JsonKey(name: 'ai_analysis_completed')
  final bool aiAnalysisCompleted;

  @override
  String toString() {
    return 'IncidentDto(id: $id, serviceId: $serviceId, triggerCheckId: $triggerCheckId, title: $title, description: $description, status: $status, severity: $severity, consecutiveFailures: $consecutiveFailures, totalAffectedChecks: $totalAffectedChecks, detectedAt: $detectedAt, resolvedAt: $resolvedAt, acknowledgedAt: $acknowledgedAt, aiAnalysisRequested: $aiAnalysisRequested, aiAnalysisCompleted: $aiAnalysisCompleted)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IncidentDtoImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.serviceId, serviceId) ||
                other.serviceId == serviceId) &&
            (identical(other.triggerCheckId, triggerCheckId) ||
                other.triggerCheckId == triggerCheckId) &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.severity, severity) ||
                other.severity == severity) &&
            (identical(other.consecutiveFailures, consecutiveFailures) ||
                other.consecutiveFailures == consecutiveFailures) &&
            (identical(other.totalAffectedChecks, totalAffectedChecks) ||
                other.totalAffectedChecks == totalAffectedChecks) &&
            (identical(other.detectedAt, detectedAt) ||
                other.detectedAt == detectedAt) &&
            (identical(other.resolvedAt, resolvedAt) ||
                other.resolvedAt == resolvedAt) &&
            (identical(other.acknowledgedAt, acknowledgedAt) ||
                other.acknowledgedAt == acknowledgedAt) &&
            (identical(other.aiAnalysisRequested, aiAnalysisRequested) ||
                other.aiAnalysisRequested == aiAnalysisRequested) &&
            (identical(other.aiAnalysisCompleted, aiAnalysisCompleted) ||
                other.aiAnalysisCompleted == aiAnalysisCompleted));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      serviceId,
      triggerCheckId,
      title,
      description,
      status,
      severity,
      consecutiveFailures,
      totalAffectedChecks,
      detectedAt,
      resolvedAt,
      acknowledgedAt,
      aiAnalysisRequested,
      aiAnalysisCompleted);

  /// Create a copy of IncidentDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$IncidentDtoImplCopyWith<_$IncidentDtoImpl> get copyWith =>
      __$$IncidentDtoImplCopyWithImpl<_$IncidentDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$IncidentDtoImplToJson(
      this,
    );
  }
}

abstract class _IncidentDto extends IncidentDto {
  const factory _IncidentDto(
      {required final int id,
      @JsonKey(name: 'service_id') required final int serviceId,
      @JsonKey(name: 'trigger_check_id') final int? triggerCheckId,
      required final String title,
      final String? description,
      required final String status,
      required final String severity,
      @JsonKey(name: 'consecutive_failures')
      required final int consecutiveFailures,
      @JsonKey(name: 'total_affected_checks')
      required final int totalAffectedChecks,
      @JsonKey(name: 'detected_at') required final String detectedAt,
      @JsonKey(name: 'resolved_at') final String? resolvedAt,
      @JsonKey(name: 'acknowledged_at') final String? acknowledgedAt,
      @JsonKey(name: 'ai_analysis_requested')
      required final bool aiAnalysisRequested,
      @JsonKey(name: 'ai_analysis_completed')
      required final bool aiAnalysisCompleted}) = _$IncidentDtoImpl;
  const _IncidentDto._() : super._();

  factory _IncidentDto.fromJson(Map<String, dynamic> json) =
      _$IncidentDtoImpl.fromJson;

  @override
  int get id; // 🔥 String → int
  @override
  @JsonKey(name: 'service_id')
  int get serviceId; // 🔥
  @override
  @JsonKey(name: 'trigger_check_id')
  int? get triggerCheckId; // 🔥
  @override
  String get title;
  @override
  String? get description;
  @override
  String get status;
  @override
  String get severity;
  @override
  @JsonKey(name: 'consecutive_failures')
  int get consecutiveFailures;
  @override
  @JsonKey(name: 'total_affected_checks')
  int get totalAffectedChecks;
  @override
  @JsonKey(name: 'detected_at')
  String get detectedAt;
  @override
  @JsonKey(name: 'resolved_at')
  String? get resolvedAt;
  @override
  @JsonKey(name: 'acknowledged_at')
  String? get acknowledgedAt;
  @override
  @JsonKey(name: 'ai_analysis_requested')
  bool get aiAnalysisRequested;
  @override
  @JsonKey(name: 'ai_analysis_completed')
  bool get aiAnalysisCompleted;

  /// Create a copy of IncidentDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$IncidentDtoImplCopyWith<_$IncidentDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

IncidentUpdateDto _$IncidentUpdateDtoFromJson(Map<String, dynamic> json) {
  return _IncidentUpdateDto.fromJson(json);
}

/// @nodoc
mixin _$IncidentUpdateDto {
  String? get title => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  String? get status => throw _privateConstructorUsedError;
  String? get severity => throw _privateConstructorUsedError;

  /// Serializes this IncidentUpdateDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of IncidentUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $IncidentUpdateDtoCopyWith<IncidentUpdateDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IncidentUpdateDtoCopyWith<$Res> {
  factory $IncidentUpdateDtoCopyWith(
          IncidentUpdateDto value, $Res Function(IncidentUpdateDto) then) =
      _$IncidentUpdateDtoCopyWithImpl<$Res, IncidentUpdateDto>;
  @useResult
  $Res call(
      {String? title, String? description, String? status, String? severity});
}

/// @nodoc
class _$IncidentUpdateDtoCopyWithImpl<$Res, $Val extends IncidentUpdateDto>
    implements $IncidentUpdateDtoCopyWith<$Res> {
  _$IncidentUpdateDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of IncidentUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? title = freezed,
    Object? description = freezed,
    Object? status = freezed,
    Object? severity = freezed,
  }) {
    return _then(_value.copyWith(
      title: freezed == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      severity: freezed == severity
          ? _value.severity
          : severity // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IncidentUpdateDtoImplCopyWith<$Res>
    implements $IncidentUpdateDtoCopyWith<$Res> {
  factory _$$IncidentUpdateDtoImplCopyWith(_$IncidentUpdateDtoImpl value,
          $Res Function(_$IncidentUpdateDtoImpl) then) =
      __$$IncidentUpdateDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? title, String? description, String? status, String? severity});
}

/// @nodoc
class __$$IncidentUpdateDtoImplCopyWithImpl<$Res>
    extends _$IncidentUpdateDtoCopyWithImpl<$Res, _$IncidentUpdateDtoImpl>
    implements _$$IncidentUpdateDtoImplCopyWith<$Res> {
  __$$IncidentUpdateDtoImplCopyWithImpl(_$IncidentUpdateDtoImpl _value,
      $Res Function(_$IncidentUpdateDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of IncidentUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? title = freezed,
    Object? description = freezed,
    Object? status = freezed,
    Object? severity = freezed,
  }) {
    return _then(_$IncidentUpdateDtoImpl(
      title: freezed == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String?,
      severity: freezed == severity
          ? _value.severity
          : severity // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$IncidentUpdateDtoImpl implements _IncidentUpdateDto {
  const _$IncidentUpdateDtoImpl(
      {this.title, this.description, this.status, this.severity});

  factory _$IncidentUpdateDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$IncidentUpdateDtoImplFromJson(json);

  @override
  final String? title;
  @override
  final String? description;
  @override
  final String? status;
  @override
  final String? severity;

  @override
  String toString() {
    return 'IncidentUpdateDto(title: $title, description: $description, status: $status, severity: $severity)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IncidentUpdateDtoImpl &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.severity, severity) ||
                other.severity == severity));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode =>
      Object.hash(runtimeType, title, description, status, severity);

  /// Create a copy of IncidentUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$IncidentUpdateDtoImplCopyWith<_$IncidentUpdateDtoImpl> get copyWith =>
      __$$IncidentUpdateDtoImplCopyWithImpl<_$IncidentUpdateDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$IncidentUpdateDtoImplToJson(
      this,
    );
  }
}

abstract class _IncidentUpdateDto implements IncidentUpdateDto {
  const factory _IncidentUpdateDto(
      {final String? title,
      final String? description,
      final String? status,
      final String? severity}) = _$IncidentUpdateDtoImpl;

  factory _IncidentUpdateDto.fromJson(Map<String, dynamic> json) =
      _$IncidentUpdateDtoImpl.fromJson;

  @override
  String? get title;
  @override
  String? get description;
  @override
  String? get status;
  @override
  String? get severity;

  /// Create a copy of IncidentUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$IncidentUpdateDtoImplCopyWith<_$IncidentUpdateDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
