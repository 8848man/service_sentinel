// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ai_analysis_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$AiAnalysisDtoImpl _$$AiAnalysisDtoImplFromJson(Map<String, dynamic> json) =>
    _$AiAnalysisDtoImpl(
      id: json['id'] as String,
      incidentId: json['incident_id'] as String,
      modelUsed: json['model_used'] as String,
      promptTokens: (json['prompt_tokens'] as num).toInt(),
      completionTokens: (json['completion_tokens'] as num).toInt(),
      totalCostUsd: (json['total_cost_usd'] as num).toDouble(),
      rootCauseHypothesis: json['root_cause_hypothesis'] as String,
      confidenceScore: (json['confidence_score'] as num).toDouble(),
      debugChecklist: (json['debug_checklist'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
      suggestedActions: (json['suggested_actions'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
      relatedErrorPatterns: (json['related_error_patterns'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
      rawResponse: json['raw_response'] as String?,
      analyzedAt: json['analyzed_at'] as String,
      analysisDurationMs: (json['analysis_duration_ms'] as num).toInt(),
    );

Map<String, dynamic> _$$AiAnalysisDtoImplToJson(_$AiAnalysisDtoImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'incident_id': instance.incidentId,
      'model_used': instance.modelUsed,
      'prompt_tokens': instance.promptTokens,
      'completion_tokens': instance.completionTokens,
      'total_cost_usd': instance.totalCostUsd,
      'root_cause_hypothesis': instance.rootCauseHypothesis,
      'confidence_score': instance.confidenceScore,
      'debug_checklist': instance.debugChecklist,
      'suggested_actions': instance.suggestedActions,
      'related_error_patterns': instance.relatedErrorPatterns,
      'raw_response': instance.rawResponse,
      'analyzed_at': instance.analyzedAt,
      'analysis_duration_ms': instance.analysisDurationMs,
    };
