// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'incident.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$Incident {
  int get id => throw _privateConstructorUsedError;
  int get serviceId => throw _privateConstructorUsedError;
  int? get triggerCheckId => throw _privateConstructorUsedError;
  String get title => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  IncidentStatus get status => throw _privateConstructorUsedError;
  IncidentSeverity get severity => throw _privateConstructorUsedError;
  int get consecutiveFailures => throw _privateConstructorUsedError;
  int get totalAffectedChecks => throw _privateConstructorUsedError;
  DateTime get detectedAt => throw _privateConstructorUsedError;
  DateTime? get resolvedAt => throw _privateConstructorUsedError;
  DateTime? get acknowledgedAt => throw _privateConstructorUsedError;
  bool get aiAnalysisRequested => throw _privateConstructorUsedError;
  bool get aiAnalysisCompleted => throw _privateConstructorUsedError;

  /// Create a copy of Incident
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $IncidentCopyWith<Incident> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IncidentCopyWith<$Res> {
  factory $IncidentCopyWith(Incident value, $Res Function(Incident) then) =
      _$IncidentCopyWithImpl<$Res, Incident>;
  @useResult
  $Res call(
      {int id,
      int serviceId,
      int? triggerCheckId,
      String title,
      String? description,
      IncidentStatus status,
      IncidentSeverity severity,
      int consecutiveFailures,
      int totalAffectedChecks,
      DateTime detectedAt,
      DateTime? resolvedAt,
      DateTime? acknowledgedAt,
      bool aiAnalysisRequested,
      bool aiAnalysisCompleted});
}

/// @nodoc
class _$IncidentCopyWithImpl<$Res, $Val extends Incident>
    implements $IncidentCopyWith<$Res> {
  _$IncidentCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of Incident
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? serviceId = null,
    Object? triggerCheckId = freezed,
    Object? title = null,
    Object? description = freezed,
    Object? status = null,
    Object? severity = null,
    Object? consecutiveFailures = null,
    Object? totalAffectedChecks = null,
    Object? detectedAt = null,
    Object? resolvedAt = freezed,
    Object? acknowledgedAt = freezed,
    Object? aiAnalysisRequested = null,
    Object? aiAnalysisCompleted = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      serviceId: null == serviceId
          ? _value.serviceId
          : serviceId // ignore: cast_nullable_to_non_nullable
              as int,
      triggerCheckId: freezed == triggerCheckId
          ? _value.triggerCheckId
          : triggerCheckId // ignore: cast_nullable_to_non_nullable
              as int?,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as IncidentStatus,
      severity: null == severity
          ? _value.severity
          : severity // ignore: cast_nullable_to_non_nullable
              as IncidentSeverity,
      consecutiveFailures: null == consecutiveFailures
          ? _value.consecutiveFailures
          : consecutiveFailures // ignore: cast_nullable_to_non_nullable
              as int,
      totalAffectedChecks: null == totalAffectedChecks
          ? _value.totalAffectedChecks
          : totalAffectedChecks // ignore: cast_nullable_to_non_nullable
              as int,
      detectedAt: null == detectedAt
          ? _value.detectedAt
          : detectedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      resolvedAt: freezed == resolvedAt
          ? _value.resolvedAt
          : resolvedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      acknowledgedAt: freezed == acknowledgedAt
          ? _value.acknowledgedAt
          : acknowledgedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      aiAnalysisRequested: null == aiAnalysisRequested
          ? _value.aiAnalysisRequested
          : aiAnalysisRequested // ignore: cast_nullable_to_non_nullable
              as bool,
      aiAnalysisCompleted: null == aiAnalysisCompleted
          ? _value.aiAnalysisCompleted
          : aiAnalysisCompleted // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IncidentImplCopyWith<$Res>
    implements $IncidentCopyWith<$Res> {
  factory _$$IncidentImplCopyWith(
          _$IncidentImpl value, $Res Function(_$IncidentImpl) then) =
      __$$IncidentImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int id,
      int serviceId,
      int? triggerCheckId,
      String title,
      String? description,
      IncidentStatus status,
      IncidentSeverity severity,
      int consecutiveFailures,
      int totalAffectedChecks,
      DateTime detectedAt,
      DateTime? resolvedAt,
      DateTime? acknowledgedAt,
      bool aiAnalysisRequested,
      bool aiAnalysisCompleted});
}

/// @nodoc
class __$$IncidentImplCopyWithImpl<$Res>
    extends _$IncidentCopyWithImpl<$Res, _$IncidentImpl>
    implements _$$IncidentImplCopyWith<$Res> {
  __$$IncidentImplCopyWithImpl(
      _$IncidentImpl _value, $Res Function(_$IncidentImpl) _then)
      : super(_value, _then);

  /// Create a copy of Incident
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? serviceId = null,
    Object? triggerCheckId = freezed,
    Object? title = null,
    Object? description = freezed,
    Object? status = null,
    Object? severity = null,
    Object? consecutiveFailures = null,
    Object? totalAffectedChecks = null,
    Object? detectedAt = null,
    Object? resolvedAt = freezed,
    Object? acknowledgedAt = freezed,
    Object? aiAnalysisRequested = null,
    Object? aiAnalysisCompleted = null,
  }) {
    return _then(_$IncidentImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      serviceId: null == serviceId
          ? _value.serviceId
          : serviceId // ignore: cast_nullable_to_non_nullable
              as int,
      triggerCheckId: freezed == triggerCheckId
          ? _value.triggerCheckId
          : triggerCheckId // ignore: cast_nullable_to_non_nullable
              as int?,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as IncidentStatus,
      severity: null == severity
          ? _value.severity
          : severity // ignore: cast_nullable_to_non_nullable
              as IncidentSeverity,
      consecutiveFailures: null == consecutiveFailures
          ? _value.consecutiveFailures
          : consecutiveFailures // ignore: cast_nullable_to_non_nullable
              as int,
      totalAffectedChecks: null == totalAffectedChecks
          ? _value.totalAffectedChecks
          : totalAffectedChecks // ignore: cast_nullable_to_non_nullable
              as int,
      detectedAt: null == detectedAt
          ? _value.detectedAt
          : detectedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      resolvedAt: freezed == resolvedAt
          ? _value.resolvedAt
          : resolvedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      acknowledgedAt: freezed == acknowledgedAt
          ? _value.acknowledgedAt
          : acknowledgedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      aiAnalysisRequested: null == aiAnalysisRequested
          ? _value.aiAnalysisRequested
          : aiAnalysisRequested // ignore: cast_nullable_to_non_nullable
              as bool,
      aiAnalysisCompleted: null == aiAnalysisCompleted
          ? _value.aiAnalysisCompleted
          : aiAnalysisCompleted // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$IncidentImpl extends _Incident {
  const _$IncidentImpl(
      {required this.id,
      required this.serviceId,
      this.triggerCheckId,
      required this.title,
      this.description,
      required this.status,
      required this.severity,
      required this.consecutiveFailures,
      required this.totalAffectedChecks,
      required this.detectedAt,
      this.resolvedAt,
      this.acknowledgedAt,
      required this.aiAnalysisRequested,
      required this.aiAnalysisCompleted})
      : super._();

  @override
  final int id;
  @override
  final int serviceId;
  @override
  final int? triggerCheckId;
  @override
  final String title;
  @override
  final String? description;
  @override
  final IncidentStatus status;
  @override
  final IncidentSeverity severity;
  @override
  final int consecutiveFailures;
  @override
  final int totalAffectedChecks;
  @override
  final DateTime detectedAt;
  @override
  final DateTime? resolvedAt;
  @override
  final DateTime? acknowledgedAt;
  @override
  final bool aiAnalysisRequested;
  @override
  final bool aiAnalysisCompleted;

  @override
  String toString() {
    return 'Incident(id: $id, serviceId: $serviceId, triggerCheckId: $triggerCheckId, title: $title, description: $description, status: $status, severity: $severity, consecutiveFailures: $consecutiveFailures, totalAffectedChecks: $totalAffectedChecks, detectedAt: $detectedAt, resolvedAt: $resolvedAt, acknowledgedAt: $acknowledgedAt, aiAnalysisRequested: $aiAnalysisRequested, aiAnalysisCompleted: $aiAnalysisCompleted)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IncidentImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.serviceId, serviceId) ||
                other.serviceId == serviceId) &&
            (identical(other.triggerCheckId, triggerCheckId) ||
                other.triggerCheckId == triggerCheckId) &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.severity, severity) ||
                other.severity == severity) &&
            (identical(other.consecutiveFailures, consecutiveFailures) ||
                other.consecutiveFailures == consecutiveFailures) &&
            (identical(other.totalAffectedChecks, totalAffectedChecks) ||
                other.totalAffectedChecks == totalAffectedChecks) &&
            (identical(other.detectedAt, detectedAt) ||
                other.detectedAt == detectedAt) &&
            (identical(other.resolvedAt, resolvedAt) ||
                other.resolvedAt == resolvedAt) &&
            (identical(other.acknowledgedAt, acknowledgedAt) ||
                other.acknowledgedAt == acknowledgedAt) &&
            (identical(other.aiAnalysisRequested, aiAnalysisRequested) ||
                other.aiAnalysisRequested == aiAnalysisRequested) &&
            (identical(other.aiAnalysisCompleted, aiAnalysisCompleted) ||
                other.aiAnalysisCompleted == aiAnalysisCompleted));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      serviceId,
      triggerCheckId,
      title,
      description,
      status,
      severity,
      consecutiveFailures,
      totalAffectedChecks,
      detectedAt,
      resolvedAt,
      acknowledgedAt,
      aiAnalysisRequested,
      aiAnalysisCompleted);

  /// Create a copy of Incident
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$IncidentImplCopyWith<_$IncidentImpl> get copyWith =>
      __$$IncidentImplCopyWithImpl<_$IncidentImpl>(this, _$identity);
}

abstract class _Incident extends Incident {
  const factory _Incident(
      {required final int id,
      required final int serviceId,
      final int? triggerCheckId,
      required final String title,
      final String? description,
      required final IncidentStatus status,
      required final IncidentSeverity severity,
      required final int consecutiveFailures,
      required final int totalAffectedChecks,
      required final DateTime detectedAt,
      final DateTime? resolvedAt,
      final DateTime? acknowledgedAt,
      required final bool aiAnalysisRequested,
      required final bool aiAnalysisCompleted}) = _$IncidentImpl;
  const _Incident._() : super._();

  @override
  int get id;
  @override
  int get serviceId;
  @override
  int? get triggerCheckId;
  @override
  String get title;
  @override
  String? get description;
  @override
  IncidentStatus get status;
  @override
  IncidentSeverity get severity;
  @override
  int get consecutiveFailures;
  @override
  int get totalAffectedChecks;
  @override
  DateTime get detectedAt;
  @override
  DateTime? get resolvedAt;
  @override
  DateTime? get acknowledgedAt;
  @override
  bool get aiAnalysisRequested;
  @override
  bool get aiAnalysisCompleted;

  /// Create a copy of Incident
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$IncidentImplCopyWith<_$IncidentImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$IncidentUpdate {
  String? get title => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  IncidentStatus? get status => throw _privateConstructorUsedError;
  IncidentSeverity? get severity => throw _privateConstructorUsedError;

  /// Create a copy of IncidentUpdate
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $IncidentUpdateCopyWith<IncidentUpdate> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IncidentUpdateCopyWith<$Res> {
  factory $IncidentUpdateCopyWith(
          IncidentUpdate value, $Res Function(IncidentUpdate) then) =
      _$IncidentUpdateCopyWithImpl<$Res, IncidentUpdate>;
  @useResult
  $Res call(
      {String? title,
      String? description,
      IncidentStatus? status,
      IncidentSeverity? severity});
}

/// @nodoc
class _$IncidentUpdateCopyWithImpl<$Res, $Val extends IncidentUpdate>
    implements $IncidentUpdateCopyWith<$Res> {
  _$IncidentUpdateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of IncidentUpdate
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? title = freezed,
    Object? description = freezed,
    Object? status = freezed,
    Object? severity = freezed,
  }) {
    return _then(_value.copyWith(
      title: freezed == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as IncidentStatus?,
      severity: freezed == severity
          ? _value.severity
          : severity // ignore: cast_nullable_to_non_nullable
              as IncidentSeverity?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IncidentUpdateImplCopyWith<$Res>
    implements $IncidentUpdateCopyWith<$Res> {
  factory _$$IncidentUpdateImplCopyWith(_$IncidentUpdateImpl value,
          $Res Function(_$IncidentUpdateImpl) then) =
      __$$IncidentUpdateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? title,
      String? description,
      IncidentStatus? status,
      IncidentSeverity? severity});
}

/// @nodoc
class __$$IncidentUpdateImplCopyWithImpl<$Res>
    extends _$IncidentUpdateCopyWithImpl<$Res, _$IncidentUpdateImpl>
    implements _$$IncidentUpdateImplCopyWith<$Res> {
  __$$IncidentUpdateImplCopyWithImpl(
      _$IncidentUpdateImpl _value, $Res Function(_$IncidentUpdateImpl) _then)
      : super(_value, _then);

  /// Create a copy of IncidentUpdate
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? title = freezed,
    Object? description = freezed,
    Object? status = freezed,
    Object? severity = freezed,
  }) {
    return _then(_$IncidentUpdateImpl(
      title: freezed == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      status: freezed == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as IncidentStatus?,
      severity: freezed == severity
          ? _value.severity
          : severity // ignore: cast_nullable_to_non_nullable
              as IncidentSeverity?,
    ));
  }
}

/// @nodoc

class _$IncidentUpdateImpl implements _IncidentUpdate {
  const _$IncidentUpdateImpl(
      {this.title, this.description, this.status, this.severity});

  @override
  final String? title;
  @override
  final String? description;
  @override
  final IncidentStatus? status;
  @override
  final IncidentSeverity? severity;

  @override
  String toString() {
    return 'IncidentUpdate(title: $title, description: $description, status: $status, severity: $severity)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IncidentUpdateImpl &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.severity, severity) ||
                other.severity == severity));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, title, description, status, severity);

  /// Create a copy of IncidentUpdate
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$IncidentUpdateImplCopyWith<_$IncidentUpdateImpl> get copyWith =>
      __$$IncidentUpdateImplCopyWithImpl<_$IncidentUpdateImpl>(
          this, _$identity);
}

abstract class _IncidentUpdate implements IncidentUpdate {
  const factory _IncidentUpdate(
      {final String? title,
      final String? description,
      final IncidentStatus? status,
      final IncidentSeverity? severity}) = _$IncidentUpdateImpl;

  @override
  String? get title;
  @override
  String? get description;
  @override
  IncidentStatus? get status;
  @override
  IncidentSeverity? get severity;

  /// Create a copy of IncidentUpdate
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$IncidentUpdateImplCopyWith<_$IncidentUpdateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
