// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'ai_analysis.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$AiAnalysis {
  String get id => throw _privateConstructorUsedError;
  String get incidentId => throw _privateConstructorUsedError;
  String get modelUsed => throw _privateConstructorUsedError;
  int get promptTokens => throw _privateConstructorUsedError;
  int get completionTokens => throw _privateConstructorUsedError;
  double get totalCostUsd => throw _privateConstructorUsedError;
  String get rootCauseHypothesis => throw _privateConstructorUsedError;
  double get confidenceScore => throw _privateConstructorUsedError;
  List<String> get debugChecklist => throw _privateConstructorUsedError;
  List<String> get suggestedActions => throw _privateConstructorUsedError;
  List<String> get relatedErrorPatterns => throw _privateConstructorUsedError;
  String? get rawResponse => throw _privateConstructorUsedError;
  DateTime get analyzedAt => throw _privateConstructorUsedError;
  int get analysisDurationMs => throw _privateConstructorUsedError;

  /// Create a copy of AiAnalysis
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $AiAnalysisCopyWith<AiAnalysis> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AiAnalysisCopyWith<$Res> {
  factory $AiAnalysisCopyWith(
          AiAnalysis value, $Res Function(AiAnalysis) then) =
      _$AiAnalysisCopyWithImpl<$Res, AiAnalysis>;
  @useResult
  $Res call(
      {String id,
      String incidentId,
      String modelUsed,
      int promptTokens,
      int completionTokens,
      double totalCostUsd,
      String rootCauseHypothesis,
      double confidenceScore,
      List<String> debugChecklist,
      List<String> suggestedActions,
      List<String> relatedErrorPatterns,
      String? rawResponse,
      DateTime analyzedAt,
      int analysisDurationMs});
}

/// @nodoc
class _$AiAnalysisCopyWithImpl<$Res, $Val extends AiAnalysis>
    implements $AiAnalysisCopyWith<$Res> {
  _$AiAnalysisCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of AiAnalysis
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? incidentId = null,
    Object? modelUsed = null,
    Object? promptTokens = null,
    Object? completionTokens = null,
    Object? totalCostUsd = null,
    Object? rootCauseHypothesis = null,
    Object? confidenceScore = null,
    Object? debugChecklist = null,
    Object? suggestedActions = null,
    Object? relatedErrorPatterns = null,
    Object? rawResponse = freezed,
    Object? analyzedAt = null,
    Object? analysisDurationMs = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      incidentId: null == incidentId
          ? _value.incidentId
          : incidentId // ignore: cast_nullable_to_non_nullable
              as String,
      modelUsed: null == modelUsed
          ? _value.modelUsed
          : modelUsed // ignore: cast_nullable_to_non_nullable
              as String,
      promptTokens: null == promptTokens
          ? _value.promptTokens
          : promptTokens // ignore: cast_nullable_to_non_nullable
              as int,
      completionTokens: null == completionTokens
          ? _value.completionTokens
          : completionTokens // ignore: cast_nullable_to_non_nullable
              as int,
      totalCostUsd: null == totalCostUsd
          ? _value.totalCostUsd
          : totalCostUsd // ignore: cast_nullable_to_non_nullable
              as double,
      rootCauseHypothesis: null == rootCauseHypothesis
          ? _value.rootCauseHypothesis
          : rootCauseHypothesis // ignore: cast_nullable_to_non_nullable
              as String,
      confidenceScore: null == confidenceScore
          ? _value.confidenceScore
          : confidenceScore // ignore: cast_nullable_to_non_nullable
              as double,
      debugChecklist: null == debugChecklist
          ? _value.debugChecklist
          : debugChecklist // ignore: cast_nullable_to_non_nullable
              as List<String>,
      suggestedActions: null == suggestedActions
          ? _value.suggestedActions
          : suggestedActions // ignore: cast_nullable_to_non_nullable
              as List<String>,
      relatedErrorPatterns: null == relatedErrorPatterns
          ? _value.relatedErrorPatterns
          : relatedErrorPatterns // ignore: cast_nullable_to_non_nullable
              as List<String>,
      rawResponse: freezed == rawResponse
          ? _value.rawResponse
          : rawResponse // ignore: cast_nullable_to_non_nullable
              as String?,
      analyzedAt: null == analyzedAt
          ? _value.analyzedAt
          : analyzedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      analysisDurationMs: null == analysisDurationMs
          ? _value.analysisDurationMs
          : analysisDurationMs // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AiAnalysisImplCopyWith<$Res>
    implements $AiAnalysisCopyWith<$Res> {
  factory _$$AiAnalysisImplCopyWith(
          _$AiAnalysisImpl value, $Res Function(_$AiAnalysisImpl) then) =
      __$$AiAnalysisImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String incidentId,
      String modelUsed,
      int promptTokens,
      int completionTokens,
      double totalCostUsd,
      String rootCauseHypothesis,
      double confidenceScore,
      List<String> debugChecklist,
      List<String> suggestedActions,
      List<String> relatedErrorPatterns,
      String? rawResponse,
      DateTime analyzedAt,
      int analysisDurationMs});
}

/// @nodoc
class __$$AiAnalysisImplCopyWithImpl<$Res>
    extends _$AiAnalysisCopyWithImpl<$Res, _$AiAnalysisImpl>
    implements _$$AiAnalysisImplCopyWith<$Res> {
  __$$AiAnalysisImplCopyWithImpl(
      _$AiAnalysisImpl _value, $Res Function(_$AiAnalysisImpl) _then)
      : super(_value, _then);

  /// Create a copy of AiAnalysis
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? incidentId = null,
    Object? modelUsed = null,
    Object? promptTokens = null,
    Object? completionTokens = null,
    Object? totalCostUsd = null,
    Object? rootCauseHypothesis = null,
    Object? confidenceScore = null,
    Object? debugChecklist = null,
    Object? suggestedActions = null,
    Object? relatedErrorPatterns = null,
    Object? rawResponse = freezed,
    Object? analyzedAt = null,
    Object? analysisDurationMs = null,
  }) {
    return _then(_$AiAnalysisImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      incidentId: null == incidentId
          ? _value.incidentId
          : incidentId // ignore: cast_nullable_to_non_nullable
              as String,
      modelUsed: null == modelUsed
          ? _value.modelUsed
          : modelUsed // ignore: cast_nullable_to_non_nullable
              as String,
      promptTokens: null == promptTokens
          ? _value.promptTokens
          : promptTokens // ignore: cast_nullable_to_non_nullable
              as int,
      completionTokens: null == completionTokens
          ? _value.completionTokens
          : completionTokens // ignore: cast_nullable_to_non_nullable
              as int,
      totalCostUsd: null == totalCostUsd
          ? _value.totalCostUsd
          : totalCostUsd // ignore: cast_nullable_to_non_nullable
              as double,
      rootCauseHypothesis: null == rootCauseHypothesis
          ? _value.rootCauseHypothesis
          : rootCauseHypothesis // ignore: cast_nullable_to_non_nullable
              as String,
      confidenceScore: null == confidenceScore
          ? _value.confidenceScore
          : confidenceScore // ignore: cast_nullable_to_non_nullable
              as double,
      debugChecklist: null == debugChecklist
          ? _value._debugChecklist
          : debugChecklist // ignore: cast_nullable_to_non_nullable
              as List<String>,
      suggestedActions: null == suggestedActions
          ? _value._suggestedActions
          : suggestedActions // ignore: cast_nullable_to_non_nullable
              as List<String>,
      relatedErrorPatterns: null == relatedErrorPatterns
          ? _value._relatedErrorPatterns
          : relatedErrorPatterns // ignore: cast_nullable_to_non_nullable
              as List<String>,
      rawResponse: freezed == rawResponse
          ? _value.rawResponse
          : rawResponse // ignore: cast_nullable_to_non_nullable
              as String?,
      analyzedAt: null == analyzedAt
          ? _value.analyzedAt
          : analyzedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      analysisDurationMs: null == analysisDurationMs
          ? _value.analysisDurationMs
          : analysisDurationMs // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$AiAnalysisImpl extends _AiAnalysis {
  const _$AiAnalysisImpl(
      {required this.id,
      required this.incidentId,
      required this.modelUsed,
      required this.promptTokens,
      required this.completionTokens,
      required this.totalCostUsd,
      required this.rootCauseHypothesis,
      required this.confidenceScore,
      required final List<String> debugChecklist,
      required final List<String> suggestedActions,
      required final List<String> relatedErrorPatterns,
      this.rawResponse,
      required this.analyzedAt,
      required this.analysisDurationMs})
      : _debugChecklist = debugChecklist,
        _suggestedActions = suggestedActions,
        _relatedErrorPatterns = relatedErrorPatterns,
        super._();

  @override
  final String id;
  @override
  final String incidentId;
  @override
  final String modelUsed;
  @override
  final int promptTokens;
  @override
  final int completionTokens;
  @override
  final double totalCostUsd;
  @override
  final String rootCauseHypothesis;
  @override
  final double confidenceScore;
  final List<String> _debugChecklist;
  @override
  List<String> get debugChecklist {
    if (_debugChecklist is EqualUnmodifiableListView) return _debugChecklist;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_debugChecklist);
  }

  final List<String> _suggestedActions;
  @override
  List<String> get suggestedActions {
    if (_suggestedActions is EqualUnmodifiableListView)
      return _suggestedActions;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_suggestedActions);
  }

  final List<String> _relatedErrorPatterns;
  @override
  List<String> get relatedErrorPatterns {
    if (_relatedErrorPatterns is EqualUnmodifiableListView)
      return _relatedErrorPatterns;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_relatedErrorPatterns);
  }

  @override
  final String? rawResponse;
  @override
  final DateTime analyzedAt;
  @override
  final int analysisDurationMs;

  @override
  String toString() {
    return 'AiAnalysis(id: $id, incidentId: $incidentId, modelUsed: $modelUsed, promptTokens: $promptTokens, completionTokens: $completionTokens, totalCostUsd: $totalCostUsd, rootCauseHypothesis: $rootCauseHypothesis, confidenceScore: $confidenceScore, debugChecklist: $debugChecklist, suggestedActions: $suggestedActions, relatedErrorPatterns: $relatedErrorPatterns, rawResponse: $rawResponse, analyzedAt: $analyzedAt, analysisDurationMs: $analysisDurationMs)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AiAnalysisImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.incidentId, incidentId) ||
                other.incidentId == incidentId) &&
            (identical(other.modelUsed, modelUsed) ||
                other.modelUsed == modelUsed) &&
            (identical(other.promptTokens, promptTokens) ||
                other.promptTokens == promptTokens) &&
            (identical(other.completionTokens, completionTokens) ||
                other.completionTokens == completionTokens) &&
            (identical(other.totalCostUsd, totalCostUsd) ||
                other.totalCostUsd == totalCostUsd) &&
            (identical(other.rootCauseHypothesis, rootCauseHypothesis) ||
                other.rootCauseHypothesis == rootCauseHypothesis) &&
            (identical(other.confidenceScore, confidenceScore) ||
                other.confidenceScore == confidenceScore) &&
            const DeepCollectionEquality()
                .equals(other._debugChecklist, _debugChecklist) &&
            const DeepCollectionEquality()
                .equals(other._suggestedActions, _suggestedActions) &&
            const DeepCollectionEquality()
                .equals(other._relatedErrorPatterns, _relatedErrorPatterns) &&
            (identical(other.rawResponse, rawResponse) ||
                other.rawResponse == rawResponse) &&
            (identical(other.analyzedAt, analyzedAt) ||
                other.analyzedAt == analyzedAt) &&
            (identical(other.analysisDurationMs, analysisDurationMs) ||
                other.analysisDurationMs == analysisDurationMs));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      incidentId,
      modelUsed,
      promptTokens,
      completionTokens,
      totalCostUsd,
      rootCauseHypothesis,
      confidenceScore,
      const DeepCollectionEquality().hash(_debugChecklist),
      const DeepCollectionEquality().hash(_suggestedActions),
      const DeepCollectionEquality().hash(_relatedErrorPatterns),
      rawResponse,
      analyzedAt,
      analysisDurationMs);

  /// Create a copy of AiAnalysis
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$AiAnalysisImplCopyWith<_$AiAnalysisImpl> get copyWith =>
      __$$AiAnalysisImplCopyWithImpl<_$AiAnalysisImpl>(this, _$identity);
}

abstract class _AiAnalysis extends AiAnalysis {
  const factory _AiAnalysis(
      {required final String id,
      required final String incidentId,
      required final String modelUsed,
      required final int promptTokens,
      required final int completionTokens,
      required final double totalCostUsd,
      required final String rootCauseHypothesis,
      required final double confidenceScore,
      required final List<String> debugChecklist,
      required final List<String> suggestedActions,
      required final List<String> relatedErrorPatterns,
      final String? rawResponse,
      required final DateTime analyzedAt,
      required final int analysisDurationMs}) = _$AiAnalysisImpl;
  const _AiAnalysis._() : super._();

  @override
  String get id;
  @override
  String get incidentId;
  @override
  String get modelUsed;
  @override
  int get promptTokens;
  @override
  int get completionTokens;
  @override
  double get totalCostUsd;
  @override
  String get rootCauseHypothesis;
  @override
  double get confidenceScore;
  @override
  List<String> get debugChecklist;
  @override
  List<String> get suggestedActions;
  @override
  List<String> get relatedErrorPatterns;
  @override
  String? get rawResponse;
  @override
  DateTime get analyzedAt;
  @override
  int get analysisDurationMs;

  /// Create a copy of AiAnalysis
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$AiAnalysisImplCopyWith<_$AiAnalysisImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
