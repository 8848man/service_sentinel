// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'api_key_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ApiKeyDtoImpl _$$ApiKeyDtoImplFromJson(Map<String, dynamic> json) =>
    _$ApiKeyDtoImpl(
      id: json['id'] as String,
      projectId: json['project_id'] as String,
      name: json['name'] as String,
      description: json['description'] as String?,
      isActive: json['is_active'] as bool,
      lastUsedAt: json['last_used_at'] as String?,
      usageCount: (json['usage_count'] as num).toInt(),
      createdAt: json['created_at'] as String,
      expiresAt: json['expires_at'] as String?,
      keyValue: json['key_value'] as String?,
    );

Map<String, dynamic> _$$ApiKeyDtoImplToJson(_$ApiKeyDtoImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'project_id': instance.projectId,
      'name': instance.name,
      'description': instance.description,
      'is_active': instance.isActive,
      'last_used_at': instance.lastUsedAt,
      'usage_count': instance.usageCount,
      'created_at': instance.createdAt,
      'expires_at': instance.expiresAt,
      'key_value': instance.keyValue,
    };

_$ApiKeyCreateDtoImpl _$$ApiKeyCreateDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ApiKeyCreateDtoImpl(
      name: json['name'] as String,
      description: json['description'] as String?,
      expiresAt: json['expires_at'] as String?,
    );

Map<String, dynamic> _$$ApiKeyCreateDtoImplToJson(
        _$ApiKeyCreateDtoImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
      'description': instance.description,
      'expires_at': instance.expiresAt,
    };
