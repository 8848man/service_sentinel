// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'project_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProjectDtoImpl _$$ProjectDtoImplFromJson(Map<String, dynamic> json) =>
    _$ProjectDtoImpl(
      id: (json['id'] as num).toInt(),
      name: json['name'] as String,
      description: json['description'] as String?,
      isActive: json['is_active'] as bool,
      createdAt: json['created_at'] as String,
      updatedAt: json['updated_at'] as String,
      health: json['health'] == null
          ? null
          : ProjectHealthDto.fromJson(json['health'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$ProjectDtoImplToJson(_$ProjectDtoImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'description': instance.description,
      'is_active': instance.isActive,
      'created_at': instance.createdAt,
      'updated_at': instance.updatedAt,
      'health': instance.health,
    };

_$ProjectCreateDtoImpl _$$ProjectCreateDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ProjectCreateDtoImpl(
      name: json['name'] as String,
      description: json['description'] as String?,
    );

Map<String, dynamic> _$$ProjectCreateDtoImplToJson(
        _$ProjectCreateDtoImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
      'description': instance.description,
    };

_$ProjectUpdateDtoImpl _$$ProjectUpdateDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ProjectUpdateDtoImpl(
      name: json['name'] as String?,
      description: json['description'] as String?,
      isActive: json['is_active'] as bool?,
    );

Map<String, dynamic> _$$ProjectUpdateDtoImplToJson(
        _$ProjectUpdateDtoImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
      'description': instance.description,
      'is_active': instance.isActive,
    };

_$ProjectStatsDtoImpl _$$ProjectStatsDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ProjectStatsDtoImpl(
      projectId: json['project_id'] as String,
      totalServices: (json['total_services'] as num).toInt(),
      healthyServices: (json['healthy_services'] as num).toInt(),
      unhealthyServices: (json['unhealthy_services'] as num).toInt(),
      openIncidents: (json['open_incidents'] as num).toInt(),
    );

Map<String, dynamic> _$$ProjectStatsDtoImplToJson(
        _$ProjectStatsDtoImpl instance) =>
    <String, dynamic>{
      'project_id': instance.projectId,
      'total_services': instance.totalServices,
      'healthy_services': instance.healthyServices,
      'unhealthy_services': instance.unhealthyServices,
      'open_incidents': instance.openIncidents,
    };
