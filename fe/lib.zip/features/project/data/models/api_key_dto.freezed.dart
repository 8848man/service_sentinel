// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'api_key_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ApiKeyDto _$ApiKeyDtoFromJson(Map<String, dynamic> json) {
  return _ApiKeyDto.fromJson(json);
}

/// @nodoc
mixin _$ApiKeyDto {
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'project_id')
  String get projectId => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  @JsonKey(name: 'is_active')
  bool get isActive => throw _privateConstructorUsedError;
  @JsonKey(name: 'last_used_at')
  String? get lastUsedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'usage_count')
  int get usageCount => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_at')
  String get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'expires_at')
  String? get expiresAt =>
      throw _privateConstructorUsedError; // Key value only present at creation
  @JsonKey(name: 'key_value')
  String? get keyValue => throw _privateConstructorUsedError;

  /// Serializes this ApiKeyDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ApiKeyDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ApiKeyDtoCopyWith<ApiKeyDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ApiKeyDtoCopyWith<$Res> {
  factory $ApiKeyDtoCopyWith(ApiKeyDto value, $Res Function(ApiKeyDto) then) =
      _$ApiKeyDtoCopyWithImpl<$Res, ApiKeyDto>;
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'project_id') String projectId,
      String name,
      String? description,
      @JsonKey(name: 'is_active') bool isActive,
      @JsonKey(name: 'last_used_at') String? lastUsedAt,
      @JsonKey(name: 'usage_count') int usageCount,
      @JsonKey(name: 'created_at') String createdAt,
      @JsonKey(name: 'expires_at') String? expiresAt,
      @JsonKey(name: 'key_value') String? keyValue});
}

/// @nodoc
class _$ApiKeyDtoCopyWithImpl<$Res, $Val extends ApiKeyDto>
    implements $ApiKeyDtoCopyWith<$Res> {
  _$ApiKeyDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ApiKeyDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? projectId = null,
    Object? name = null,
    Object? description = freezed,
    Object? isActive = null,
    Object? lastUsedAt = freezed,
    Object? usageCount = null,
    Object? createdAt = null,
    Object? expiresAt = freezed,
    Object? keyValue = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      projectId: null == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      lastUsedAt: freezed == lastUsedAt
          ? _value.lastUsedAt
          : lastUsedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      usageCount: null == usageCount
          ? _value.usageCount
          : usageCount // ignore: cast_nullable_to_non_nullable
              as int,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String,
      expiresAt: freezed == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as String?,
      keyValue: freezed == keyValue
          ? _value.keyValue
          : keyValue // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ApiKeyDtoImplCopyWith<$Res>
    implements $ApiKeyDtoCopyWith<$Res> {
  factory _$$ApiKeyDtoImplCopyWith(
          _$ApiKeyDtoImpl value, $Res Function(_$ApiKeyDtoImpl) then) =
      __$$ApiKeyDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      @JsonKey(name: 'project_id') String projectId,
      String name,
      String? description,
      @JsonKey(name: 'is_active') bool isActive,
      @JsonKey(name: 'last_used_at') String? lastUsedAt,
      @JsonKey(name: 'usage_count') int usageCount,
      @JsonKey(name: 'created_at') String createdAt,
      @JsonKey(name: 'expires_at') String? expiresAt,
      @JsonKey(name: 'key_value') String? keyValue});
}

/// @nodoc
class __$$ApiKeyDtoImplCopyWithImpl<$Res>
    extends _$ApiKeyDtoCopyWithImpl<$Res, _$ApiKeyDtoImpl>
    implements _$$ApiKeyDtoImplCopyWith<$Res> {
  __$$ApiKeyDtoImplCopyWithImpl(
      _$ApiKeyDtoImpl _value, $Res Function(_$ApiKeyDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of ApiKeyDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? projectId = null,
    Object? name = null,
    Object? description = freezed,
    Object? isActive = null,
    Object? lastUsedAt = freezed,
    Object? usageCount = null,
    Object? createdAt = null,
    Object? expiresAt = freezed,
    Object? keyValue = freezed,
  }) {
    return _then(_$ApiKeyDtoImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      projectId: null == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      lastUsedAt: freezed == lastUsedAt
          ? _value.lastUsedAt
          : lastUsedAt // ignore: cast_nullable_to_non_nullable
              as String?,
      usageCount: null == usageCount
          ? _value.usageCount
          : usageCount // ignore: cast_nullable_to_non_nullable
              as int,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String,
      expiresAt: freezed == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as String?,
      keyValue: freezed == keyValue
          ? _value.keyValue
          : keyValue // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ApiKeyDtoImpl extends _ApiKeyDto {
  const _$ApiKeyDtoImpl(
      {required this.id,
      @JsonKey(name: 'project_id') required this.projectId,
      required this.name,
      this.description,
      @JsonKey(name: 'is_active') required this.isActive,
      @JsonKey(name: 'last_used_at') this.lastUsedAt,
      @JsonKey(name: 'usage_count') required this.usageCount,
      @JsonKey(name: 'created_at') required this.createdAt,
      @JsonKey(name: 'expires_at') this.expiresAt,
      @JsonKey(name: 'key_value') this.keyValue})
      : super._();

  factory _$ApiKeyDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ApiKeyDtoImplFromJson(json);

  @override
  final String id;
  @override
  @JsonKey(name: 'project_id')
  final String projectId;
  @override
  final String name;
  @override
  final String? description;
  @override
  @JsonKey(name: 'is_active')
  final bool isActive;
  @override
  @JsonKey(name: 'last_used_at')
  final String? lastUsedAt;
  @override
  @JsonKey(name: 'usage_count')
  final int usageCount;
  @override
  @JsonKey(name: 'created_at')
  final String createdAt;
  @override
  @JsonKey(name: 'expires_at')
  final String? expiresAt;
// Key value only present at creation
  @override
  @JsonKey(name: 'key_value')
  final String? keyValue;

  @override
  String toString() {
    return 'ApiKeyDto(id: $id, projectId: $projectId, name: $name, description: $description, isActive: $isActive, lastUsedAt: $lastUsedAt, usageCount: $usageCount, createdAt: $createdAt, expiresAt: $expiresAt, keyValue: $keyValue)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ApiKeyDtoImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.projectId, projectId) ||
                other.projectId == projectId) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.isActive, isActive) ||
                other.isActive == isActive) &&
            (identical(other.lastUsedAt, lastUsedAt) ||
                other.lastUsedAt == lastUsedAt) &&
            (identical(other.usageCount, usageCount) ||
                other.usageCount == usageCount) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.expiresAt, expiresAt) ||
                other.expiresAt == expiresAt) &&
            (identical(other.keyValue, keyValue) ||
                other.keyValue == keyValue));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, id, projectId, name, description,
      isActive, lastUsedAt, usageCount, createdAt, expiresAt, keyValue);

  /// Create a copy of ApiKeyDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ApiKeyDtoImplCopyWith<_$ApiKeyDtoImpl> get copyWith =>
      __$$ApiKeyDtoImplCopyWithImpl<_$ApiKeyDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ApiKeyDtoImplToJson(
      this,
    );
  }
}

abstract class _ApiKeyDto extends ApiKeyDto {
  const factory _ApiKeyDto(
      {required final String id,
      @JsonKey(name: 'project_id') required final String projectId,
      required final String name,
      final String? description,
      @JsonKey(name: 'is_active') required final bool isActive,
      @JsonKey(name: 'last_used_at') final String? lastUsedAt,
      @JsonKey(name: 'usage_count') required final int usageCount,
      @JsonKey(name: 'created_at') required final String createdAt,
      @JsonKey(name: 'expires_at') final String? expiresAt,
      @JsonKey(name: 'key_value') final String? keyValue}) = _$ApiKeyDtoImpl;
  const _ApiKeyDto._() : super._();

  factory _ApiKeyDto.fromJson(Map<String, dynamic> json) =
      _$ApiKeyDtoImpl.fromJson;

  @override
  String get id;
  @override
  @JsonKey(name: 'project_id')
  String get projectId;
  @override
  String get name;
  @override
  String? get description;
  @override
  @JsonKey(name: 'is_active')
  bool get isActive;
  @override
  @JsonKey(name: 'last_used_at')
  String? get lastUsedAt;
  @override
  @JsonKey(name: 'usage_count')
  int get usageCount;
  @override
  @JsonKey(name: 'created_at')
  String get createdAt;
  @override
  @JsonKey(name: 'expires_at')
  String? get expiresAt; // Key value only present at creation
  @override
  @JsonKey(name: 'key_value')
  String? get keyValue;

  /// Create a copy of ApiKeyDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ApiKeyDtoImplCopyWith<_$ApiKeyDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ApiKeyCreateDto _$ApiKeyCreateDtoFromJson(Map<String, dynamic> json) {
  return _ApiKeyCreateDto.fromJson(json);
}

/// @nodoc
mixin _$ApiKeyCreateDto {
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  @JsonKey(name: 'expires_at')
  String? get expiresAt => throw _privateConstructorUsedError;

  /// Serializes this ApiKeyCreateDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ApiKeyCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ApiKeyCreateDtoCopyWith<ApiKeyCreateDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ApiKeyCreateDtoCopyWith<$Res> {
  factory $ApiKeyCreateDtoCopyWith(
          ApiKeyCreateDto value, $Res Function(ApiKeyCreateDto) then) =
      _$ApiKeyCreateDtoCopyWithImpl<$Res, ApiKeyCreateDto>;
  @useResult
  $Res call(
      {String name,
      String? description,
      @JsonKey(name: 'expires_at') String? expiresAt});
}

/// @nodoc
class _$ApiKeyCreateDtoCopyWithImpl<$Res, $Val extends ApiKeyCreateDto>
    implements $ApiKeyCreateDtoCopyWith<$Res> {
  _$ApiKeyCreateDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ApiKeyCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
    Object? expiresAt = freezed,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      expiresAt: freezed == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ApiKeyCreateDtoImplCopyWith<$Res>
    implements $ApiKeyCreateDtoCopyWith<$Res> {
  factory _$$ApiKeyCreateDtoImplCopyWith(_$ApiKeyCreateDtoImpl value,
          $Res Function(_$ApiKeyCreateDtoImpl) then) =
      __$$ApiKeyCreateDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String name,
      String? description,
      @JsonKey(name: 'expires_at') String? expiresAt});
}

/// @nodoc
class __$$ApiKeyCreateDtoImplCopyWithImpl<$Res>
    extends _$ApiKeyCreateDtoCopyWithImpl<$Res, _$ApiKeyCreateDtoImpl>
    implements _$$ApiKeyCreateDtoImplCopyWith<$Res> {
  __$$ApiKeyCreateDtoImplCopyWithImpl(
      _$ApiKeyCreateDtoImpl _value, $Res Function(_$ApiKeyCreateDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of ApiKeyCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
    Object? expiresAt = freezed,
  }) {
    return _then(_$ApiKeyCreateDtoImpl(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      expiresAt: freezed == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ApiKeyCreateDtoImpl implements _ApiKeyCreateDto {
  const _$ApiKeyCreateDtoImpl(
      {required this.name,
      this.description,
      @JsonKey(name: 'expires_at') this.expiresAt});

  factory _$ApiKeyCreateDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ApiKeyCreateDtoImplFromJson(json);

  @override
  final String name;
  @override
  final String? description;
  @override
  @JsonKey(name: 'expires_at')
  final String? expiresAt;

  @override
  String toString() {
    return 'ApiKeyCreateDto(name: $name, description: $description, expiresAt: $expiresAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ApiKeyCreateDtoImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.expiresAt, expiresAt) ||
                other.expiresAt == expiresAt));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, name, description, expiresAt);

  /// Create a copy of ApiKeyCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ApiKeyCreateDtoImplCopyWith<_$ApiKeyCreateDtoImpl> get copyWith =>
      __$$ApiKeyCreateDtoImplCopyWithImpl<_$ApiKeyCreateDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ApiKeyCreateDtoImplToJson(
      this,
    );
  }
}

abstract class _ApiKeyCreateDto implements ApiKeyCreateDto {
  const factory _ApiKeyCreateDto(
          {required final String name,
          final String? description,
          @JsonKey(name: 'expires_at') final String? expiresAt}) =
      _$ApiKeyCreateDtoImpl;

  factory _ApiKeyCreateDto.fromJson(Map<String, dynamic> json) =
      _$ApiKeyCreateDtoImpl.fromJson;

  @override
  String get name;
  @override
  String? get description;
  @override
  @JsonKey(name: 'expires_at')
  String? get expiresAt;

  /// Create a copy of ApiKeyCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ApiKeyCreateDtoImplCopyWith<_$ApiKeyCreateDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
