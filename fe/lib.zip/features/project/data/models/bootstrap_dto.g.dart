// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'bootstrap_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$BootstrapResponseDtoImpl _$$BootstrapResponseDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$BootstrapResponseDtoImpl(
      project: ProjectDto.fromJson(json['project'] as Map<String, dynamic>),
      apiKey: json['api_key'] as String,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$BootstrapResponseDtoImplToJson(
        _$BootstrapResponseDtoImpl instance) =>
    <String, dynamic>{
      'project': instance.project,
      'api_key': instance.apiKey,
      'message': instance.message,
    };

_$BootstrapRequestDtoImpl _$$BootstrapRequestDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$BootstrapRequestDtoImpl(
      name: json['name'] as String,
      description: json['description'] as String?,
    );

Map<String, dynamic> _$$BootstrapRequestDtoImplToJson(
        _$BootstrapRequestDtoImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
      'description': instance.description,
    };
