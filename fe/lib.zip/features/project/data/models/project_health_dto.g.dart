// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'project_health_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProjectHealthDtoImpl _$$ProjectHealthDtoImplFromJson(
        Map<String, dynamic> json) =>
    _$ProjectHealthDtoImpl(
      status: json['status'] as String,
      totalServices: (json['total_services'] as num).toInt(),
      healthyServices: (json['healthy_services'] as num).toInt(),
      errorServices: (json['error_services'] as num).toInt(),
      inactiveServices: (json['inactive_services'] as num).toInt(),
      activeIncidents: (json['active_incidents'] as num).toInt(),
    );

Map<String, dynamic> _$$ProjectHealthDtoImplToJson(
        _$ProjectHealthDtoImpl instance) =>
    <String, dynamic>{
      'status': instance.status,
      'total_services': instance.totalServices,
      'healthy_services': instance.healthyServices,
      'error_services': instance.errorServices,
      'inactive_services': instance.inactiveServices,
      'active_incidents': instance.activeIncidents,
    };
