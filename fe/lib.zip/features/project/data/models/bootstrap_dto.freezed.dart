// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'bootstrap_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

BootstrapResponseDto _$BootstrapResponseDtoFromJson(Map<String, dynamic> json) {
  return _BootstrapResponseDto.fromJson(json);
}

/// @nodoc
mixin _$BootstrapResponseDto {
  ProjectDto get project => throw _privateConstructorUsedError;
  @JsonKey(name: 'api_key')
  String get apiKey =>
      throw _privateConstructorUsedError; // Snake case from backend
  String? get message => throw _privateConstructorUsedError;

  /// Serializes this BootstrapResponseDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of BootstrapResponseDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $BootstrapResponseDtoCopyWith<BootstrapResponseDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BootstrapResponseDtoCopyWith<$Res> {
  factory $BootstrapResponseDtoCopyWith(BootstrapResponseDto value,
          $Res Function(BootstrapResponseDto) then) =
      _$BootstrapResponseDtoCopyWithImpl<$Res, BootstrapResponseDto>;
  @useResult
  $Res call(
      {ProjectDto project,
      @JsonKey(name: 'api_key') String apiKey,
      String? message});

  $ProjectDtoCopyWith<$Res> get project;
}

/// @nodoc
class _$BootstrapResponseDtoCopyWithImpl<$Res,
        $Val extends BootstrapResponseDto>
    implements $BootstrapResponseDtoCopyWith<$Res> {
  _$BootstrapResponseDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of BootstrapResponseDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project = null,
    Object? apiKey = null,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      project: null == project
          ? _value.project
          : project // ignore: cast_nullable_to_non_nullable
              as ProjectDto,
      apiKey: null == apiKey
          ? _value.apiKey
          : apiKey // ignore: cast_nullable_to_non_nullable
              as String,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  /// Create a copy of BootstrapResponseDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @pragma('vm:prefer-inline')
  $ProjectDtoCopyWith<$Res> get project {
    return $ProjectDtoCopyWith<$Res>(_value.project, (value) {
      return _then(_value.copyWith(project: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$BootstrapResponseDtoImplCopyWith<$Res>
    implements $BootstrapResponseDtoCopyWith<$Res> {
  factory _$$BootstrapResponseDtoImplCopyWith(_$BootstrapResponseDtoImpl value,
          $Res Function(_$BootstrapResponseDtoImpl) then) =
      __$$BootstrapResponseDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {ProjectDto project,
      @JsonKey(name: 'api_key') String apiKey,
      String? message});

  @override
  $ProjectDtoCopyWith<$Res> get project;
}

/// @nodoc
class __$$BootstrapResponseDtoImplCopyWithImpl<$Res>
    extends _$BootstrapResponseDtoCopyWithImpl<$Res, _$BootstrapResponseDtoImpl>
    implements _$$BootstrapResponseDtoImplCopyWith<$Res> {
  __$$BootstrapResponseDtoImplCopyWithImpl(_$BootstrapResponseDtoImpl _value,
      $Res Function(_$BootstrapResponseDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of BootstrapResponseDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project = null,
    Object? apiKey = null,
    Object? message = freezed,
  }) {
    return _then(_$BootstrapResponseDtoImpl(
      project: null == project
          ? _value.project
          : project // ignore: cast_nullable_to_non_nullable
              as ProjectDto,
      apiKey: null == apiKey
          ? _value.apiKey
          : apiKey // ignore: cast_nullable_to_non_nullable
              as String,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$BootstrapResponseDtoImpl extends _BootstrapResponseDto {
  const _$BootstrapResponseDtoImpl(
      {required this.project,
      @JsonKey(name: 'api_key') required this.apiKey,
      this.message})
      : super._();

  factory _$BootstrapResponseDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$BootstrapResponseDtoImplFromJson(json);

  @override
  final ProjectDto project;
  @override
  @JsonKey(name: 'api_key')
  final String apiKey;
// Snake case from backend
  @override
  final String? message;

  @override
  String toString() {
    return 'BootstrapResponseDto(project: $project, apiKey: $apiKey, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BootstrapResponseDtoImpl &&
            (identical(other.project, project) || other.project == project) &&
            (identical(other.apiKey, apiKey) || other.apiKey == apiKey) &&
            (identical(other.message, message) || other.message == message));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, project, apiKey, message);

  /// Create a copy of BootstrapResponseDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$BootstrapResponseDtoImplCopyWith<_$BootstrapResponseDtoImpl>
      get copyWith =>
          __$$BootstrapResponseDtoImplCopyWithImpl<_$BootstrapResponseDtoImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$BootstrapResponseDtoImplToJson(
      this,
    );
  }
}

abstract class _BootstrapResponseDto extends BootstrapResponseDto {
  const factory _BootstrapResponseDto(
      {required final ProjectDto project,
      @JsonKey(name: 'api_key') required final String apiKey,
      final String? message}) = _$BootstrapResponseDtoImpl;
  const _BootstrapResponseDto._() : super._();

  factory _BootstrapResponseDto.fromJson(Map<String, dynamic> json) =
      _$BootstrapResponseDtoImpl.fromJson;

  @override
  ProjectDto get project;
  @override
  @JsonKey(name: 'api_key')
  String get apiKey; // Snake case from backend
  @override
  String? get message;

  /// Create a copy of BootstrapResponseDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$BootstrapResponseDtoImplCopyWith<_$BootstrapResponseDtoImpl>
      get copyWith => throw _privateConstructorUsedError;
}

BootstrapRequestDto _$BootstrapRequestDtoFromJson(Map<String, dynamic> json) {
  return _BootstrapRequestDto.fromJson(json);
}

/// @nodoc
mixin _$BootstrapRequestDto {
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;

  /// Serializes this BootstrapRequestDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of BootstrapRequestDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $BootstrapRequestDtoCopyWith<BootstrapRequestDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BootstrapRequestDtoCopyWith<$Res> {
  factory $BootstrapRequestDtoCopyWith(
          BootstrapRequestDto value, $Res Function(BootstrapRequestDto) then) =
      _$BootstrapRequestDtoCopyWithImpl<$Res, BootstrapRequestDto>;
  @useResult
  $Res call({String name, String? description});
}

/// @nodoc
class _$BootstrapRequestDtoCopyWithImpl<$Res, $Val extends BootstrapRequestDto>
    implements $BootstrapRequestDtoCopyWith<$Res> {
  _$BootstrapRequestDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of BootstrapRequestDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$BootstrapRequestDtoImplCopyWith<$Res>
    implements $BootstrapRequestDtoCopyWith<$Res> {
  factory _$$BootstrapRequestDtoImplCopyWith(_$BootstrapRequestDtoImpl value,
          $Res Function(_$BootstrapRequestDtoImpl) then) =
      __$$BootstrapRequestDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String name, String? description});
}

/// @nodoc
class __$$BootstrapRequestDtoImplCopyWithImpl<$Res>
    extends _$BootstrapRequestDtoCopyWithImpl<$Res, _$BootstrapRequestDtoImpl>
    implements _$$BootstrapRequestDtoImplCopyWith<$Res> {
  __$$BootstrapRequestDtoImplCopyWithImpl(_$BootstrapRequestDtoImpl _value,
      $Res Function(_$BootstrapRequestDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of BootstrapRequestDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
  }) {
    return _then(_$BootstrapRequestDtoImpl(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$BootstrapRequestDtoImpl extends _BootstrapRequestDto {
  const _$BootstrapRequestDtoImpl({required this.name, this.description})
      : super._();

  factory _$BootstrapRequestDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$BootstrapRequestDtoImplFromJson(json);

  @override
  final String name;
  @override
  final String? description;

  @override
  String toString() {
    return 'BootstrapRequestDto(name: $name, description: $description)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BootstrapRequestDtoImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, name, description);

  /// Create a copy of BootstrapRequestDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$BootstrapRequestDtoImplCopyWith<_$BootstrapRequestDtoImpl> get copyWith =>
      __$$BootstrapRequestDtoImplCopyWithImpl<_$BootstrapRequestDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$BootstrapRequestDtoImplToJson(
      this,
    );
  }
}

abstract class _BootstrapRequestDto extends BootstrapRequestDto {
  const factory _BootstrapRequestDto(
      {required final String name,
      final String? description}) = _$BootstrapRequestDtoImpl;
  const _BootstrapRequestDto._() : super._();

  factory _BootstrapRequestDto.fromJson(Map<String, dynamic> json) =
      _$BootstrapRequestDtoImpl.fromJson;

  @override
  String get name;
  @override
  String? get description;

  /// Create a copy of BootstrapRequestDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$BootstrapRequestDtoImplCopyWith<_$BootstrapRequestDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
