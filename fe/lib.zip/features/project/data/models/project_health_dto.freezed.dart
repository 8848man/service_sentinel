// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'project_health_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProjectHealthDto _$ProjectHealthDtoFromJson(Map<String, dynamic> json) {
  return _ProjectHealthDto.fromJson(json);
}

/// @nodoc
mixin _$ProjectHealthDto {
  String get status => throw _privateConstructorUsedError;
  @JsonKey(name: 'total_services')
  int get totalServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'healthy_services')
  int get healthyServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'error_services')
  int get errorServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'inactive_services')
  int get inactiveServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'active_incidents')
  int get activeIncidents => throw _privateConstructorUsedError;

  /// Serializes this ProjectHealthDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ProjectHealthDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ProjectHealthDtoCopyWith<ProjectHealthDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectHealthDtoCopyWith<$Res> {
  factory $ProjectHealthDtoCopyWith(
          ProjectHealthDto value, $Res Function(ProjectHealthDto) then) =
      _$ProjectHealthDtoCopyWithImpl<$Res, ProjectHealthDto>;
  @useResult
  $Res call(
      {String status,
      @JsonKey(name: 'total_services') int totalServices,
      @JsonKey(name: 'healthy_services') int healthyServices,
      @JsonKey(name: 'error_services') int errorServices,
      @JsonKey(name: 'inactive_services') int inactiveServices,
      @JsonKey(name: 'active_incidents') int activeIncidents});
}

/// @nodoc
class _$ProjectHealthDtoCopyWithImpl<$Res, $Val extends ProjectHealthDto>
    implements $ProjectHealthDtoCopyWith<$Res> {
  _$ProjectHealthDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ProjectHealthDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? errorServices = null,
    Object? inactiveServices = null,
    Object? activeIncidents = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      errorServices: null == errorServices
          ? _value.errorServices
          : errorServices // ignore: cast_nullable_to_non_nullable
              as int,
      inactiveServices: null == inactiveServices
          ? _value.inactiveServices
          : inactiveServices // ignore: cast_nullable_to_non_nullable
              as int,
      activeIncidents: null == activeIncidents
          ? _value.activeIncidents
          : activeIncidents // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProjectHealthDtoImplCopyWith<$Res>
    implements $ProjectHealthDtoCopyWith<$Res> {
  factory _$$ProjectHealthDtoImplCopyWith(_$ProjectHealthDtoImpl value,
          $Res Function(_$ProjectHealthDtoImpl) then) =
      __$$ProjectHealthDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String status,
      @JsonKey(name: 'total_services') int totalServices,
      @JsonKey(name: 'healthy_services') int healthyServices,
      @JsonKey(name: 'error_services') int errorServices,
      @JsonKey(name: 'inactive_services') int inactiveServices,
      @JsonKey(name: 'active_incidents') int activeIncidents});
}

/// @nodoc
class __$$ProjectHealthDtoImplCopyWithImpl<$Res>
    extends _$ProjectHealthDtoCopyWithImpl<$Res, _$ProjectHealthDtoImpl>
    implements _$$ProjectHealthDtoImplCopyWith<$Res> {
  __$$ProjectHealthDtoImplCopyWithImpl(_$ProjectHealthDtoImpl _value,
      $Res Function(_$ProjectHealthDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of ProjectHealthDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? errorServices = null,
    Object? inactiveServices = null,
    Object? activeIncidents = null,
  }) {
    return _then(_$ProjectHealthDtoImpl(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      errorServices: null == errorServices
          ? _value.errorServices
          : errorServices // ignore: cast_nullable_to_non_nullable
              as int,
      inactiveServices: null == inactiveServices
          ? _value.inactiveServices
          : inactiveServices // ignore: cast_nullable_to_non_nullable
              as int,
      activeIncidents: null == activeIncidents
          ? _value.activeIncidents
          : activeIncidents // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProjectHealthDtoImpl extends _ProjectHealthDto {
  const _$ProjectHealthDtoImpl(
      {required this.status,
      @JsonKey(name: 'total_services') required this.totalServices,
      @JsonKey(name: 'healthy_services') required this.healthyServices,
      @JsonKey(name: 'error_services') required this.errorServices,
      @JsonKey(name: 'inactive_services') required this.inactiveServices,
      @JsonKey(name: 'active_incidents') required this.activeIncidents})
      : super._();

  factory _$ProjectHealthDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProjectHealthDtoImplFromJson(json);

  @override
  final String status;
  @override
  @JsonKey(name: 'total_services')
  final int totalServices;
  @override
  @JsonKey(name: 'healthy_services')
  final int healthyServices;
  @override
  @JsonKey(name: 'error_services')
  final int errorServices;
  @override
  @JsonKey(name: 'inactive_services')
  final int inactiveServices;
  @override
  @JsonKey(name: 'active_incidents')
  final int activeIncidents;

  @override
  String toString() {
    return 'ProjectHealthDto(status: $status, totalServices: $totalServices, healthyServices: $healthyServices, errorServices: $errorServices, inactiveServices: $inactiveServices, activeIncidents: $activeIncidents)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProjectHealthDtoImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.totalServices, totalServices) ||
                other.totalServices == totalServices) &&
            (identical(other.healthyServices, healthyServices) ||
                other.healthyServices == healthyServices) &&
            (identical(other.errorServices, errorServices) ||
                other.errorServices == errorServices) &&
            (identical(other.inactiveServices, inactiveServices) ||
                other.inactiveServices == inactiveServices) &&
            (identical(other.activeIncidents, activeIncidents) ||
                other.activeIncidents == activeIncidents));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, status, totalServices,
      healthyServices, errorServices, inactiveServices, activeIncidents);

  /// Create a copy of ProjectHealthDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ProjectHealthDtoImplCopyWith<_$ProjectHealthDtoImpl> get copyWith =>
      __$$ProjectHealthDtoImplCopyWithImpl<_$ProjectHealthDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProjectHealthDtoImplToJson(
      this,
    );
  }
}

abstract class _ProjectHealthDto extends ProjectHealthDto {
  const factory _ProjectHealthDto(
      {required final String status,
      @JsonKey(name: 'total_services') required final int totalServices,
      @JsonKey(name: 'healthy_services') required final int healthyServices,
      @JsonKey(name: 'error_services') required final int errorServices,
      @JsonKey(name: 'inactive_services') required final int inactiveServices,
      @JsonKey(name: 'active_incidents')
      required final int activeIncidents}) = _$ProjectHealthDtoImpl;
  const _ProjectHealthDto._() : super._();

  factory _ProjectHealthDto.fromJson(Map<String, dynamic> json) =
      _$ProjectHealthDtoImpl.fromJson;

  @override
  String get status;
  @override
  @JsonKey(name: 'total_services')
  int get totalServices;
  @override
  @JsonKey(name: 'healthy_services')
  int get healthyServices;
  @override
  @JsonKey(name: 'error_services')
  int get errorServices;
  @override
  @JsonKey(name: 'inactive_services')
  int get inactiveServices;
  @override
  @JsonKey(name: 'active_incidents')
  int get activeIncidents;

  /// Create a copy of ProjectHealthDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ProjectHealthDtoImplCopyWith<_$ProjectHealthDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
