// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'project_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProjectDto _$ProjectDtoFromJson(Map<String, dynamic> json) {
  return _ProjectDto.fromJson(json);
}

/// @nodoc
mixin _$ProjectDto {
  int get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  @JsonKey(name: 'is_active')
  bool get isActive => throw _privateConstructorUsedError;
  @JsonKey(name: 'created_at')
  String get createdAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'updated_at')
  String get updatedAt => throw _privateConstructorUsedError;
  @JsonKey(name: 'health')
  ProjectHealthDto? get health => throw _privateConstructorUsedError;

  /// Serializes this ProjectDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ProjectDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ProjectDtoCopyWith<ProjectDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectDtoCopyWith<$Res> {
  factory $ProjectDtoCopyWith(
          ProjectDto value, $Res Function(ProjectDto) then) =
      _$ProjectDtoCopyWithImpl<$Res, ProjectDto>;
  @useResult
  $Res call(
      {int id,
      String name,
      String? description,
      @JsonKey(name: 'is_active') bool isActive,
      @JsonKey(name: 'created_at') String createdAt,
      @JsonKey(name: 'updated_at') String updatedAt,
      @JsonKey(name: 'health') ProjectHealthDto? health});

  $ProjectHealthDtoCopyWith<$Res>? get health;
}

/// @nodoc
class _$ProjectDtoCopyWithImpl<$Res, $Val extends ProjectDto>
    implements $ProjectDtoCopyWith<$Res> {
  _$ProjectDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ProjectDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? description = freezed,
    Object? isActive = null,
    Object? createdAt = null,
    Object? updatedAt = null,
    Object? health = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String,
      health: freezed == health
          ? _value.health
          : health // ignore: cast_nullable_to_non_nullable
              as ProjectHealthDto?,
    ) as $Val);
  }

  /// Create a copy of ProjectDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @pragma('vm:prefer-inline')
  $ProjectHealthDtoCopyWith<$Res>? get health {
    if (_value.health == null) {
      return null;
    }

    return $ProjectHealthDtoCopyWith<$Res>(_value.health!, (value) {
      return _then(_value.copyWith(health: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ProjectDtoImplCopyWith<$Res>
    implements $ProjectDtoCopyWith<$Res> {
  factory _$$ProjectDtoImplCopyWith(
          _$ProjectDtoImpl value, $Res Function(_$ProjectDtoImpl) then) =
      __$$ProjectDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int id,
      String name,
      String? description,
      @JsonKey(name: 'is_active') bool isActive,
      @JsonKey(name: 'created_at') String createdAt,
      @JsonKey(name: 'updated_at') String updatedAt,
      @JsonKey(name: 'health') ProjectHealthDto? health});

  @override
  $ProjectHealthDtoCopyWith<$Res>? get health;
}

/// @nodoc
class __$$ProjectDtoImplCopyWithImpl<$Res>
    extends _$ProjectDtoCopyWithImpl<$Res, _$ProjectDtoImpl>
    implements _$$ProjectDtoImplCopyWith<$Res> {
  __$$ProjectDtoImplCopyWithImpl(
      _$ProjectDtoImpl _value, $Res Function(_$ProjectDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of ProjectDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? description = freezed,
    Object? isActive = null,
    Object? createdAt = null,
    Object? updatedAt = null,
    Object? health = freezed,
  }) {
    return _then(_$ProjectDtoImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as String,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as String,
      health: freezed == health
          ? _value.health
          : health // ignore: cast_nullable_to_non_nullable
              as ProjectHealthDto?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProjectDtoImpl extends _ProjectDto {
  const _$ProjectDtoImpl(
      {required this.id,
      required this.name,
      this.description,
      @JsonKey(name: 'is_active') required this.isActive,
      @JsonKey(name: 'created_at') required this.createdAt,
      @JsonKey(name: 'updated_at') required this.updatedAt,
      @JsonKey(name: 'health') this.health})
      : super._();

  factory _$ProjectDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProjectDtoImplFromJson(json);

  @override
  final int id;
  @override
  final String name;
  @override
  final String? description;
  @override
  @JsonKey(name: 'is_active')
  final bool isActive;
  @override
  @JsonKey(name: 'created_at')
  final String createdAt;
  @override
  @JsonKey(name: 'updated_at')
  final String updatedAt;
  @override
  @JsonKey(name: 'health')
  final ProjectHealthDto? health;

  @override
  String toString() {
    return 'ProjectDto(id: $id, name: $name, description: $description, isActive: $isActive, createdAt: $createdAt, updatedAt: $updatedAt, health: $health)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProjectDtoImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.isActive, isActive) ||
                other.isActive == isActive) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.health, health) || other.health == health));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, id, name, description, isActive,
      createdAt, updatedAt, health);

  /// Create a copy of ProjectDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ProjectDtoImplCopyWith<_$ProjectDtoImpl> get copyWith =>
      __$$ProjectDtoImplCopyWithImpl<_$ProjectDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProjectDtoImplToJson(
      this,
    );
  }
}

abstract class _ProjectDto extends ProjectDto {
  const factory _ProjectDto(
          {required final int id,
          required final String name,
          final String? description,
          @JsonKey(name: 'is_active') required final bool isActive,
          @JsonKey(name: 'created_at') required final String createdAt,
          @JsonKey(name: 'updated_at') required final String updatedAt,
          @JsonKey(name: 'health') final ProjectHealthDto? health}) =
      _$ProjectDtoImpl;
  const _ProjectDto._() : super._();

  factory _ProjectDto.fromJson(Map<String, dynamic> json) =
      _$ProjectDtoImpl.fromJson;

  @override
  int get id;
  @override
  String get name;
  @override
  String? get description;
  @override
  @JsonKey(name: 'is_active')
  bool get isActive;
  @override
  @JsonKey(name: 'created_at')
  String get createdAt;
  @override
  @JsonKey(name: 'updated_at')
  String get updatedAt;
  @override
  @JsonKey(name: 'health')
  ProjectHealthDto? get health;

  /// Create a copy of ProjectDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ProjectDtoImplCopyWith<_$ProjectDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ProjectCreateDto _$ProjectCreateDtoFromJson(Map<String, dynamic> json) {
  return _ProjectCreateDto.fromJson(json);
}

/// @nodoc
mixin _$ProjectCreateDto {
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;

  /// Serializes this ProjectCreateDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ProjectCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ProjectCreateDtoCopyWith<ProjectCreateDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectCreateDtoCopyWith<$Res> {
  factory $ProjectCreateDtoCopyWith(
          ProjectCreateDto value, $Res Function(ProjectCreateDto) then) =
      _$ProjectCreateDtoCopyWithImpl<$Res, ProjectCreateDto>;
  @useResult
  $Res call({String name, String? description});
}

/// @nodoc
class _$ProjectCreateDtoCopyWithImpl<$Res, $Val extends ProjectCreateDto>
    implements $ProjectCreateDtoCopyWith<$Res> {
  _$ProjectCreateDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ProjectCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProjectCreateDtoImplCopyWith<$Res>
    implements $ProjectCreateDtoCopyWith<$Res> {
  factory _$$ProjectCreateDtoImplCopyWith(_$ProjectCreateDtoImpl value,
          $Res Function(_$ProjectCreateDtoImpl) then) =
      __$$ProjectCreateDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String name, String? description});
}

/// @nodoc
class __$$ProjectCreateDtoImplCopyWithImpl<$Res>
    extends _$ProjectCreateDtoCopyWithImpl<$Res, _$ProjectCreateDtoImpl>
    implements _$$ProjectCreateDtoImplCopyWith<$Res> {
  __$$ProjectCreateDtoImplCopyWithImpl(_$ProjectCreateDtoImpl _value,
      $Res Function(_$ProjectCreateDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of ProjectCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
  }) {
    return _then(_$ProjectCreateDtoImpl(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProjectCreateDtoImpl implements _ProjectCreateDto {
  const _$ProjectCreateDtoImpl({required this.name, this.description});

  factory _$ProjectCreateDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProjectCreateDtoImplFromJson(json);

  @override
  final String name;
  @override
  final String? description;

  @override
  String toString() {
    return 'ProjectCreateDto(name: $name, description: $description)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProjectCreateDtoImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, name, description);

  /// Create a copy of ProjectCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ProjectCreateDtoImplCopyWith<_$ProjectCreateDtoImpl> get copyWith =>
      __$$ProjectCreateDtoImplCopyWithImpl<_$ProjectCreateDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProjectCreateDtoImplToJson(
      this,
    );
  }
}

abstract class _ProjectCreateDto implements ProjectCreateDto {
  const factory _ProjectCreateDto(
      {required final String name,
      final String? description}) = _$ProjectCreateDtoImpl;

  factory _ProjectCreateDto.fromJson(Map<String, dynamic> json) =
      _$ProjectCreateDtoImpl.fromJson;

  @override
  String get name;
  @override
  String? get description;

  /// Create a copy of ProjectCreateDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ProjectCreateDtoImplCopyWith<_$ProjectCreateDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ProjectUpdateDto _$ProjectUpdateDtoFromJson(Map<String, dynamic> json) {
  return _ProjectUpdateDto.fromJson(json);
}

/// @nodoc
mixin _$ProjectUpdateDto {
  String? get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  @JsonKey(name: 'is_active')
  bool? get isActive => throw _privateConstructorUsedError;

  /// Serializes this ProjectUpdateDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ProjectUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ProjectUpdateDtoCopyWith<ProjectUpdateDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectUpdateDtoCopyWith<$Res> {
  factory $ProjectUpdateDtoCopyWith(
          ProjectUpdateDto value, $Res Function(ProjectUpdateDto) then) =
      _$ProjectUpdateDtoCopyWithImpl<$Res, ProjectUpdateDto>;
  @useResult
  $Res call(
      {String? name,
      String? description,
      @JsonKey(name: 'is_active') bool? isActive});
}

/// @nodoc
class _$ProjectUpdateDtoCopyWithImpl<$Res, $Val extends ProjectUpdateDto>
    implements $ProjectUpdateDtoCopyWith<$Res> {
  _$ProjectUpdateDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ProjectUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = freezed,
    Object? description = freezed,
    Object? isActive = freezed,
  }) {
    return _then(_value.copyWith(
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      isActive: freezed == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProjectUpdateDtoImplCopyWith<$Res>
    implements $ProjectUpdateDtoCopyWith<$Res> {
  factory _$$ProjectUpdateDtoImplCopyWith(_$ProjectUpdateDtoImpl value,
          $Res Function(_$ProjectUpdateDtoImpl) then) =
      __$$ProjectUpdateDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? name,
      String? description,
      @JsonKey(name: 'is_active') bool? isActive});
}

/// @nodoc
class __$$ProjectUpdateDtoImplCopyWithImpl<$Res>
    extends _$ProjectUpdateDtoCopyWithImpl<$Res, _$ProjectUpdateDtoImpl>
    implements _$$ProjectUpdateDtoImplCopyWith<$Res> {
  __$$ProjectUpdateDtoImplCopyWithImpl(_$ProjectUpdateDtoImpl _value,
      $Res Function(_$ProjectUpdateDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of ProjectUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = freezed,
    Object? description = freezed,
    Object? isActive = freezed,
  }) {
    return _then(_$ProjectUpdateDtoImpl(
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      isActive: freezed == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProjectUpdateDtoImpl implements _ProjectUpdateDto {
  const _$ProjectUpdateDtoImpl(
      {this.name, this.description, @JsonKey(name: 'is_active') this.isActive});

  factory _$ProjectUpdateDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProjectUpdateDtoImplFromJson(json);

  @override
  final String? name;
  @override
  final String? description;
  @override
  @JsonKey(name: 'is_active')
  final bool? isActive;

  @override
  String toString() {
    return 'ProjectUpdateDto(name: $name, description: $description, isActive: $isActive)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProjectUpdateDtoImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.isActive, isActive) ||
                other.isActive == isActive));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, name, description, isActive);

  /// Create a copy of ProjectUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ProjectUpdateDtoImplCopyWith<_$ProjectUpdateDtoImpl> get copyWith =>
      __$$ProjectUpdateDtoImplCopyWithImpl<_$ProjectUpdateDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProjectUpdateDtoImplToJson(
      this,
    );
  }
}

abstract class _ProjectUpdateDto implements ProjectUpdateDto {
  const factory _ProjectUpdateDto(
          {final String? name,
          final String? description,
          @JsonKey(name: 'is_active') final bool? isActive}) =
      _$ProjectUpdateDtoImpl;

  factory _ProjectUpdateDto.fromJson(Map<String, dynamic> json) =
      _$ProjectUpdateDtoImpl.fromJson;

  @override
  String? get name;
  @override
  String? get description;
  @override
  @JsonKey(name: 'is_active')
  bool? get isActive;

  /// Create a copy of ProjectUpdateDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ProjectUpdateDtoImplCopyWith<_$ProjectUpdateDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

ProjectStatsDto _$ProjectStatsDtoFromJson(Map<String, dynamic> json) {
  return _ProjectStatsDto.fromJson(json);
}

/// @nodoc
mixin _$ProjectStatsDto {
  @JsonKey(name: 'project_id')
  String get projectId => throw _privateConstructorUsedError;
  @JsonKey(name: 'total_services')
  int get totalServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'healthy_services')
  int get healthyServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'unhealthy_services')
  int get unhealthyServices => throw _privateConstructorUsedError;
  @JsonKey(name: 'open_incidents')
  int get openIncidents => throw _privateConstructorUsedError;

  /// Serializes this ProjectStatsDto to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ProjectStatsDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ProjectStatsDtoCopyWith<ProjectStatsDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectStatsDtoCopyWith<$Res> {
  factory $ProjectStatsDtoCopyWith(
          ProjectStatsDto value, $Res Function(ProjectStatsDto) then) =
      _$ProjectStatsDtoCopyWithImpl<$Res, ProjectStatsDto>;
  @useResult
  $Res call(
      {@JsonKey(name: 'project_id') String projectId,
      @JsonKey(name: 'total_services') int totalServices,
      @JsonKey(name: 'healthy_services') int healthyServices,
      @JsonKey(name: 'unhealthy_services') int unhealthyServices,
      @JsonKey(name: 'open_incidents') int openIncidents});
}

/// @nodoc
class _$ProjectStatsDtoCopyWithImpl<$Res, $Val extends ProjectStatsDto>
    implements $ProjectStatsDtoCopyWith<$Res> {
  _$ProjectStatsDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ProjectStatsDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? projectId = null,
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? unhealthyServices = null,
    Object? openIncidents = null,
  }) {
    return _then(_value.copyWith(
      projectId: null == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as String,
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      unhealthyServices: null == unhealthyServices
          ? _value.unhealthyServices
          : unhealthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      openIncidents: null == openIncidents
          ? _value.openIncidents
          : openIncidents // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProjectStatsDtoImplCopyWith<$Res>
    implements $ProjectStatsDtoCopyWith<$Res> {
  factory _$$ProjectStatsDtoImplCopyWith(_$ProjectStatsDtoImpl value,
          $Res Function(_$ProjectStatsDtoImpl) then) =
      __$$ProjectStatsDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: 'project_id') String projectId,
      @JsonKey(name: 'total_services') int totalServices,
      @JsonKey(name: 'healthy_services') int healthyServices,
      @JsonKey(name: 'unhealthy_services') int unhealthyServices,
      @JsonKey(name: 'open_incidents') int openIncidents});
}

/// @nodoc
class __$$ProjectStatsDtoImplCopyWithImpl<$Res>
    extends _$ProjectStatsDtoCopyWithImpl<$Res, _$ProjectStatsDtoImpl>
    implements _$$ProjectStatsDtoImplCopyWith<$Res> {
  __$$ProjectStatsDtoImplCopyWithImpl(
      _$ProjectStatsDtoImpl _value, $Res Function(_$ProjectStatsDtoImpl) _then)
      : super(_value, _then);

  /// Create a copy of ProjectStatsDto
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? projectId = null,
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? unhealthyServices = null,
    Object? openIncidents = null,
  }) {
    return _then(_$ProjectStatsDtoImpl(
      projectId: null == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as String,
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      unhealthyServices: null == unhealthyServices
          ? _value.unhealthyServices
          : unhealthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      openIncidents: null == openIncidents
          ? _value.openIncidents
          : openIncidents // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProjectStatsDtoImpl extends _ProjectStatsDto {
  const _$ProjectStatsDtoImpl(
      {@JsonKey(name: 'project_id') required this.projectId,
      @JsonKey(name: 'total_services') required this.totalServices,
      @JsonKey(name: 'healthy_services') required this.healthyServices,
      @JsonKey(name: 'unhealthy_services') required this.unhealthyServices,
      @JsonKey(name: 'open_incidents') required this.openIncidents})
      : super._();

  factory _$ProjectStatsDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProjectStatsDtoImplFromJson(json);

  @override
  @JsonKey(name: 'project_id')
  final String projectId;
  @override
  @JsonKey(name: 'total_services')
  final int totalServices;
  @override
  @JsonKey(name: 'healthy_services')
  final int healthyServices;
  @override
  @JsonKey(name: 'unhealthy_services')
  final int unhealthyServices;
  @override
  @JsonKey(name: 'open_incidents')
  final int openIncidents;

  @override
  String toString() {
    return 'ProjectStatsDto(projectId: $projectId, totalServices: $totalServices, healthyServices: $healthyServices, unhealthyServices: $unhealthyServices, openIncidents: $openIncidents)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProjectStatsDtoImpl &&
            (identical(other.projectId, projectId) ||
                other.projectId == projectId) &&
            (identical(other.totalServices, totalServices) ||
                other.totalServices == totalServices) &&
            (identical(other.healthyServices, healthyServices) ||
                other.healthyServices == healthyServices) &&
            (identical(other.unhealthyServices, unhealthyServices) ||
                other.unhealthyServices == unhealthyServices) &&
            (identical(other.openIncidents, openIncidents) ||
                other.openIncidents == openIncidents));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, projectId, totalServices,
      healthyServices, unhealthyServices, openIncidents);

  /// Create a copy of ProjectStatsDto
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ProjectStatsDtoImplCopyWith<_$ProjectStatsDtoImpl> get copyWith =>
      __$$ProjectStatsDtoImplCopyWithImpl<_$ProjectStatsDtoImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProjectStatsDtoImplToJson(
      this,
    );
  }
}

abstract class _ProjectStatsDto extends ProjectStatsDto {
  const factory _ProjectStatsDto(
      {@JsonKey(name: 'project_id') required final String projectId,
      @JsonKey(name: 'total_services') required final int totalServices,
      @JsonKey(name: 'healthy_services') required final int healthyServices,
      @JsonKey(name: 'unhealthy_services') required final int unhealthyServices,
      @JsonKey(name: 'open_incidents')
      required final int openIncidents}) = _$ProjectStatsDtoImpl;
  const _ProjectStatsDto._() : super._();

  factory _ProjectStatsDto.fromJson(Map<String, dynamic> json) =
      _$ProjectStatsDtoImpl.fromJson;

  @override
  @JsonKey(name: 'project_id')
  String get projectId;
  @override
  @JsonKey(name: 'total_services')
  int get totalServices;
  @override
  @JsonKey(name: 'healthy_services')
  int get healthyServices;
  @override
  @JsonKey(name: 'unhealthy_services')
  int get unhealthyServices;
  @override
  @JsonKey(name: 'open_incidents')
  int get openIncidents;

  /// Create a copy of ProjectStatsDto
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ProjectStatsDtoImplCopyWith<_$ProjectStatsDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
