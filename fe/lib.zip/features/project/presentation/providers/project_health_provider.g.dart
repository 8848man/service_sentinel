// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'project_health_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$getProjectHealthHash() => r'84f5710f6a9a3979b1d77625f1f6ef4ff360ea22';

/// Use case provider for getting project health
///
/// Copied from [getProjectHealth].
@ProviderFor(getProjectHealth)
final getProjectHealthProvider = AutoDisposeProvider<GetProjectHealth>.internal(
  getProjectHealth,
  name: r'getProjectHealthProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$getProjectHealthHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef GetProjectHealthRef = AutoDisposeProviderRef<GetProjectHealth>;
String _$projectHealthHash() => r'f371c4a0810a8ea6ce472dc626d026d4cb2d5c47';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

/// Provider for fetching project health by ID
///
/// Returns ProjectHealth containing:
/// - Overall status (HEALTHY, DEGRADED, UNKNOWN)
/// - Service counts by state (healthy, error, inactive)
/// - Active incident count
///
/// This is a FutureProvider that fetches health from the server on-demand.
/// Health is NEVER cached or stored locally.
///
/// Copied from [projectHealth].
@ProviderFor(projectHealth)
const projectHealthProvider = ProjectHealthFamily();

/// Provider for fetching project health by ID
///
/// Returns ProjectHealth containing:
/// - Overall status (HEALTHY, DEGRADED, UNKNOWN)
/// - Service counts by state (healthy, error, inactive)
/// - Active incident count
///
/// This is a FutureProvider that fetches health from the server on-demand.
/// Health is NEVER cached or stored locally.
///
/// Copied from [projectHealth].
class ProjectHealthFamily extends Family<AsyncValue<ProjectHealth>> {
  /// Provider for fetching project health by ID
  ///
  /// Returns ProjectHealth containing:
  /// - Overall status (HEALTHY, DEGRADED, UNKNOWN)
  /// - Service counts by state (healthy, error, inactive)
  /// - Active incident count
  ///
  /// This is a FutureProvider that fetches health from the server on-demand.
  /// Health is NEVER cached or stored locally.
  ///
  /// Copied from [projectHealth].
  const ProjectHealthFamily();

  /// Provider for fetching project health by ID
  ///
  /// Returns ProjectHealth containing:
  /// - Overall status (HEALTHY, DEGRADED, UNKNOWN)
  /// - Service counts by state (healthy, error, inactive)
  /// - Active incident count
  ///
  /// This is a FutureProvider that fetches health from the server on-demand.
  /// Health is NEVER cached or stored locally.
  ///
  /// Copied from [projectHealth].
  ProjectHealthProvider call(
    String projectId,
  ) {
    return ProjectHealthProvider(
      projectId,
    );
  }

  @override
  ProjectHealthProvider getProviderOverride(
    covariant ProjectHealthProvider provider,
  ) {
    return call(
      provider.projectId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'projectHealthProvider';
}

/// Provider for fetching project health by ID
///
/// Returns ProjectHealth containing:
/// - Overall status (HEALTHY, DEGRADED, UNKNOWN)
/// - Service counts by state (healthy, error, inactive)
/// - Active incident count
///
/// This is a FutureProvider that fetches health from the server on-demand.
/// Health is NEVER cached or stored locally.
///
/// Copied from [projectHealth].
class ProjectHealthProvider extends AutoDisposeFutureProvider<ProjectHealth> {
  /// Provider for fetching project health by ID
  ///
  /// Returns ProjectHealth containing:
  /// - Overall status (HEALTHY, DEGRADED, UNKNOWN)
  /// - Service counts by state (healthy, error, inactive)
  /// - Active incident count
  ///
  /// This is a FutureProvider that fetches health from the server on-demand.
  /// Health is NEVER cached or stored locally.
  ///
  /// Copied from [projectHealth].
  ProjectHealthProvider(
    String projectId,
  ) : this._internal(
          (ref) => projectHealth(
            ref as ProjectHealthRef,
            projectId,
          ),
          from: projectHealthProvider,
          name: r'projectHealthProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$projectHealthHash,
          dependencies: ProjectHealthFamily._dependencies,
          allTransitiveDependencies:
              ProjectHealthFamily._allTransitiveDependencies,
          projectId: projectId,
        );

  ProjectHealthProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.projectId,
  }) : super.internal();

  final String projectId;

  @override
  Override overrideWith(
    FutureOr<ProjectHealth> Function(ProjectHealthRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: ProjectHealthProvider._internal(
        (ref) => create(ref as ProjectHealthRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        projectId: projectId,
      ),
    );
  }

  @override
  AutoDisposeFutureProviderElement<ProjectHealth> createElement() {
    return _ProjectHealthProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is ProjectHealthProvider && other.projectId == projectId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, projectId.hashCode);

    return _SystemHash.finish(hash);
  }
}

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
mixin ProjectHealthRef on AutoDisposeFutureProviderRef<ProjectHealth> {
  /// The parameter `projectId` of this provider.
  String get projectId;
}

class _ProjectHealthProviderElement
    extends AutoDisposeFutureProviderElement<ProjectHealth>
    with ProjectHealthRef {
  _ProjectHealthProviderElement(super.provider);

  @override
  String get projectId => (origin as ProjectHealthProvider).projectId;
}
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
