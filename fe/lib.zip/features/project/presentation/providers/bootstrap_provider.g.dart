// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'bootstrap_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$bootstrapGuestUserHash() =>
    r'5d1ff42dd0c36feca1f6c3b6af9fa9fdf7af06c1';

/// Provider for BootstrapGuestUser use case
/// Handles guest user initialization via bootstrap endpoint
///
/// Copied from [bootstrapGuestUser].
@ProviderFor(bootstrapGuestUser)
final bootstrapGuestUserProvider =
    AutoDisposeProvider<BootstrapGuestUser>.internal(
  bootstrapGuestUser,
  name: r'bootstrapGuestUserProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$bootstrapGuestUserHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef BootstrapGuestUserRef = AutoDisposeProviderRef<BootstrapGuestUser>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
