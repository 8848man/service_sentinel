// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'project_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$loadProjectsHash() => r'9b103d3e015b99e041ef056e290f6ac0c92d6956';

/// Provider for LoadProjects use case
///
/// Copied from [loadProjects].
@ProviderFor(loadProjects)
final loadProjectsProvider = AutoDisposeProvider<LoadProjects>.internal(
  loadProjects,
  name: r'loadProjectsProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$loadProjectsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef LoadProjectsRef = AutoDisposeProviderRef<LoadProjects>;
String _$createProjectHash() => r'7abadabed2081d162b42870550cae015deaeb4f4';

/// Provider for CreateProject use case
///
/// Copied from [createProject].
@ProviderFor(createProject)
final createProjectProvider = AutoDisposeProvider<CreateProject>.internal(
  createProject,
  name: r'createProjectProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$createProjectHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef CreateProjectRef = AutoDisposeProviderRef<CreateProject>;
String _$updateProjectHash() => r'10253390781564fa4b19dff1689ac3dc7cf30157';

/// Provider for UpdateProject use case
///
/// Copied from [updateProject].
@ProviderFor(updateProject)
final updateProjectProvider = AutoDisposeProvider<UpdateProject>.internal(
  updateProject,
  name: r'updateProjectProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$updateProjectHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef UpdateProjectRef = AutoDisposeProviderRef<UpdateProject>;
String _$deleteProjectHash() => r'638f41cb6f840310eb9a9df4632bdd5a00eae0c3';

/// Provider for DeleteProject use case
///
/// Copied from [deleteProject].
@ProviderFor(deleteProject)
final deleteProjectProvider = AutoDisposeProvider<DeleteProject>.internal(
  deleteProject,
  name: r'deleteProjectProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$deleteProjectHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef DeleteProjectRef = AutoDisposeProviderRef<DeleteProject>;
String _$projectsHash() => r'a3d34964c1eeaed1dcf7bb1f7912ce7b48d35f5e';

/// Provider to fetch all projects
/// This provider auto-refreshes when dependencies change
///
/// Copied from [projects].
@ProviderFor(projects)
final projectsProvider = AutoDisposeFutureProvider<List<Project>>.internal(
  projects,
  name: r'projectsProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$projectsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef ProjectsRef = AutoDisposeFutureProviderRef<List<Project>>;
String _$activeProjectsHash() => r'40d3d8d493659334f7c340d0999feb445a4007c7';

/// Provider to fetch active projects only
///
/// Copied from [activeProjects].
@ProviderFor(activeProjects)
final activeProjectsProvider =
    AutoDisposeFutureProvider<List<Project>>.internal(
  activeProjects,
  name: r'activeProjectsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$activeProjectsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef ActiveProjectsRef = AutoDisposeFutureProviderRef<List<Project>>;
String _$projectByIdHash() => r'3f46135f2ba569be0b071ab427fc8df69d2ba00a';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

/// Provider to fetch a project by ID
///
/// Copied from [projectById].
@ProviderFor(projectById)
const projectByIdProvider = ProjectByIdFamily();

/// Provider to fetch a project by ID
///
/// Copied from [projectById].
class ProjectByIdFamily extends Family<AsyncValue<Project>> {
  /// Provider to fetch a project by ID
  ///
  /// Copied from [projectById].
  const ProjectByIdFamily();

  /// Provider to fetch a project by ID
  ///
  /// Copied from [projectById].
  ProjectByIdProvider call(
    String projectId,
  ) {
    return ProjectByIdProvider(
      projectId,
    );
  }

  @override
  ProjectByIdProvider getProviderOverride(
    covariant ProjectByIdProvider provider,
  ) {
    return call(
      provider.projectId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'projectByIdProvider';
}

/// Provider to fetch a project by ID
///
/// Copied from [projectById].
class ProjectByIdProvider extends AutoDisposeFutureProvider<Project> {
  /// Provider to fetch a project by ID
  ///
  /// Copied from [projectById].
  ProjectByIdProvider(
    String projectId,
  ) : this._internal(
          (ref) => projectById(
            ref as ProjectByIdRef,
            projectId,
          ),
          from: projectByIdProvider,
          name: r'projectByIdProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$projectByIdHash,
          dependencies: ProjectByIdFamily._dependencies,
          allTransitiveDependencies:
              ProjectByIdFamily._allTransitiveDependencies,
          projectId: projectId,
        );

  ProjectByIdProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.projectId,
  }) : super.internal();

  final String projectId;

  @override
  Override overrideWith(
    FutureOr<Project> Function(ProjectByIdRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: ProjectByIdProvider._internal(
        (ref) => create(ref as ProjectByIdRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        projectId: projectId,
      ),
    );
  }

  @override
  AutoDisposeFutureProviderElement<Project> createElement() {
    return _ProjectByIdProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is ProjectByIdProvider && other.projectId == projectId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, projectId.hashCode);

    return _SystemHash.finish(hash);
  }
}

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
mixin ProjectByIdRef on AutoDisposeFutureProviderRef<Project> {
  /// The parameter `projectId` of this provider.
  String get projectId;
}

class _ProjectByIdProviderElement
    extends AutoDisposeFutureProviderElement<Project> with ProjectByIdRef {
  _ProjectByIdProviderElement(super.provider);

  @override
  String get projectId => (origin as ProjectByIdProvider).projectId;
}

String _$projectStatsHash() => r'a54824e6a1c1e8e94199d3cbf574fd3767de0933';

/// Provider to fetch project statistics
///
/// Copied from [projectStats].
@ProviderFor(projectStats)
const projectStatsProvider = ProjectStatsFamily();

/// Provider to fetch project statistics
///
/// Copied from [projectStats].
class ProjectStatsFamily extends Family<AsyncValue<ProjectStats>> {
  /// Provider to fetch project statistics
  ///
  /// Copied from [projectStats].
  const ProjectStatsFamily();

  /// Provider to fetch project statistics
  ///
  /// Copied from [projectStats].
  ProjectStatsProvider call(
    String projectId,
  ) {
    return ProjectStatsProvider(
      projectId,
    );
  }

  @override
  ProjectStatsProvider getProviderOverride(
    covariant ProjectStatsProvider provider,
  ) {
    return call(
      provider.projectId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'projectStatsProvider';
}

/// Provider to fetch project statistics
///
/// Copied from [projectStats].
class ProjectStatsProvider extends AutoDisposeFutureProvider<ProjectStats> {
  /// Provider to fetch project statistics
  ///
  /// Copied from [projectStats].
  ProjectStatsProvider(
    String projectId,
  ) : this._internal(
          (ref) => projectStats(
            ref as ProjectStatsRef,
            projectId,
          ),
          from: projectStatsProvider,
          name: r'projectStatsProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$projectStatsHash,
          dependencies: ProjectStatsFamily._dependencies,
          allTransitiveDependencies:
              ProjectStatsFamily._allTransitiveDependencies,
          projectId: projectId,
        );

  ProjectStatsProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.projectId,
  }) : super.internal();

  final String projectId;

  @override
  Override overrideWith(
    FutureOr<ProjectStats> Function(ProjectStatsRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: ProjectStatsProvider._internal(
        (ref) => create(ref as ProjectStatsRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        projectId: projectId,
      ),
    );
  }

  @override
  AutoDisposeFutureProviderElement<ProjectStats> createElement() {
    return _ProjectStatsProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is ProjectStatsProvider && other.projectId == projectId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, projectId.hashCode);

    return _SystemHash.finish(hash);
  }
}

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
mixin ProjectStatsRef on AutoDisposeFutureProviderRef<ProjectStats> {
  /// The parameter `projectId` of this provider.
  String get projectId;
}

class _ProjectStatsProviderElement
    extends AutoDisposeFutureProviderElement<ProjectStats>
    with ProjectStatsRef {
  _ProjectStatsProviderElement(super.provider);

  @override
  String get projectId => (origin as ProjectStatsProvider).projectId;
}
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
