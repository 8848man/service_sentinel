// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'bootstrap.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$BootstrapResponse {
  Project get project => throw _privateConstructorUsedError;
  String get apiKey =>
      throw _privateConstructorUsedError; // Field name: apiKey (matches backend response field 'api_key')
  String? get message => throw _privateConstructorUsedError;

  /// Create a copy of BootstrapResponse
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $BootstrapResponseCopyWith<BootstrapResponse> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BootstrapResponseCopyWith<$Res> {
  factory $BootstrapResponseCopyWith(
          BootstrapResponse value, $Res Function(BootstrapResponse) then) =
      _$BootstrapResponseCopyWithImpl<$Res, BootstrapResponse>;
  @useResult
  $Res call({Project project, String apiKey, String? message});

  $ProjectCopyWith<$Res> get project;
}

/// @nodoc
class _$BootstrapResponseCopyWithImpl<$Res, $Val extends BootstrapResponse>
    implements $BootstrapResponseCopyWith<$Res> {
  _$BootstrapResponseCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of BootstrapResponse
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project = null,
    Object? apiKey = null,
    Object? message = freezed,
  }) {
    return _then(_value.copyWith(
      project: null == project
          ? _value.project
          : project // ignore: cast_nullable_to_non_nullable
              as Project,
      apiKey: null == apiKey
          ? _value.apiKey
          : apiKey // ignore: cast_nullable_to_non_nullable
              as String,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  /// Create a copy of BootstrapResponse
  /// with the given fields replaced by the non-null parameter values.
  @override
  @pragma('vm:prefer-inline')
  $ProjectCopyWith<$Res> get project {
    return $ProjectCopyWith<$Res>(_value.project, (value) {
      return _then(_value.copyWith(project: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$BootstrapResponseImplCopyWith<$Res>
    implements $BootstrapResponseCopyWith<$Res> {
  factory _$$BootstrapResponseImplCopyWith(_$BootstrapResponseImpl value,
          $Res Function(_$BootstrapResponseImpl) then) =
      __$$BootstrapResponseImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Project project, String apiKey, String? message});

  @override
  $ProjectCopyWith<$Res> get project;
}

/// @nodoc
class __$$BootstrapResponseImplCopyWithImpl<$Res>
    extends _$BootstrapResponseCopyWithImpl<$Res, _$BootstrapResponseImpl>
    implements _$$BootstrapResponseImplCopyWith<$Res> {
  __$$BootstrapResponseImplCopyWithImpl(_$BootstrapResponseImpl _value,
      $Res Function(_$BootstrapResponseImpl) _then)
      : super(_value, _then);

  /// Create a copy of BootstrapResponse
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? project = null,
    Object? apiKey = null,
    Object? message = freezed,
  }) {
    return _then(_$BootstrapResponseImpl(
      project: null == project
          ? _value.project
          : project // ignore: cast_nullable_to_non_nullable
              as Project,
      apiKey: null == apiKey
          ? _value.apiKey
          : apiKey // ignore: cast_nullable_to_non_nullable
              as String,
      message: freezed == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

class _$BootstrapResponseImpl implements _BootstrapResponse {
  const _$BootstrapResponseImpl(
      {required this.project, required this.apiKey, this.message});

  @override
  final Project project;
  @override
  final String apiKey;
// Field name: apiKey (matches backend response field 'api_key')
  @override
  final String? message;

  @override
  String toString() {
    return 'BootstrapResponse(project: $project, apiKey: $apiKey, message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BootstrapResponseImpl &&
            (identical(other.project, project) || other.project == project) &&
            (identical(other.apiKey, apiKey) || other.apiKey == apiKey) &&
            (identical(other.message, message) || other.message == message));
  }

  @override
  int get hashCode => Object.hash(runtimeType, project, apiKey, message);

  /// Create a copy of BootstrapResponse
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$BootstrapResponseImplCopyWith<_$BootstrapResponseImpl> get copyWith =>
      __$$BootstrapResponseImplCopyWithImpl<_$BootstrapResponseImpl>(
          this, _$identity);
}

abstract class _BootstrapResponse implements BootstrapResponse {
  const factory _BootstrapResponse(
      {required final Project project,
      required final String apiKey,
      final String? message}) = _$BootstrapResponseImpl;

  @override
  Project get project;
  @override
  String
      get apiKey; // Field name: apiKey (matches backend response field 'api_key')
  @override
  String? get message;

  /// Create a copy of BootstrapResponse
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$BootstrapResponseImplCopyWith<_$BootstrapResponseImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$BootstrapRequest {
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;

  /// Create a copy of BootstrapRequest
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $BootstrapRequestCopyWith<BootstrapRequest> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $BootstrapRequestCopyWith<$Res> {
  factory $BootstrapRequestCopyWith(
          BootstrapRequest value, $Res Function(BootstrapRequest) then) =
      _$BootstrapRequestCopyWithImpl<$Res, BootstrapRequest>;
  @useResult
  $Res call({String name, String? description});
}

/// @nodoc
class _$BootstrapRequestCopyWithImpl<$Res, $Val extends BootstrapRequest>
    implements $BootstrapRequestCopyWith<$Res> {
  _$BootstrapRequestCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of BootstrapRequest
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$BootstrapRequestImplCopyWith<$Res>
    implements $BootstrapRequestCopyWith<$Res> {
  factory _$$BootstrapRequestImplCopyWith(_$BootstrapRequestImpl value,
          $Res Function(_$BootstrapRequestImpl) then) =
      __$$BootstrapRequestImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String name, String? description});
}

/// @nodoc
class __$$BootstrapRequestImplCopyWithImpl<$Res>
    extends _$BootstrapRequestCopyWithImpl<$Res, _$BootstrapRequestImpl>
    implements _$$BootstrapRequestImplCopyWith<$Res> {
  __$$BootstrapRequestImplCopyWithImpl(_$BootstrapRequestImpl _value,
      $Res Function(_$BootstrapRequestImpl) _then)
      : super(_value, _then);

  /// Create a copy of BootstrapRequest
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
  }) {
    return _then(_$BootstrapRequestImpl(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

class _$BootstrapRequestImpl implements _BootstrapRequest {
  const _$BootstrapRequestImpl({required this.name, this.description});

  @override
  final String name;
  @override
  final String? description;

  @override
  String toString() {
    return 'BootstrapRequest(name: $name, description: $description)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$BootstrapRequestImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description));
  }

  @override
  int get hashCode => Object.hash(runtimeType, name, description);

  /// Create a copy of BootstrapRequest
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$BootstrapRequestImplCopyWith<_$BootstrapRequestImpl> get copyWith =>
      __$$BootstrapRequestImplCopyWithImpl<_$BootstrapRequestImpl>(
          this, _$identity);
}

abstract class _BootstrapRequest implements BootstrapRequest {
  const factory _BootstrapRequest(
      {required final String name,
      final String? description}) = _$BootstrapRequestImpl;

  @override
  String get name;
  @override
  String? get description;

  /// Create a copy of BootstrapRequest
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$BootstrapRequestImplCopyWith<_$BootstrapRequestImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
