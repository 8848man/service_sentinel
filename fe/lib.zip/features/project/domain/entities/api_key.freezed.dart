// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'api_key.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ApiKey {
  String get id => throw _privateConstructorUsedError;
  String get projectId => throw _privateConstructorUsedError;
  String get keyValue =>
      throw _privateConstructorUsedError; // The actual key value (e.g., "ss_abc123...")
  String get name =>
      throw _privateConstructorUsedError; // Human-readable name (e.g., "Production Key")
  String? get description => throw _privateConstructorUsedError;
  bool get isActive => throw _privateConstructorUsedError;
  DateTime? get lastUsedAt => throw _privateConstructorUsedError;
  int get usageCount => throw _privateConstructorUsedError;
  DateTime get createdAt => throw _privateConstructorUsedError;
  DateTime? get expiresAt => throw _privateConstructorUsedError;

  /// Create a copy of ApiKey
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ApiKeyCopyWith<ApiKey> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ApiKeyCopyWith<$Res> {
  factory $ApiKeyCopyWith(ApiKey value, $Res Function(ApiKey) then) =
      _$ApiKeyCopyWithImpl<$Res, ApiKey>;
  @useResult
  $Res call(
      {String id,
      String projectId,
      String keyValue,
      String name,
      String? description,
      bool isActive,
      DateTime? lastUsedAt,
      int usageCount,
      DateTime createdAt,
      DateTime? expiresAt});
}

/// @nodoc
class _$ApiKeyCopyWithImpl<$Res, $Val extends ApiKey>
    implements $ApiKeyCopyWith<$Res> {
  _$ApiKeyCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ApiKey
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? projectId = null,
    Object? keyValue = null,
    Object? name = null,
    Object? description = freezed,
    Object? isActive = null,
    Object? lastUsedAt = freezed,
    Object? usageCount = null,
    Object? createdAt = null,
    Object? expiresAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      projectId: null == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as String,
      keyValue: null == keyValue
          ? _value.keyValue
          : keyValue // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      lastUsedAt: freezed == lastUsedAt
          ? _value.lastUsedAt
          : lastUsedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      usageCount: null == usageCount
          ? _value.usageCount
          : usageCount // ignore: cast_nullable_to_non_nullable
              as int,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      expiresAt: freezed == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ApiKeyImplCopyWith<$Res> implements $ApiKeyCopyWith<$Res> {
  factory _$$ApiKeyImplCopyWith(
          _$ApiKeyImpl value, $Res Function(_$ApiKeyImpl) then) =
      __$$ApiKeyImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String projectId,
      String keyValue,
      String name,
      String? description,
      bool isActive,
      DateTime? lastUsedAt,
      int usageCount,
      DateTime createdAt,
      DateTime? expiresAt});
}

/// @nodoc
class __$$ApiKeyImplCopyWithImpl<$Res>
    extends _$ApiKeyCopyWithImpl<$Res, _$ApiKeyImpl>
    implements _$$ApiKeyImplCopyWith<$Res> {
  __$$ApiKeyImplCopyWithImpl(
      _$ApiKeyImpl _value, $Res Function(_$ApiKeyImpl) _then)
      : super(_value, _then);

  /// Create a copy of ApiKey
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? projectId = null,
    Object? keyValue = null,
    Object? name = null,
    Object? description = freezed,
    Object? isActive = null,
    Object? lastUsedAt = freezed,
    Object? usageCount = null,
    Object? createdAt = null,
    Object? expiresAt = freezed,
  }) {
    return _then(_$ApiKeyImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      projectId: null == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as String,
      keyValue: null == keyValue
          ? _value.keyValue
          : keyValue // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      lastUsedAt: freezed == lastUsedAt
          ? _value.lastUsedAt
          : lastUsedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      usageCount: null == usageCount
          ? _value.usageCount
          : usageCount // ignore: cast_nullable_to_non_nullable
              as int,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      expiresAt: freezed == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$ApiKeyImpl extends _ApiKey {
  const _$ApiKeyImpl(
      {required this.id,
      required this.projectId,
      required this.keyValue,
      required this.name,
      this.description,
      required this.isActive,
      this.lastUsedAt,
      required this.usageCount,
      required this.createdAt,
      this.expiresAt})
      : super._();

  @override
  final String id;
  @override
  final String projectId;
  @override
  final String keyValue;
// The actual key value (e.g., "ss_abc123...")
  @override
  final String name;
// Human-readable name (e.g., "Production Key")
  @override
  final String? description;
  @override
  final bool isActive;
  @override
  final DateTime? lastUsedAt;
  @override
  final int usageCount;
  @override
  final DateTime createdAt;
  @override
  final DateTime? expiresAt;

  @override
  String toString() {
    return 'ApiKey(id: $id, projectId: $projectId, keyValue: $keyValue, name: $name, description: $description, isActive: $isActive, lastUsedAt: $lastUsedAt, usageCount: $usageCount, createdAt: $createdAt, expiresAt: $expiresAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ApiKeyImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.projectId, projectId) ||
                other.projectId == projectId) &&
            (identical(other.keyValue, keyValue) ||
                other.keyValue == keyValue) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.isActive, isActive) ||
                other.isActive == isActive) &&
            (identical(other.lastUsedAt, lastUsedAt) ||
                other.lastUsedAt == lastUsedAt) &&
            (identical(other.usageCount, usageCount) ||
                other.usageCount == usageCount) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.expiresAt, expiresAt) ||
                other.expiresAt == expiresAt));
  }

  @override
  int get hashCode => Object.hash(runtimeType, id, projectId, keyValue, name,
      description, isActive, lastUsedAt, usageCount, createdAt, expiresAt);

  /// Create a copy of ApiKey
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ApiKeyImplCopyWith<_$ApiKeyImpl> get copyWith =>
      __$$ApiKeyImplCopyWithImpl<_$ApiKeyImpl>(this, _$identity);
}

abstract class _ApiKey extends ApiKey {
  const factory _ApiKey(
      {required final String id,
      required final String projectId,
      required final String keyValue,
      required final String name,
      final String? description,
      required final bool isActive,
      final DateTime? lastUsedAt,
      required final int usageCount,
      required final DateTime createdAt,
      final DateTime? expiresAt}) = _$ApiKeyImpl;
  const _ApiKey._() : super._();

  @override
  String get id;
  @override
  String get projectId;
  @override
  String get keyValue; // The actual key value (e.g., "ss_abc123...")
  @override
  String get name; // Human-readable name (e.g., "Production Key")
  @override
  String? get description;
  @override
  bool get isActive;
  @override
  DateTime? get lastUsedAt;
  @override
  int get usageCount;
  @override
  DateTime get createdAt;
  @override
  DateTime? get expiresAt;

  /// Create a copy of ApiKey
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ApiKeyImplCopyWith<_$ApiKeyImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ApiKeyCreate {
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  DateTime? get expiresAt => throw _privateConstructorUsedError;

  /// Create a copy of ApiKeyCreate
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ApiKeyCreateCopyWith<ApiKeyCreate> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ApiKeyCreateCopyWith<$Res> {
  factory $ApiKeyCreateCopyWith(
          ApiKeyCreate value, $Res Function(ApiKeyCreate) then) =
      _$ApiKeyCreateCopyWithImpl<$Res, ApiKeyCreate>;
  @useResult
  $Res call({String name, String? description, DateTime? expiresAt});
}

/// @nodoc
class _$ApiKeyCreateCopyWithImpl<$Res, $Val extends ApiKeyCreate>
    implements $ApiKeyCreateCopyWith<$Res> {
  _$ApiKeyCreateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ApiKeyCreate
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
    Object? expiresAt = freezed,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      expiresAt: freezed == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ApiKeyCreateImplCopyWith<$Res>
    implements $ApiKeyCreateCopyWith<$Res> {
  factory _$$ApiKeyCreateImplCopyWith(
          _$ApiKeyCreateImpl value, $Res Function(_$ApiKeyCreateImpl) then) =
      __$$ApiKeyCreateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String name, String? description, DateTime? expiresAt});
}

/// @nodoc
class __$$ApiKeyCreateImplCopyWithImpl<$Res>
    extends _$ApiKeyCreateCopyWithImpl<$Res, _$ApiKeyCreateImpl>
    implements _$$ApiKeyCreateImplCopyWith<$Res> {
  __$$ApiKeyCreateImplCopyWithImpl(
      _$ApiKeyCreateImpl _value, $Res Function(_$ApiKeyCreateImpl) _then)
      : super(_value, _then);

  /// Create a copy of ApiKeyCreate
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
    Object? expiresAt = freezed,
  }) {
    return _then(_$ApiKeyCreateImpl(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      expiresAt: freezed == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$ApiKeyCreateImpl implements _ApiKeyCreate {
  const _$ApiKeyCreateImpl(
      {required this.name, this.description, this.expiresAt});

  @override
  final String name;
  @override
  final String? description;
  @override
  final DateTime? expiresAt;

  @override
  String toString() {
    return 'ApiKeyCreate(name: $name, description: $description, expiresAt: $expiresAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ApiKeyCreateImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.expiresAt, expiresAt) ||
                other.expiresAt == expiresAt));
  }

  @override
  int get hashCode => Object.hash(runtimeType, name, description, expiresAt);

  /// Create a copy of ApiKeyCreate
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ApiKeyCreateImplCopyWith<_$ApiKeyCreateImpl> get copyWith =>
      __$$ApiKeyCreateImplCopyWithImpl<_$ApiKeyCreateImpl>(this, _$identity);
}

abstract class _ApiKeyCreate implements ApiKeyCreate {
  const factory _ApiKeyCreate(
      {required final String name,
      final String? description,
      final DateTime? expiresAt}) = _$ApiKeyCreateImpl;

  @override
  String get name;
  @override
  String? get description;
  @override
  DateTime? get expiresAt;

  /// Create a copy of ApiKeyCreate
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ApiKeyCreateImplCopyWith<_$ApiKeyCreateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
