// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'project_health.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ProjectHealth {
  ProjectHealthStatus get status => throw _privateConstructorUsedError;
  int get totalServices => throw _privateConstructorUsedError;
  int get healthyServices => throw _privateConstructorUsedError;
  int get errorServices => throw _privateConstructorUsedError;
  int get inactiveServices => throw _privateConstructorUsedError;
  int get activeIncidents => throw _privateConstructorUsedError;

  /// Create a copy of ProjectHealth
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ProjectHealthCopyWith<ProjectHealth> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectHealthCopyWith<$Res> {
  factory $ProjectHealthCopyWith(
          ProjectHealth value, $Res Function(ProjectHealth) then) =
      _$ProjectHealthCopyWithImpl<$Res, ProjectHealth>;
  @useResult
  $Res call(
      {ProjectHealthStatus status,
      int totalServices,
      int healthyServices,
      int errorServices,
      int inactiveServices,
      int activeIncidents});
}

/// @nodoc
class _$ProjectHealthCopyWithImpl<$Res, $Val extends ProjectHealth>
    implements $ProjectHealthCopyWith<$Res> {
  _$ProjectHealthCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ProjectHealth
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? errorServices = null,
    Object? inactiveServices = null,
    Object? activeIncidents = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as ProjectHealthStatus,
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      errorServices: null == errorServices
          ? _value.errorServices
          : errorServices // ignore: cast_nullable_to_non_nullable
              as int,
      inactiveServices: null == inactiveServices
          ? _value.inactiveServices
          : inactiveServices // ignore: cast_nullable_to_non_nullable
              as int,
      activeIncidents: null == activeIncidents
          ? _value.activeIncidents
          : activeIncidents // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProjectHealthImplCopyWith<$Res>
    implements $ProjectHealthCopyWith<$Res> {
  factory _$$ProjectHealthImplCopyWith(
          _$ProjectHealthImpl value, $Res Function(_$ProjectHealthImpl) then) =
      __$$ProjectHealthImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {ProjectHealthStatus status,
      int totalServices,
      int healthyServices,
      int errorServices,
      int inactiveServices,
      int activeIncidents});
}

/// @nodoc
class __$$ProjectHealthImplCopyWithImpl<$Res>
    extends _$ProjectHealthCopyWithImpl<$Res, _$ProjectHealthImpl>
    implements _$$ProjectHealthImplCopyWith<$Res> {
  __$$ProjectHealthImplCopyWithImpl(
      _$ProjectHealthImpl _value, $Res Function(_$ProjectHealthImpl) _then)
      : super(_value, _then);

  /// Create a copy of ProjectHealth
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? errorServices = null,
    Object? inactiveServices = null,
    Object? activeIncidents = null,
  }) {
    return _then(_$ProjectHealthImpl(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as ProjectHealthStatus,
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      errorServices: null == errorServices
          ? _value.errorServices
          : errorServices // ignore: cast_nullable_to_non_nullable
              as int,
      inactiveServices: null == inactiveServices
          ? _value.inactiveServices
          : inactiveServices // ignore: cast_nullable_to_non_nullable
              as int,
      activeIncidents: null == activeIncidents
          ? _value.activeIncidents
          : activeIncidents // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$ProjectHealthImpl implements _ProjectHealth {
  const _$ProjectHealthImpl(
      {required this.status,
      required this.totalServices,
      required this.healthyServices,
      required this.errorServices,
      required this.inactiveServices,
      required this.activeIncidents});

  @override
  final ProjectHealthStatus status;
  @override
  final int totalServices;
  @override
  final int healthyServices;
  @override
  final int errorServices;
  @override
  final int inactiveServices;
  @override
  final int activeIncidents;

  @override
  String toString() {
    return 'ProjectHealth(status: $status, totalServices: $totalServices, healthyServices: $healthyServices, errorServices: $errorServices, inactiveServices: $inactiveServices, activeIncidents: $activeIncidents)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProjectHealthImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.totalServices, totalServices) ||
                other.totalServices == totalServices) &&
            (identical(other.healthyServices, healthyServices) ||
                other.healthyServices == healthyServices) &&
            (identical(other.errorServices, errorServices) ||
                other.errorServices == errorServices) &&
            (identical(other.inactiveServices, inactiveServices) ||
                other.inactiveServices == inactiveServices) &&
            (identical(other.activeIncidents, activeIncidents) ||
                other.activeIncidents == activeIncidents));
  }

  @override
  int get hashCode => Object.hash(runtimeType, status, totalServices,
      healthyServices, errorServices, inactiveServices, activeIncidents);

  /// Create a copy of ProjectHealth
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ProjectHealthImplCopyWith<_$ProjectHealthImpl> get copyWith =>
      __$$ProjectHealthImplCopyWithImpl<_$ProjectHealthImpl>(this, _$identity);
}

abstract class _ProjectHealth implements ProjectHealth {
  const factory _ProjectHealth(
      {required final ProjectHealthStatus status,
      required final int totalServices,
      required final int healthyServices,
      required final int errorServices,
      required final int inactiveServices,
      required final int activeIncidents}) = _$ProjectHealthImpl;

  @override
  ProjectHealthStatus get status;
  @override
  int get totalServices;
  @override
  int get healthyServices;
  @override
  int get errorServices;
  @override
  int get inactiveServices;
  @override
  int get activeIncidents;

  /// Create a copy of ProjectHealth
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ProjectHealthImplCopyWith<_$ProjectHealthImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
