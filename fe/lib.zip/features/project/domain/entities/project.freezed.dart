// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'project.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$Project {
  int get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  bool get isActive => throw _privateConstructorUsedError;
  DateTime get createdAt => throw _privateConstructorUsedError;
  DateTime get updatedAt =>
      throw _privateConstructorUsedError; // Local-only flag to track if project exists only in local DB
  bool get isLocalOnly =>
      throw _privateConstructorUsedError; // API keys for this project (one-to-many relationship)
  List<ApiKey> get apiKeys => throw _privateConstructorUsedError;
  ProjectHealth? get health => throw _privateConstructorUsedError;

  /// Create a copy of Project
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ProjectCopyWith<Project> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectCopyWith<$Res> {
  factory $ProjectCopyWith(Project value, $Res Function(Project) then) =
      _$ProjectCopyWithImpl<$Res, Project>;
  @useResult
  $Res call(
      {int id,
      String name,
      String? description,
      bool isActive,
      DateTime createdAt,
      DateTime updatedAt,
      bool isLocalOnly,
      List<ApiKey> apiKeys,
      ProjectHealth? health});

  $ProjectHealthCopyWith<$Res>? get health;
}

/// @nodoc
class _$ProjectCopyWithImpl<$Res, $Val extends Project>
    implements $ProjectCopyWith<$Res> {
  _$ProjectCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of Project
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? description = freezed,
    Object? isActive = null,
    Object? createdAt = null,
    Object? updatedAt = null,
    Object? isLocalOnly = null,
    Object? apiKeys = null,
    Object? health = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      isLocalOnly: null == isLocalOnly
          ? _value.isLocalOnly
          : isLocalOnly // ignore: cast_nullable_to_non_nullable
              as bool,
      apiKeys: null == apiKeys
          ? _value.apiKeys
          : apiKeys // ignore: cast_nullable_to_non_nullable
              as List<ApiKey>,
      health: freezed == health
          ? _value.health
          : health // ignore: cast_nullable_to_non_nullable
              as ProjectHealth?,
    ) as $Val);
  }

  /// Create a copy of Project
  /// with the given fields replaced by the non-null parameter values.
  @override
  @pragma('vm:prefer-inline')
  $ProjectHealthCopyWith<$Res>? get health {
    if (_value.health == null) {
      return null;
    }

    return $ProjectHealthCopyWith<$Res>(_value.health!, (value) {
      return _then(_value.copyWith(health: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$ProjectImplCopyWith<$Res> implements $ProjectCopyWith<$Res> {
  factory _$$ProjectImplCopyWith(
          _$ProjectImpl value, $Res Function(_$ProjectImpl) then) =
      __$$ProjectImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int id,
      String name,
      String? description,
      bool isActive,
      DateTime createdAt,
      DateTime updatedAt,
      bool isLocalOnly,
      List<ApiKey> apiKeys,
      ProjectHealth? health});

  @override
  $ProjectHealthCopyWith<$Res>? get health;
}

/// @nodoc
class __$$ProjectImplCopyWithImpl<$Res>
    extends _$ProjectCopyWithImpl<$Res, _$ProjectImpl>
    implements _$$ProjectImplCopyWith<$Res> {
  __$$ProjectImplCopyWithImpl(
      _$ProjectImpl _value, $Res Function(_$ProjectImpl) _then)
      : super(_value, _then);

  /// Create a copy of Project
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? description = freezed,
    Object? isActive = null,
    Object? createdAt = null,
    Object? updatedAt = null,
    Object? isLocalOnly = null,
    Object? apiKeys = null,
    Object? health = freezed,
  }) {
    return _then(_$ProjectImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      isActive: null == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      updatedAt: null == updatedAt
          ? _value.updatedAt
          : updatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      isLocalOnly: null == isLocalOnly
          ? _value.isLocalOnly
          : isLocalOnly // ignore: cast_nullable_to_non_nullable
              as bool,
      apiKeys: null == apiKeys
          ? _value._apiKeys
          : apiKeys // ignore: cast_nullable_to_non_nullable
              as List<ApiKey>,
      health: freezed == health
          ? _value.health
          : health // ignore: cast_nullable_to_non_nullable
              as ProjectHealth?,
    ));
  }
}

/// @nodoc

class _$ProjectImpl extends _Project {
  const _$ProjectImpl(
      {required this.id,
      required this.name,
      this.description,
      required this.isActive,
      required this.createdAt,
      required this.updatedAt,
      this.isLocalOnly = false,
      final List<ApiKey> apiKeys = const [],
      this.health})
      : _apiKeys = apiKeys,
        super._();

  @override
  final int id;
  @override
  final String name;
  @override
  final String? description;
  @override
  final bool isActive;
  @override
  final DateTime createdAt;
  @override
  final DateTime updatedAt;
// Local-only flag to track if project exists only in local DB
  @override
  @JsonKey()
  final bool isLocalOnly;
// API keys for this project (one-to-many relationship)
  final List<ApiKey> _apiKeys;
// API keys for this project (one-to-many relationship)
  @override
  @JsonKey()
  List<ApiKey> get apiKeys {
    if (_apiKeys is EqualUnmodifiableListView) return _apiKeys;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_apiKeys);
  }

  @override
  final ProjectHealth? health;

  @override
  String toString() {
    return 'Project(id: $id, name: $name, description: $description, isActive: $isActive, createdAt: $createdAt, updatedAt: $updatedAt, isLocalOnly: $isLocalOnly, apiKeys: $apiKeys, health: $health)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProjectImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.isActive, isActive) ||
                other.isActive == isActive) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.updatedAt, updatedAt) ||
                other.updatedAt == updatedAt) &&
            (identical(other.isLocalOnly, isLocalOnly) ||
                other.isLocalOnly == isLocalOnly) &&
            const DeepCollectionEquality().equals(other._apiKeys, _apiKeys) &&
            (identical(other.health, health) || other.health == health));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      name,
      description,
      isActive,
      createdAt,
      updatedAt,
      isLocalOnly,
      const DeepCollectionEquality().hash(_apiKeys),
      health);

  /// Create a copy of Project
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ProjectImplCopyWith<_$ProjectImpl> get copyWith =>
      __$$ProjectImplCopyWithImpl<_$ProjectImpl>(this, _$identity);
}

abstract class _Project extends Project {
  const factory _Project(
      {required final int id,
      required final String name,
      final String? description,
      required final bool isActive,
      required final DateTime createdAt,
      required final DateTime updatedAt,
      final bool isLocalOnly,
      final List<ApiKey> apiKeys,
      final ProjectHealth? health}) = _$ProjectImpl;
  const _Project._() : super._();

  @override
  int get id;
  @override
  String get name;
  @override
  String? get description;
  @override
  bool get isActive;
  @override
  DateTime get createdAt;
  @override
  DateTime
      get updatedAt; // Local-only flag to track if project exists only in local DB
  @override
  bool get isLocalOnly; // API keys for this project (one-to-many relationship)
  @override
  List<ApiKey> get apiKeys;
  @override
  ProjectHealth? get health;

  /// Create a copy of Project
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ProjectImplCopyWith<_$ProjectImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ProjectCreate {
  String get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;

  /// Create a copy of ProjectCreate
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ProjectCreateCopyWith<ProjectCreate> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectCreateCopyWith<$Res> {
  factory $ProjectCreateCopyWith(
          ProjectCreate value, $Res Function(ProjectCreate) then) =
      _$ProjectCreateCopyWithImpl<$Res, ProjectCreate>;
  @useResult
  $Res call({String name, String? description});
}

/// @nodoc
class _$ProjectCreateCopyWithImpl<$Res, $Val extends ProjectCreate>
    implements $ProjectCreateCopyWith<$Res> {
  _$ProjectCreateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ProjectCreate
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProjectCreateImplCopyWith<$Res>
    implements $ProjectCreateCopyWith<$Res> {
  factory _$$ProjectCreateImplCopyWith(
          _$ProjectCreateImpl value, $Res Function(_$ProjectCreateImpl) then) =
      __$$ProjectCreateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String name, String? description});
}

/// @nodoc
class __$$ProjectCreateImplCopyWithImpl<$Res>
    extends _$ProjectCreateCopyWithImpl<$Res, _$ProjectCreateImpl>
    implements _$$ProjectCreateImplCopyWith<$Res> {
  __$$ProjectCreateImplCopyWithImpl(
      _$ProjectCreateImpl _value, $Res Function(_$ProjectCreateImpl) _then)
      : super(_value, _then);

  /// Create a copy of ProjectCreate
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? description = freezed,
  }) {
    return _then(_$ProjectCreateImpl(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

class _$ProjectCreateImpl implements _ProjectCreate {
  const _$ProjectCreateImpl({required this.name, this.description});

  @override
  final String name;
  @override
  final String? description;

  @override
  String toString() {
    return 'ProjectCreate(name: $name, description: $description)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProjectCreateImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description));
  }

  @override
  int get hashCode => Object.hash(runtimeType, name, description);

  /// Create a copy of ProjectCreate
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ProjectCreateImplCopyWith<_$ProjectCreateImpl> get copyWith =>
      __$$ProjectCreateImplCopyWithImpl<_$ProjectCreateImpl>(this, _$identity);
}

abstract class _ProjectCreate implements ProjectCreate {
  const factory _ProjectCreate(
      {required final String name,
      final String? description}) = _$ProjectCreateImpl;

  @override
  String get name;
  @override
  String? get description;

  /// Create a copy of ProjectCreate
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ProjectCreateImplCopyWith<_$ProjectCreateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ProjectUpdate {
  String? get name => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  bool? get isActive => throw _privateConstructorUsedError;

  /// Create a copy of ProjectUpdate
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ProjectUpdateCopyWith<ProjectUpdate> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectUpdateCopyWith<$Res> {
  factory $ProjectUpdateCopyWith(
          ProjectUpdate value, $Res Function(ProjectUpdate) then) =
      _$ProjectUpdateCopyWithImpl<$Res, ProjectUpdate>;
  @useResult
  $Res call({String? name, String? description, bool? isActive});
}

/// @nodoc
class _$ProjectUpdateCopyWithImpl<$Res, $Val extends ProjectUpdate>
    implements $ProjectUpdateCopyWith<$Res> {
  _$ProjectUpdateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ProjectUpdate
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = freezed,
    Object? description = freezed,
    Object? isActive = freezed,
  }) {
    return _then(_value.copyWith(
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      isActive: freezed == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProjectUpdateImplCopyWith<$Res>
    implements $ProjectUpdateCopyWith<$Res> {
  factory _$$ProjectUpdateImplCopyWith(
          _$ProjectUpdateImpl value, $Res Function(_$ProjectUpdateImpl) then) =
      __$$ProjectUpdateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String? name, String? description, bool? isActive});
}

/// @nodoc
class __$$ProjectUpdateImplCopyWithImpl<$Res>
    extends _$ProjectUpdateCopyWithImpl<$Res, _$ProjectUpdateImpl>
    implements _$$ProjectUpdateImplCopyWith<$Res> {
  __$$ProjectUpdateImplCopyWithImpl(
      _$ProjectUpdateImpl _value, $Res Function(_$ProjectUpdateImpl) _then)
      : super(_value, _then);

  /// Create a copy of ProjectUpdate
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = freezed,
    Object? description = freezed,
    Object? isActive = freezed,
  }) {
    return _then(_$ProjectUpdateImpl(
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      isActive: freezed == isActive
          ? _value.isActive
          : isActive // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$ProjectUpdateImpl implements _ProjectUpdate {
  const _$ProjectUpdateImpl({this.name, this.description, this.isActive});

  @override
  final String? name;
  @override
  final String? description;
  @override
  final bool? isActive;

  @override
  String toString() {
    return 'ProjectUpdate(name: $name, description: $description, isActive: $isActive)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProjectUpdateImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.isActive, isActive) ||
                other.isActive == isActive));
  }

  @override
  int get hashCode => Object.hash(runtimeType, name, description, isActive);

  /// Create a copy of ProjectUpdate
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ProjectUpdateImplCopyWith<_$ProjectUpdateImpl> get copyWith =>
      __$$ProjectUpdateImplCopyWithImpl<_$ProjectUpdateImpl>(this, _$identity);
}

abstract class _ProjectUpdate implements ProjectUpdate {
  const factory _ProjectUpdate(
      {final String? name,
      final String? description,
      final bool? isActive}) = _$ProjectUpdateImpl;

  @override
  String? get name;
  @override
  String? get description;
  @override
  bool? get isActive;

  /// Create a copy of ProjectUpdate
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ProjectUpdateImplCopyWith<_$ProjectUpdateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ProjectStats {
  String get projectId => throw _privateConstructorUsedError;
  int get totalServices => throw _privateConstructorUsedError;
  int get healthyServices => throw _privateConstructorUsedError;
  int get unhealthyServices => throw _privateConstructorUsedError;
  int get openIncidents => throw _privateConstructorUsedError;

  /// Create a copy of ProjectStats
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ProjectStatsCopyWith<ProjectStats> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProjectStatsCopyWith<$Res> {
  factory $ProjectStatsCopyWith(
          ProjectStats value, $Res Function(ProjectStats) then) =
      _$ProjectStatsCopyWithImpl<$Res, ProjectStats>;
  @useResult
  $Res call(
      {String projectId,
      int totalServices,
      int healthyServices,
      int unhealthyServices,
      int openIncidents});
}

/// @nodoc
class _$ProjectStatsCopyWithImpl<$Res, $Val extends ProjectStats>
    implements $ProjectStatsCopyWith<$Res> {
  _$ProjectStatsCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ProjectStats
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? projectId = null,
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? unhealthyServices = null,
    Object? openIncidents = null,
  }) {
    return _then(_value.copyWith(
      projectId: null == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as String,
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      unhealthyServices: null == unhealthyServices
          ? _value.unhealthyServices
          : unhealthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      openIncidents: null == openIncidents
          ? _value.openIncidents
          : openIncidents // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProjectStatsImplCopyWith<$Res>
    implements $ProjectStatsCopyWith<$Res> {
  factory _$$ProjectStatsImplCopyWith(
          _$ProjectStatsImpl value, $Res Function(_$ProjectStatsImpl) then) =
      __$$ProjectStatsImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String projectId,
      int totalServices,
      int healthyServices,
      int unhealthyServices,
      int openIncidents});
}

/// @nodoc
class __$$ProjectStatsImplCopyWithImpl<$Res>
    extends _$ProjectStatsCopyWithImpl<$Res, _$ProjectStatsImpl>
    implements _$$ProjectStatsImplCopyWith<$Res> {
  __$$ProjectStatsImplCopyWithImpl(
      _$ProjectStatsImpl _value, $Res Function(_$ProjectStatsImpl) _then)
      : super(_value, _then);

  /// Create a copy of ProjectStats
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? projectId = null,
    Object? totalServices = null,
    Object? healthyServices = null,
    Object? unhealthyServices = null,
    Object? openIncidents = null,
  }) {
    return _then(_$ProjectStatsImpl(
      projectId: null == projectId
          ? _value.projectId
          : projectId // ignore: cast_nullable_to_non_nullable
              as String,
      totalServices: null == totalServices
          ? _value.totalServices
          : totalServices // ignore: cast_nullable_to_non_nullable
              as int,
      healthyServices: null == healthyServices
          ? _value.healthyServices
          : healthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      unhealthyServices: null == unhealthyServices
          ? _value.unhealthyServices
          : unhealthyServices // ignore: cast_nullable_to_non_nullable
              as int,
      openIncidents: null == openIncidents
          ? _value.openIncidents
          : openIncidents // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$ProjectStatsImpl implements _ProjectStats {
  const _$ProjectStatsImpl(
      {required this.projectId,
      required this.totalServices,
      required this.healthyServices,
      required this.unhealthyServices,
      required this.openIncidents});

  @override
  final String projectId;
  @override
  final int totalServices;
  @override
  final int healthyServices;
  @override
  final int unhealthyServices;
  @override
  final int openIncidents;

  @override
  String toString() {
    return 'ProjectStats(projectId: $projectId, totalServices: $totalServices, healthyServices: $healthyServices, unhealthyServices: $unhealthyServices, openIncidents: $openIncidents)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProjectStatsImpl &&
            (identical(other.projectId, projectId) ||
                other.projectId == projectId) &&
            (identical(other.totalServices, totalServices) ||
                other.totalServices == totalServices) &&
            (identical(other.healthyServices, healthyServices) ||
                other.healthyServices == healthyServices) &&
            (identical(other.unhealthyServices, unhealthyServices) ||
                other.unhealthyServices == unhealthyServices) &&
            (identical(other.openIncidents, openIncidents) ||
                other.openIncidents == openIncidents));
  }

  @override
  int get hashCode => Object.hash(runtimeType, projectId, totalServices,
      healthyServices, unhealthyServices, openIncidents);

  /// Create a copy of ProjectStats
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ProjectStatsImplCopyWith<_$ProjectStatsImpl> get copyWith =>
      __$$ProjectStatsImplCopyWithImpl<_$ProjectStatsImpl>(this, _$identity);
}

abstract class _ProjectStats implements ProjectStats {
  const factory _ProjectStats(
      {required final String projectId,
      required final int totalServices,
      required final int healthyServices,
      required final int unhealthyServices,
      required final int openIncidents}) = _$ProjectStatsImpl;

  @override
  String get projectId;
  @override
  int get totalServices;
  @override
  int get healthyServices;
  @override
  int get unhealthyServices;
  @override
  int get openIncidents;

  /// Create a copy of ProjectStats
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ProjectStatsImplCopyWith<_$ProjectStatsImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
